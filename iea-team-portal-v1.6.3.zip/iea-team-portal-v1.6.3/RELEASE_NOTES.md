# IEA Team Portal v1.6.3 — Staff + Guardian UI hotfix

## Fixed
- Administrator and Coach accounts can now see and select the Parent/Guardian field on the user-management form.
- The v1.6.2 backend support for dual staff/family relationships is now correctly exposed by the front-end UI.
- Rider accounts continue to hide/disallow guardian links.

## Database
No migration is required for v1.6.3.

# IEA Team Portal v1.6.2 — Staff + Parent Relationship Fix

## Fixed
- Administrators and Coaches can now also be linked to a Parent/Guardian contact without changing their staff role.
- User onboarding and account editing now treat staff role and family relationship as independent concepts.
- Parent-targeted announcements include users who are actually linked as guardians, even if their primary portal role is Admin or Coach.
- Committee Chair and Show Lead selectors now include staff users who are linked as guardians, in addition to ordinary Parent-role accounts.

## Behavior
- Parent accounts still require a guardian link.
- Rider accounts still require a rider link and cannot simultaneously be linked as a guardian.
- Admin/Coach accounts may optionally have a guardian link.
- Existing v1.6.1 privacy and delegated-permission rules remain unchanged.

## Database
No new database migration is required for v1.6.2. The existing GuardianContact model already supports linking any user account; this release removes the overly restrictive form/query rules.
