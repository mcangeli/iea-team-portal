from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db.models import Q, Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import (
    AnnouncementForm,
    CalendarEventForm,
    RiderForm,
    ShowClassForm,
    ShowEntryForm,
    ShowForm,
    ShowResultForm,
)
from .models import Announcement, CalendarEvent, Rider, Show, ShowEntry, ShowResult, UserProfile


def _team(user):
    if user.is_superuser:
        return user.profile.team if hasattr(user, "profile") else None
    if not hasattr(user, "profile") or not user.profile.team:
        raise PermissionDenied("Your account is not assigned to a team.")
    return user.profile.team


def _can_manage(user):
    return user.is_superuser or (
        hasattr(user, "profile")
        and user.profile.role in [UserProfile.Role.ADMIN, UserProfile.Role.COACH]
    )


def _require_manage(user):
    if not _can_manage(user):
        raise PermissionDenied


def _visible_riders(user, team):
    qs = team.riders.all()
    if hasattr(user, "profile") and user.profile.role == UserProfile.Role.PARENT:
        qs = qs.filter(guardians=user)
    elif hasattr(user, "profile") and user.profile.role == UserProfile.Role.RIDER:
        qs = qs.filter(user=user)
    return qs


@login_required
def dashboard(request):
    team = _team(request.user)
    if not team:
        return render(request, "portal/no_team.html")
    season = team.seasons.filter(is_active=True).first()
    now = timezone.now()
    today = timezone.localdate()
    announcements = team.announcements.filter(published=True).filter(
        Q(expires_at__isnull=True) | Q(expires_at__gt=now)
    )[:5]
    events = team.events.filter(starts_at__gte=now)[:6]
    riders = _visible_riders(request.user, team).filter(active=True)
    shows = team.shows.filter(show_date__gte=today).order_by("show_date")[:4]
    return render(
        request,
        "portal/dashboard.html",
        {
            "season": season,
            "announcements": announcements,
            "events": events,
            "riders": riders,
            "shows": shows,
            "can_manage": _can_manage(request.user),
        },
    )


@login_required
def rider_list(request):
    team = _team(request.user)
    qs = _visible_riders(request.user, team)
    return render(
        request,
        "portal/rider_list.html",
        {"riders": qs, "can_manage": _can_manage(request.user)},
    )


@login_required
def rider_detail(request, pk):
    team = _team(request.user)
    rider = get_object_or_404(Rider, pk=pk, team=team)
    if not _can_manage(request.user):
        allowed = rider.user_id == request.user.id or rider.guardians.filter(pk=request.user.pk).exists()
        if not allowed:
            raise PermissionDenied
    season_points = rider.show_entries.filter(result__isnull=False).aggregate(total=Sum("result__points"))["total"] or 0
    return render(
        request,
        "portal/rider_detail.html",
        {"rider": rider, "season_points": season_points, "can_manage": _can_manage(request.user)},
    )


@login_required
def rider_create(request):
    _require_manage(request.user)
    team = _team(request.user)
    form = RiderForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.save()
        messages.success(request, "Rider added.")
        return redirect("rider_detail", pk=obj.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add rider", "eyebrow": "ROSTER"})


@login_required
def rider_edit(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    obj = get_object_or_404(Rider, pk=pk, team=team)
    form = RiderForm(request.POST or None, request.FILES or None, instance=obj)
    if form.is_valid():
        form.save()
        messages.success(request, "Rider updated.")
        return redirect("rider_detail", pk=obj.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Edit rider", "eyebrow": "ROSTER"})


@login_required
def calendar(request):
    team = _team(request.user)
    return render(
        request,
        "portal/calendar.html",
        {"events": team.events.all()[:100], "can_manage": _can_manage(request.user)},
    )


@login_required
def event_create(request):
    _require_manage(request.user)
    team = _team(request.user)
    form = CalendarEventForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.season = team.seasons.filter(is_active=True).first()
        obj.save()
        messages.success(request, "Calendar event added.")
        return redirect("calendar")
    return render(request, "portal/form.html", {"form": form, "title": "Add calendar event", "eyebrow": "SCHEDULE"})


@login_required
def announcement_create(request):
    _require_manage(request.user)
    team = _team(request.user)
    form = AnnouncementForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.season = team.seasons.filter(is_active=True).first()
        obj.created_by = request.user
        obj.save()
        messages.success(request, "Announcement posted.")
        return redirect("dashboard")
    return render(request, "portal/form.html", {"form": form, "title": "Post announcement", "eyebrow": "TEAM NEWS"})


@login_required
def show_list(request):
    team = _team(request.user)
    today = timezone.localdate()
    upcoming = team.shows.filter(show_date__gte=today).order_by("show_date")
    past = team.shows.filter(show_date__lt=today).order_by("-show_date")[:20]
    return render(request, "portal/show_list.html", {"upcoming": upcoming, "past": past, "can_manage": _can_manage(request.user)})


@login_required
def show_detail(request, pk):
    team = _team(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    classes = show.classes.prefetch_related("entries__rider", "entries__result")
    return render(request, "portal/show_detail.html", {"show": show, "classes": classes, "can_manage": _can_manage(request.user)})


@login_required
def show_create(request):
    _require_manage(request.user)
    team = _team(request.user)
    season = team.seasons.filter(is_active=True).first()
    if not season:
        messages.error(request, "Create or activate a season before adding a show.")
        return redirect("show_list")
    form = ShowForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.season = season
        obj.save()
        messages.success(request, "Show added.")
        return redirect("show_detail", pk=obj.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add show", "eyebrow": "COMPETITION"})


@login_required
def show_edit(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    show = get_object_or_404(Show, pk=pk, team=team)
    form = ShowForm(request.POST or None, instance=show)
    if form.is_valid():
        form.save()
        messages.success(request, "Show updated.")
        return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Edit show", "eyebrow": "COMPETITION"})


@login_required
def show_class_create(request, show_pk):
    _require_manage(request.user)
    team = _team(request.user)
    show = get_object_or_404(Show, pk=show_pk, team=team)
    form = ShowClassForm(request.POST or None, initial={"discipline": team.discipline if team.discipline != "multi" else "hunt_seat"})
    if form.is_valid():
        obj = form.save(commit=False)
        obj.show = show
        obj.save()
        messages.success(request, "Class added.")
        return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add class", "eyebrow": show.name})


@login_required
def show_entry_create(request, show_pk):
    _require_manage(request.user)
    team = _team(request.user)
    show = get_object_or_404(Show, pk=show_pk, team=team)
    form = ShowEntryForm(request.POST or None, show=show, team=team)
    if form.is_valid():
        entry = form.save(commit=False)
        if entry.show_class.show_id != show.id or entry.rider.team_id != team.id:
            raise PermissionDenied
        entry.save()
        messages.success(request, "Rider entry added.")
        return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add rider entry", "eyebrow": show.name})


@login_required
def show_result_edit(request, entry_pk):
    _require_manage(request.user)
    team = _team(request.user)
    entry = get_object_or_404(ShowEntry.objects.select_related("show_class__show", "rider"), pk=entry_pk, show_class__show__team=team)
    result, _ = ShowResult.objects.get_or_create(entry=entry)
    form = ShowResultForm(request.POST or None, instance=result)
    if form.is_valid():
        form.save()
        messages.success(request, "Result saved.")
        return redirect("show_detail", pk=entry.show_class.show_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Result · {entry.rider}", "eyebrow": entry.show_class.name})
