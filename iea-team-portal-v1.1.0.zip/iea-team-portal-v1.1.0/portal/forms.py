from django import forms
from .models import (
    Announcement,
    CalendarEvent,
    Rider,
    Show,
    ShowClass,
    ShowEntry,
    ShowResult,
)


class DateTimeLocalInput(forms.DateTimeInput):
    input_type = "datetime-local"


class DateInput(forms.DateInput):
    input_type = "date"


class TimeInput(forms.TimeInput):
    input_type = "time"


class RiderForm(forms.ModelForm):
    class Meta:
        model = Rider
        fields = [
            "first_name",
            "last_name",
            "preferred_name",
            "school",
            "grade",
            "iea_member_number",
            "bio",
            "photo",
            "active",
        ]


class AnnouncementForm(forms.ModelForm):
    class Meta:
        model = Announcement
        fields = ["title", "body", "priority", "published", "expires_at"]
        widgets = {"expires_at": DateTimeLocalInput(format="%Y-%m-%dT%H:%M")}


class CalendarEventForm(forms.ModelForm):
    class Meta:
        model = CalendarEvent
        fields = [
            "title",
            "kind",
            "starts_at",
            "ends_at",
            "location",
            "description",
            "visible_to_all",
        ]
        widgets = {
            "starts_at": DateTimeLocalInput(format="%Y-%m-%dT%H:%M"),
            "ends_at": DateTimeLocalInput(format="%Y-%m-%dT%H:%M"),
        }


class ShowForm(forms.ModelForm):
    class Meta:
        model = Show
        fields = [
            "name",
            "show_date",
            "start_time",
            "venue",
            "address",
            "host_team",
            "iea_zone",
            "iea_region",
            "status",
            "entry_deadline",
            "notes",
        ]
        widgets = {
            "show_date": DateInput(),
            "start_time": TimeInput(),
            "entry_deadline": DateInput(),
        }


class ShowClassForm(forms.ModelForm):
    class Meta:
        model = ShowClass
        fields = ["name", "division", "discipline", "class_number", "sort_order"]


class ShowEntryForm(forms.ModelForm):
    class Meta:
        model = ShowEntry
        fields = ["show_class", "rider", "entry_type", "is_point_rider", "status", "notes"]

    def __init__(self, *args, show=None, team=None, **kwargs):
        super().__init__(*args, **kwargs)
        if show is not None:
            self.fields["show_class"].queryset = show.classes.all()
        if team is not None:
            self.fields["rider"].queryset = team.riders.filter(active=True)


class ShowResultForm(forms.ModelForm):
    class Meta:
        model = ShowResult
        fields = ["place", "points", "horse_name", "notes"]
