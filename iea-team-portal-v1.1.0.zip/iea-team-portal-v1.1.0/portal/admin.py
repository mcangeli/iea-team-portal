from django.contrib import admin
from .models import (
    Announcement,
    CalendarEvent,
    Rider,
    Season,
    SeasonMembership,
    Show,
    ShowClass,
    ShowEntry,
    ShowResult,
    Team,
    UserProfile,
)


@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_display = ("name", "discipline")


@admin.register(Season)
class SeasonAdmin(admin.ModelAdmin):
    list_display = ("name", "team", "start_date", "end_date", "is_active")
    list_filter = ("team", "is_active")


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "team", "role")
    list_filter = ("role", "team")


@admin.register(Rider)
class RiderAdmin(admin.ModelAdmin):
    list_display = ("last_name", "first_name", "team", "school", "grade", "active")
    list_filter = ("team", "active", "grade")
    search_fields = ("first_name", "last_name", "school", "iea_member_number")


@admin.register(SeasonMembership)
class MembershipAdmin(admin.ModelAdmin):
    list_display = ("rider", "season", "division", "class_level")
    list_filter = ("season",)


@admin.register(Announcement)
class AnnouncementAdmin(admin.ModelAdmin):
    list_display = ("title", "team", "priority", "published", "created_at")
    list_filter = ("team", "priority", "published")


@admin.register(CalendarEvent)
class CalendarEventAdmin(admin.ModelAdmin):
    list_display = ("title", "team", "kind", "starts_at", "location")
    list_filter = ("team", "kind")


class ShowClassInline(admin.TabularInline):
    model = ShowClass
    extra = 0


@admin.register(Show)
class ShowAdmin(admin.ModelAdmin):
    list_display = ("name", "team", "season", "show_date", "status", "venue")
    list_filter = ("team", "season", "status")
    search_fields = ("name", "venue", "host_team")
    inlines = [ShowClassInline]


@admin.register(ShowClass)
class ShowClassAdmin(admin.ModelAdmin):
    list_display = ("name", "show", "division", "class_number", "discipline")
    list_filter = ("discipline", "show")


@admin.register(ShowEntry)
class ShowEntryAdmin(admin.ModelAdmin):
    list_display = ("rider", "show_class", "entry_type", "is_point_rider", "status")
    list_filter = ("entry_type", "is_point_rider", "status")
    search_fields = ("rider__first_name", "rider__last_name", "show_class__name")


@admin.register(ShowResult)
class ShowResultAdmin(admin.ModelAdmin):
    list_display = ("entry", "place", "points", "horse_name")
