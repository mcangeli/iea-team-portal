# v1.1.0 Release Notes

## Competition management
- Shows, show status, venues, host information, zones/regions, deadlines, and notes
- Show classes
- Rider entries by class
- Individual/team/combined entry types
- Point-rider flag
- Entry status
- Place, points, horse, and result notes

## Design refresh
- New equestrian/editorial visual system
- Redesigned login experience
- Modern sticky navigation
- New dashboard hierarchy and metrics
- Upcoming-show cards
- Purpose-built show detail and entry tables
- Refined rider cards, forms, calendar, and responsive behavior

## Reliability and deployment
- Fixes anonymous login 500 caused by resolving `portal_team.name` when no team context exists
- Shared parent-directory `.env`
- `portalctl` wrapper automatically supplies the shared env to Compose
- Stable Compose/volume names for upgrades from this release onward
- Gunicorn access/error logs emitted to Docker logs
