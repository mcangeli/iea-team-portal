# Interscholastic Equestrian Team Portal — v1.1.0

A private, self-hosted portal for coaches, parents/guardians, and riders. v1.1.0 adds competition management, a redesigned interface, safer upgrades, and a persistent environment-file layout.

## Highlights in v1.1.0

- New Shows section
- Show status, date, venue, host team, zone/region, entry deadline, and notes
- Classes within each show
- Rider entries by class
- Individual, team, or combined entry type
- Point-rider designation
- Entry status (planned, entered, scratched)
- Results stored separately from entries
- Place, points, and horse name per result
- Rider profile season points summary
- Modernized login, navigation, dashboard, rider cards, calendar, forms, and show pages
- Fixed the v1.0.1 anonymous-login template 500 error
- Gunicorn request/access logging enabled
- Shared `.env` outside release directories
- Stable Docker Compose project and volume names for future upgrades

## Branding

The interface uses IEA Primary Blue `#007297` with restrained cyan accents and a custom editorial/equestrian visual language. No official IEA logo is bundled. Upload only marks your team is authorized to use. This is a private team portal and not an official IEA website.

## Recommended server layout

Keep configuration outside the versioned application folders:

```text
/opt/iea-team-portal/
├── .env
├── iea-team-portal-v1.0.1/
├── iea-team-portal-v1.1.0/
└── backups/
```

From v1.1.0 forward you should normally never need to copy or edit `.env` during an upgrade.

## Fresh installation

### 1. Extract the release

```bash
sudo mkdir -p /opt/iea-team-portal
sudo chown "$USER":"$USER" /opt/iea-team-portal
cd /opt/iea-team-portal
unzip iea-team-portal-v1.1.0.zip
```

### 2. Create the shared environment file once

```bash
cd /opt/iea-team-portal
cp iea-team-portal-v1.1.0/.env.example .env
nano .env
```

Example:

```ini
APP_PORT=8088
DJANGO_SECRET_KEY=YOUR-LONG-RANDOM-SECRET
DJANGO_DEBUG=0
DJANGO_ALLOWED_HOSTS=team.example.com
DJANGO_CSRF_TRUSTED_ORIGINS=https://team.example.com
POSTGRES_DB=iea_team
POSTGRES_USER=iea_team
POSTGRES_PASSWORD=YOUR-LONG-RANDOM-DATABASE-PASSWORD
POSTGRES_HOST=db
POSTGRES_PORT=5432
TIME_ZONE=America/New_York
SECURE_COOKIES=1
SECURE_HSTS_SECONDS=31536000
```

Generate secrets with:

```bash
openssl rand -base64 48
openssl rand -base64 36
```

### 3. Start the portal

```bash
cd /opt/iea-team-portal/iea-team-portal-v1.1.0
./portalctl up -d --build
./portalctl ps
./portalctl logs --tail=100 web
```

`portalctl` automatically reads `/opt/iea-team-portal/.env` when the release directory is directly beneath `/opt/iea-team-portal`.

The Docker gateway binds only to:

```text
127.0.0.1:${APP_PORT}
```

The default is `127.0.0.1:8088`. Your existing Apache/Nginx/Caddy remains on public ports 80/443.

### 4. Existing host reverse proxy

#### Nginx

```nginx
location / {
    proxy_pass http://127.0.0.1:8088;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-Host $host;
}
```

#### Apache

```apache
ProxyPreserveHost On
RequestHeader set X-Forwarded-Proto "https"
RequestHeader set X-Forwarded-Host "%{HTTP_HOST}s"
ProxyPass        / http://127.0.0.1:8088/
ProxyPassReverse / http://127.0.0.1:8088/
```

Required Apache modules:

```bash
sudo a2enmod proxy proxy_http headers ssl
```

#### Host Caddy

```caddy
team.example.com {
    reverse_proxy 127.0.0.1:8088
}
```

### 5. Bootstrap a brand-new installation

Do this only for a fresh database:

```bash
./portalctl exec web python manage.py bootstrap_team \
  --team "My Equestrian Team" \
  --season "2026-2027" \
  --username coachadmin \
  --email coach@example.com \
  --password 'USE-A-STRONG-UNIQUE-PASSWORD'
```

Then visit your configured HTTPS hostname. Django Admin remains available at `/admin/`.

---

# Upgrading from v1.0.1 to v1.1.0

v1.0.1 used the release directory as the Docker Compose project name. v1.1.0 deliberately switches to stable volume names so future releases do not create apparently empty databases just because the folder name changed.

The safest one-time migration is a PostgreSQL dump/restore plus a media archive.

## 1. Put the existing environment file in the permanent location

```bash
cd /opt/iea-team-portal
cp iea-team-portal-v1.0.1/.env .env
chmod 600 .env
```

Keep `/opt/iea-team-portal/.env` from now on.

## 2. Back up v1.0.1 before stopping it

```bash
mkdir -p /opt/iea-team-portal/backups
cd /opt/iea-team-portal/iea-team-portal-v1.0.1

docker compose exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" "$POSTGRES_DB"' \
  > /opt/iea-team-portal/backups/pre-v1.1.0.sql

docker compose exec -T gateway tar czf - -C /srv/media . \
  > /opt/iea-team-portal/backups/pre-v1.1.0-media.tgz
```

Confirm the files are non-empty:

```bash
ls -lh /opt/iea-team-portal/backups/pre-v1.1.0*
```

## 3. Stop v1.0.1 without deleting its volumes

```bash
docker compose down
```

Do **not** use `-v`.

## 4. Start only the new database

```bash
cd /opt/iea-team-portal/iea-team-portal-v1.1.0
./portalctl up -d db
```

Check readiness:

```bash
./portalctl ps
```

## 5. Restore the v1.0.1 database into the stable v1.1.0 volume

```bash
cat /opt/iea-team-portal/backups/pre-v1.1.0.sql | \
  ./portalctl exec -T db sh -c 'psql -U "$POSTGRES_USER" "$POSTGRES_DB"'
```

## 6. Restore media files

```bash
docker run --rm \
  -v iea-team-portal_media_data:/target \
  -v /opt/iea-team-portal/backups:/backup:ro \
  alpine sh -c 'tar xzf /backup/pre-v1.1.0-media.tgz -C /target'
```

If you have never uploaded rider photos or a team logo, the media archive may effectively be empty; that is fine.

## 7. Start v1.1.0

```bash
./portalctl up -d --build
./portalctl logs --tail=100 web
```

Django automatically applies the new competition-management migration on startup.

Test locally through the Docker gateway:

```bash
curl -I -H "Host: YOUR.ACTUAL.DOMAIN" -H "X-Forwarded-Proto: https" http://127.0.0.1:8088/
```

Then load the normal HTTPS site in your browser.

After you have verified the roster, photos, users, and season data, the old v1.0.1 Docker volumes can be removed later if desired. Keep the SQL/media backups until you are satisfied with the upgrade.

---

# Future upgrades (v1.1.0 and later)

Future release folders will use the same shared `.env` and the same named persistent volumes. The intended upgrade workflow becomes:

```bash
cd /opt/iea-team-portal/NEW-RELEASE-DIRECTORY
./portalctl up -d --build
./portalctl logs --tail=100 web
```

No `.env` copying should be required.

## Optional custom environment-file location

If you do not install releases directly beneath `/opt/iea-team-portal`, set `PORTAL_ENV_FILE`:

```bash
export PORTAL_ENV_FILE=/some/permanent/path/iea-team.env
./portalctl up -d --build
```

## Show workflow in v1.1.0

1. Open **Shows**.
2. Add a show. It is automatically linked to the active season.
3. Open the show and add its classes.
4. Add rider entries and identify individual/team/combined entries.
5. Mark a rider as a point rider where appropriate.
6. After the class, choose **Result** and enter place, points, and horse.
7. Rider profiles accumulate entered result points for the team history view.

The v1.1.0 point field is intentionally entered by the coach rather than calculated from a hard-coded rules table. Automated rule/qualification logic is better added as a season-aware rules feature in a later release.

## Roles

- Administrator / Coach: team-wide management tools
- Parent/Guardian: only linked riders
- Rider: only their linked rider profile
- Django superuser: full admin access

Routine show, rider, calendar, and announcement work can be done through the normal portal. Django Admin remains available for deeper setup such as user accounts, guardian relationships, seasons, and season memberships.

## Useful commands

```bash
./portalctl ps
./portalctl logs -f web
./portalctl logs -f gateway
./portalctl restart web
./portalctl exec web python manage.py check
./portalctl exec web python manage.py migrate
```

## Backups from v1.1.0 onward

Database:

```bash
mkdir -p /opt/iea-team-portal/backups
./portalctl exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" "$POSTGRES_DB"' \
  > /opt/iea-team-portal/backups/iea-team-$(date +%F).sql
```

Media:

```bash
docker run --rm \
  -v iea-team-portal_media_data:/source:ro \
  -v /opt/iea-team-portal/backups:/backup \
  alpine tar czf /backup/media-$(date +%F).tgz -C /source .
```

## Security

- Keep `.env` outside the release directory and use `chmod 600 /opt/iea-team-portal/.env`.
- Keep `DJANGO_DEBUG=0` on an Internet-facing server.
- Use HTTPS at the host reverse proxy.
- Do not expose PostgreSQL publicly.
- Do not store medical records, waivers, or other highly sensitive youth information in this version.
- Back up the database and media to storage separate from the server.
