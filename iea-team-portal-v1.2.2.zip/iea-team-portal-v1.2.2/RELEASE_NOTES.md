# v1.2.2 Release Notes

## Migration hotfix

- Fixes upgrade failure when `portal_rider.email` already exists.
- Migration `0003_team_levels_season_classes_guardians` now uses PostgreSQL `ADD COLUMN IF NOT EXISTS` while still recording the field in Django migration state.
- No `--fake`, column deletion, or database reset is required.
- All v1.2.0 Futures/Upper, season-class, rider-email, and parent/guardian features are retained.

## Upgrade from a failed v1.2.0 start

Stop the failed v1.2.0 release, unpack v1.2.2, then run `./portalctl up -d --build`. The migration was not recorded as applied when PostgreSQL raised the duplicate-column error, so v1.2.2 will retry it safely and continue with the remaining operations.

---

# v1.2.2 Release Notes

## Team structure
- Adds season-specific **Futures Team** and **Upper School Team** assignments.
- Futures is intended for grades 4–8; Upper School for grades 9–12.
- Grade is used only to suggest/migrate a team level. The season membership is authoritative, so history stays correct as a rider advances between teams.
- The roster page now displays Futures and Upper School separately.

## Season-level classes
- Adds a `SeasonClass` catalog owned by the season rather than by an individual show.
- A rider's classes are assigned once on `SeasonMembership`.
- Shows now select which season classes are offered and may give those occurrences a show-specific class number/order.
- Show entries validate that the rider is on the season roster, is on the correct team level, and is assigned to the chosen class for that season.
- Existing v1.1 show classes are migrated into season classes. Existing show entries seed rider class assignments so existing competition records remain usable.

## Rider and family contacts
- Adds rider email address.
- Adds full parent/guardian contact records with name, email, phone, notes, relationship, and primary-contact flag.
- Parent contacts may exist without login accounts; an optional user link can provide portal access.
- Existing guardian login relationships are migrated into contact records.
- Adds a coach-only Parent/Guardian Directory.

## Interface
- Adds a Season setup workspace for class catalog and roster assignments.
- Rider profiles now show team/class history and family contacts.
- Dashboard highlights Futures and Upper School roster counts.
- Continues the custom editorial/equestrian visual system introduced in v1.1.

## Deployment
- Uses the same persistent `/opt/iea-team-portal/.env` introduced in v1.1.
- Uses the same stable Docker volumes introduced in v1.1. No environment copy or database-volume migration is needed when upgrading from v1.1.0.
