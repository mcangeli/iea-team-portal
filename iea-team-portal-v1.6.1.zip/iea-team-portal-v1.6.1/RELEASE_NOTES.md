# IEA Team Portal v1.6.1 — Committees & Show Planning

## Added
- Season-scoped committee chair assignments for Upper Team Parent, Futures Team Parent, Treasurer, and Secretary / Points Secretary.
- Per-show Show Lead assignments.
- Show Planning page with hospitality and operational checklist items.
- Lunch, snack, drink, supply, task, and other planning categories.
- Family claim/release workflow for visible show-day needs.
- Delegated capability helpers for team-parent coordination, points-secretary access, and show-lead planning.

## Privacy and permissions
Committee roles supplement the user's existing Parent account rather than replacing it. They do not grant blanket Coach/Admin access. Show Lead access is limited to the assigned show. Existing v1.6.0 rider/family privacy rules remain in place.

## Database
Adds migration `0010_v161_committees_show_planning`.
