# IEA Team Portal v1.8.8 — Record Book & Season Review Layout

## Refined
Record Book and Season Review now visually follow the same presentation system as Standings.

Season Review now leads with team qualification cards, followed by individual class qualification progress and the rider season snapshot.

Record Book now uses the standard competition table layout for Rider/Class/Season records, with improved ranking and award cards.

This release is presentation-only and does not change scoring logic or the database schema.

## Migration
No new migration.

# IEA Team Portal v1.8.7 — Historical Season Page 500 Fix

## Fixed
Season Review and Team Record Book could return HTTP 500 because some queries still used the retired reverse relation name `season_memberships`. The current `SeasonMembership.rider` relation uses `related_name="memberships"`.

All stale references were replaced with `memberships`, including related filters used by announcements and show-entry rider selection.

Rider History also now handles an unexpectedly empty summary defensively.

## Migration
No new migration.

# IEA Team Portal v1.8.6 — Class-Specific Rider Points & H8/H14 Team Scoring

## Fixed — Rider points
Season points for an individual rider are qualification totals **per class**, not one total across all classes. The qualification calculation was already class-specific, but several history/reporting screens still displayed an all-class aggregate. Those displays have been corrected.

Rider History and printable summaries now show class point totals. Season Review shows class point totals per rider. The Record Book now ranks Rider/Class/Season records.

## Fixed — Team points
H8 and H14 Walk/Trot classes do not count toward team points. v1.8.6 excludes those classes from all team-scoring rows/totals and prevents a point-rider designation from being applied to them.

## Migration
No new migration.

# IEA Team Portal v1.8.5 — Historical Rider Results

## Added
A dedicated **Add Historical Results** workflow is now available from Rider Development History.

Administrators and Coaches can select a prior season, enter a historical show once, and record multiple class results for the rider. Archived seasons are intentionally supported.

Historical entries are stored in the portal's normal result structure so individual points, wins, qualification progress, season summaries, and record-book calculations continue to use one consistent source of truth. Historical imports are individual-only and do not designate a points rider, preventing them from changing team points-rider totals.

Rider Development History now displays individual result lines and marks imported shows as **Historical entry**.

## Migration
`0014_v185_historical_results.py`

## Included fixes
v1.8.5 includes the v1.8.3 user-creation double-submit protection and the v1.8.4 media upload/storage fix.

# IEA Team Portal v1.8.4 — Media Upload Storage Hotfix

## Fixed
Rider photo uploads could return a 500 error because `settings.STORAGES` defined only the `staticfiles` backend. In Django 5.2, uploaded model files use the `default` storage alias; without it, the first attempt to save an uploaded image can fail while ordinary non-file edits continue to work.

v1.8.4 adds the filesystem `default` storage backend while preserving WhiteNoise for static files. The existing Docker media volume at `/app/media` continues to provide persistent storage.

## Migration
No new database migration is required.

# IEA Team Portal v1.8.3 — User Creation Double-Submit Hotfix

## Fixed
Creating a Rider/Guardian login could successfully create the account but still display a database conflict error. This was consistent with two near-simultaneous onboarding submissions: the first request completed successfully while the second collided with the newly-created username/link.

v1.8.3 prevents duplicate submits in the browser and also reconciles raced requests on the server. If the same username is already linked to the intended Rider/Guardian, the request is treated as a successful create rather than an error.

## Migration
No new migration is required. v1.8.3 includes all prior migrations through `0013_v182_user_sequence_repair.py`.

# IEA Team Portal v1.8.2 — User Onboarding Sequence Repair

## Fixed
New Rider/Parent login creation could still fail with a generic database constraint message. v1.8.2 repairs PostgreSQL sequences for `auth_user` and `portal_userprofile`, which can become out of sync after historical restores or schema repair work.

The onboarding view now also maps common database constraints to specific messages and includes the unexpected constraint name when one is encountered.

## Migration
`0013_v182_user_sequence_repair.py`

# IEA Team Portal v1.8.1 — Startup Hotfix

## Fixed
v1.8.0 could fail during Docker image build while running `collectstatic` with:

`NameError: name 'CalendarEvent' is not defined`

The new EventRSVP and ActionItem models were declared before CalendarEvent in `models.py` and used direct class references. v1.8.1 changes those relationships to Django string-based forward references.

## Upgrade
No additional migration was added. v1.8.1 still includes `0012_v180_team_hub.py`, which will apply normally if the v1.8.0 build failed before migrations ran.

# IEA Team Portal v1.8.0 — Team Hub

## Major features

### My Team
A new family/team hub combines current rider enrollment, upcoming events, event RSVP requests, and action items. Parents with multiple linked riders see their family in one place.

### General calendar RSVP
Calendar events may now request rider/family responses using Going, Maybe, or Not going, with an optional deadline.

### Reusable action items
Managers can create team tasks and sign-ups associated with a rider, event, show, or season. Items may be directly assigned or opened for families to claim.

### Dashboard coordination
The dashboard now surfaces My Week and a manager Needs Attention area for RSVP gaps, overdue/unclaimed tasks, volunteer approvals, and show availability.

### Reminder expansion
The daily reminder command now includes general event RSVP reminders and due assigned action items.

## Fixed
Creating a login from a Rider has been hardened so account/profile/linking conflicts are handled transactionally and displayed as form errors rather than a 500 page.

## Migration
`0012_v180_team_hub.py`

## Roadmap
- Finance & Fundraising remains targeted for v1.9.0 or later.
- Horse & Hoofprint Management has been added to the v2.x.x roadmap.

# IEA Team Portal v1.7.3 — Rider Season Enrollment

## Added
The Add Rider workflow can now create the rider's first SeasonMembership at the same time as the permanent Rider record.

### Rider creation
- Optional season selector.
- Active season preselected when available.
- Futures / Upper School team selection.
- Season class selection.
- Season-specific notes.
- Dynamic class filtering by season and team level.

### Data model
This does not change the underlying model: a Rider is still created once, while SeasonMembership records represent that rider's participation each year.

## Database
No migration is required for v1.7.3.

# IEA Team Portal v1.7.2 — Validation & Calendar Editing

## Fixed
- Duplicate create attempts no longer produce raw 500 errors in the hardened workflows.
- Context-aware validation catches duplicates whose uniqueness includes season/show context that is assigned after normal form validation.

## Added
- Edit action for manually-created calendar events.
- Synced show calendar entries link to Edit Show.
- Synced lesson calendar entries link to Edit Lesson.
- Friendly fallback message for database constraint collisions in key create workflows.

## Database
No migration is required for v1.7.2.

# IEA Team Portal v1.7.1 — Existing Guardian Linking

## Fixed
The rider page previously allowed creating a new parent/guardian but did not expose the existing many-to-many family relationship workflow.

## Added
- **Create new parent** and **Link existing parent** are now separate actions on Rider profiles.
- The existing-parent workflow lists GuardianContact records on the same team that are not already linked to that rider.
- Relationship label and primary-contact status can be set when linking.
- Existing guardian user accounts are preserved and linked to the additional rider.
- A guardian can be unlinked from one rider without deleting the guardian contact or user account.

## Database
No migration is required for v1.7.1.

# IEA Team Portal v1.7.0 — Season History & Reporting

## Added
- Season archive and Season Review workspace.
- Administrator close/reopen season workflow.
- Rider Development History across seasons.
- Staff-only or family-visible rider development notes.
- Awards & Recognition.
- Printable end-of-season rider summaries.
- Team record book with historical season point totals, wins, and published awards.
- Delegated Points Secretary access for results, detailed standings, qualification review, and standings export.

## Privacy
Competition-reporting delegation does not expose rider contact details or unrelated private operational information. Rider history remains limited to staff and the rider/linked family.

## Database
Adds `0011_v170_season_history_reporting`:
- `Season.is_closed`
- `Season.closed_at`
- `RiderDevelopmentNote`
- `RiderAward`

## Upgrade
`./portalctl upgrade` creates the normal pre-upgrade database backup before applying the release.
