# IEA Team Portal v1.5.5

A self-hosted Django portal for an interscholastic equestrian team with Futures and Upper School rosters, shows, scoring/qualification, lessons, attendance, show availability, volunteer-hour tracking, calendar, family contacts, announcements, and role-based access.

v1.5.5 is a focused **User & Family Onboarding** release. It keeps the v1.5.0 operations features and makes creating, linking, and securing portal logins substantially easier.

## v1.5.5 highlights

### Guided user onboarding
- New **Users** page for Coach/Admin account management.
- **Add user** creates the Django login and portal role in one form.
- Rider accounts must be linked to an existing rider record.
- Parent/Guardian accounts must be linked to an existing guardian contact.
- Starting from a rider or parent record provides a **Create login** action with name, email, role, and record link prefilled.
- Linked records show **Manage login** instead.
- User list shows role, linked record, active/inactive state, and first-login password status.
- Administrators can create/manage Admin, Coach, Parent, and Rider roles.
- Coaches can create/manage Parent and Rider accounts only; they cannot grant Coach/Admin privileges.

### Temporary password + first-login security
- `DEFAULT_TEMP_PASSWORD` can be configured once in the shared `/opt/iea-team-portal/.env`.
- The onboarding form can use that server default or a one-off temporary password entered for a specific account.
- The configured default password is never displayed back in the portal.
- Temporary passwords are checked with Django's configured password validators.
- New accounts are marked **Password change required**.
- After first login, middleware prevents access to the portal until the user chooses a new password.
- Coach/Admin can reset another user's temporary password, which re-enables the mandatory password-change gate.
- A user cannot use the management reset workflow to reset their own password.

### Existing family relationships
- Linking a Parent/Guardian login also preserves the legacy guardian authorization relation for all riders attached to that guardian contact.
- Editing a login can repair or change its rider/guardian link without using Django Admin.

## One-time optional `.env` setting

To use a team-wide default temporary password, add this to the existing shared environment file:

```env
DEFAULT_TEMP_PASSWORD=replace-with-a-strong-temporary-password
```

The shared environment remains at:

```text
/opt/iea-team-portal/.env
```

If `DEFAULT_TEMP_PASSWORD` is left blank or omitted, the Add User / Reset Password forms require a one-off temporary password instead.

## Persistent deployment layout

```text
/opt/iea-team-portal/
├── .env
├── backups/
├── iea-team-portal-v1.5.0/
└── iea-team-portal-v1.5.5/
```

The existing PostgreSQL/media volumes and reverse proxy configuration are unchanged.

## Upgrade to v1.5.5

```bash
cd /opt/iea-team-portal/iea-team-portal-v1.5.5
chmod +x portalctl
./portalctl upgrade
```

The upgrade creates a timestamped PostgreSQL backup, runs schema preflight, builds the release, and applies migrations automatically on startup.

Verify:

```bash
./portalctl ps
./portalctl logs --tail=150 web
./portalctl exec web python manage.py showmigrations portal
./portalctl exec web python manage.py check
```

Expected latest migration:

```text
[X] 0007_v155_user_onboarding
```

## Recommended onboarding workflow

1. Add rider and parent/guardian contact records as usual.
2. Open the rider or parent record and choose **Create login**, or open **Users → Add user**.
3. Confirm username, email, and role/link.
4. Enter a one-off temporary password or leave it blank to use `DEFAULT_TEMP_PASSWORD`.
5. Give the user their username and temporary password through your normal secure communication channel.
6. On first login, the portal requires the user to choose a new password before any other page is accessible.

### v1.5.6 Season Class hotfix
This release fixes a PostgreSQL schema compatibility issue where the legacy `portal_seasonclass.division` column was intentionally retained after the field was removed from the active Django model, but the column no longer had a database default. New Season Class inserts could therefore fail with a server error. Migration `0008_v156_seasonclass_legacy_division_fix` restores a harmless blank default while preserving historical data.
