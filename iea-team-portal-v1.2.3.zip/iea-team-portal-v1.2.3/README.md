# Interscholastic Equestrian Team Portal — v1.2.2

> **v1.2.2 migration hotfix:** This release safely handles an existing `portal_rider.email` column during the v1.2 migration. If v1.2.0 failed with `DuplicateColumn`, install v1.2.2 normally; do not fake the migration or delete the column.

A private, self-hosted Django portal for an interscholastic equestrian program. v1.2.2 adds two-team season rosters, season-level rider classes, rider email, parent/guardian contacts, and a coach family directory while retaining the modernized competition and calendar experience from v1.1.

## Recommended server layout

Keep one permanent environment file outside the release directories:

```text
/opt/iea-team-portal/
├── .env
├── backups/
├── iea-team-portal-v1.1.0/
├── iea-team-portal-v1.2.2/
└── future releases...
```

`portalctl` automatically loads `/opt/iea-team-portal/.env` (or a `.env` in the parent directory if installed somewhere else). You do not need to copy secrets into each release.

## Upgrade from v1.1.0

First make a database backup:

```bash
cd /opt/iea-team-portal/iea-team-portal-v1.1.0
./portalctl exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" "$POSTGRES_DB"' > /opt/iea-team-portal/backups/pre-v1.2.2.sql
```

The database credentials are read inside the PostgreSQL container, so you do not need to export the `.env` values into your host shell.

Extract v1.2.2 next to v1.1.0:

```bash
cd /opt/iea-team-portal
unzip iea-team-portal-v1.2.2.zip
cd iea-team-portal-v1.2.2
```

Stop the old release so only one set of containers is using the stable project identity:

```bash
cd /opt/iea-team-portal/iea-team-portal-v1.1.0
./portalctl down
```

Start the new release:

```bash
cd /opt/iea-team-portal/iea-team-portal-v1.2.2
./portalctl up -d --build
```

The web container automatically applies Django migrations before Gunicorn starts. Verify:

```bash
./portalctl ps
./portalctl logs --tail=100 web
./portalctl exec web python manage.py check
```

Your existing host Apache/Nginx/Caddy reverse proxy continues to point to the same local application port (default `127.0.0.1:8088`). No host web-server change is required.

## Fresh install

Create the permanent environment file:

```bash
cd /opt/iea-team-portal
cp iea-team-portal-v1.2.2/.env.example .env
chmod 600 .env
nano .env
```

Typical production settings:

```ini
APP_PORT=8088
DJANGO_SECRET_KEY=replace-with-a-long-random-value
DJANGO_DEBUG=0
DJANGO_ALLOWED_HOSTS=team.example.com
DJANGO_CSRF_TRUSTED_ORIGINS=https://team.example.com
POSTGRES_DB=iea_team
POSTGRES_USER=iea_team
POSTGRES_PASSWORD=replace-with-a-long-random-value
POSTGRES_HOST=db
POSTGRES_PORT=5432
TIME_ZONE=America/New_York
SECURE_COOKIES=1
SECURE_HSTS_SECONDS=31536000
```

Start:

```bash
cd /opt/iea-team-portal/iea-team-portal-v1.2.2
./portalctl up -d --build
```

Bootstrap the first team, active season, and admin:

```bash
./portalctl exec web python manage.py bootstrap_team \
  --team "Your Equestrian Team" \
  --season "2026-2027" \
  --username coachadmin \
  --email coach@example.com \
  --password 'CHOOSE-A-STRONG-PASSWORD'
```

## v1.2 season workflow

1. Open **Season** in the coach navigation.
2. Add the season's IEA classes once. Each class can be Futures, Upper School, or available to both teams.
3. Open a rider and select **Season assignment**.
4. Assign Futures or Upper School and select that rider's classes for the season.
5. Create a show.
6. Add the season classes offered at that show. The show occurrence can have its own class number/order.
7. Add rider entries. The app rejects entries for classes the rider is not assigned for that season.
8. Enter result/horse/points after the show.

This keeps eligibility/class assignment at the season level while still allowing each show to have its own class schedule.

## Futures and Upper School

The application treats team placement as season history:

- **Futures Team:** normally grades 4–8
- **Upper School Team:** normally grades 9–12

When migrating existing records or creating a season membership, grade can suggest the correct team. Coaches can explicitly set the season team assignment, which remains the source of truth. A rider moving from grade 8 to grade 9 will therefore have Futures history in the old season and Upper School history in the new season.

## Rider and family information

Riders now include an email address in addition to school, grade, IEA number, biography and photo.

Parent/guardian contacts include:
- first and last name
- email
- phone
- relationship to the rider
- primary-contact flag
- internal notes
- optional linked portal login

Coaches can add a parent from the rider profile and view the coach-only **Parents** directory. Parent and rider users do not receive a team-wide parent directory.

## Reverse proxy

The Docker gateway binds to loopback only, so it does not conflict with a host web server already using ports 80/443.

### Nginx

```nginx
location / {
    proxy_pass http://127.0.0.1:8088;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

### Apache

```apache
ProxyPreserveHost On
RequestHeader set X-Forwarded-Proto "https"
ProxyPass        / http://127.0.0.1:8088/
ProxyPassReverse / http://127.0.0.1:8088/
```

### Caddy

```caddy
team.example.com {
    reverse_proxy 127.0.0.1:8088
}
```

## Common operations

```bash
./portalctl ps
./portalctl logs -f web
./portalctl restart web
./portalctl exec web python manage.py check
./portalctl exec web python manage.py migrate
```

## Backups

Create `/opt/iea-team-portal/backups` and back up PostgreSQL regularly. Also back up the persistent media volume containing rider photos and team artwork. Keep at least one backup outside the web server.

## Privacy

This portal is intended to hold information about minors and families. Keep it authenticated, use HTTPS, give accounts only the access they need, and avoid storing unnecessary sensitive data. Parent/guardian directory access is restricted to coaches/admins in the normal application UI.

## Branding

The UI is designed to be compatible with the IEA visual direction and uses IEA Primary Blue as the dominant accent. Official IEA logo files are not bundled. Upload only marks your team is authorized to use. The site identifies itself as a private team portal and not an official IEA website.

## v1.2.3 migration reconciliation

v1.2.3 hardens upgrades from installations where the physical PostgreSQL schema and Django's `django_migrations` table have become out of sync.

The web container now starts with:

```bash
python manage.py migrate --fake-initial --noinput
```

`--fake-initial` does **not** blindly mark every migration as complete. Django only fakes an initial migration when the tables/columns expected by that initial migration already exist. Normal later migrations still run.

Portal migrations 0002 and 0003 are also idempotent at the database layer, so partially-created competition, season-class, and guardian schema objects are reused rather than recreated.
