# IEA Team Portal v1.2.3

## Migration hardening release

This release fixes schema-drift failures where PostgreSQL objects already exist but Django's migration history does not fully reflect them.

### Changes

- Startup now runs `python manage.py migrate --fake-initial --noinput` so existing Django initial tables (including auth/contenttypes/admin/sessions and portal initial tables) are recognized instead of recreated.
- Reworked `portal.0002_competition_management` as an idempotent database migration. Existing Show, ShowClass, ShowEntry, and ShowResult tables/columns/constraints/indexes are reused safely.
- Retains the fully idempotent `portal.0003_team_levels_season_classes_guardians` migration from v1.2.2.
- Tightened 0003 constraint detection so checks are scoped to the actual target table, not just a schema-wide constraint name.
- No application data is intentionally deleted or reset by these migration changes.

### Upgrade

Stop the previous version, extract v1.2.3, and start it with `./portalctl up -d --build`. The persistent `.env`, PostgreSQL volume, media volume, and reverse proxy remain unchanged.
