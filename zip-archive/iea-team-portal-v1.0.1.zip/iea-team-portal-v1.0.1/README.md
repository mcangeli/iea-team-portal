# Interscholastic Equestrian Team Portal — v1.0.1

A private, self-hosted team portal for coaches, parents/guardians, and riders. Version 1 includes authentication, role-aware access, seasons, rider profiles and bios, announcements, and a team calendar foundation.

## What changed in v1.0.1

v1.0.1 is designed to run on a server that **already has Apache, Nginx, Caddy, or another web server using ports 80 and 443**. Docker no longer binds either public port.

The Docker gateway listens only on:

```text
127.0.0.1:8088
```

Your existing host web server terminates HTTPS and reverse-proxies the team site's hostname to that local address. The port can be changed with `APP_PORT` in `.env`.

## Important branding note

The visual theme uses IEA primary blue (#007297) and a restrained cyan accent (#00AEEF). This project is not an official IEA product. No IEA logo artwork is bundled. Upload only logos/marks your team is authorized to use.

## v1 features

- Django authentication with strong password validation
- Roles: Administrator, Coach, Parent/Guardian, Rider
- Team and active-season records
- Rider roster, photos, school/grade, IEA member number, and bios
- Per-season rider membership/history
- Parent accounts restricted to riders assigned to them
- Rider accounts restricted to their own profile
- Announcements with priority and expiration
- Team calendar for shows, lessons, meetings, deadlines, and events
- Coach/admin create tools
- Full Django Admin for deeper setup
- PostgreSQL and persistent Docker volumes
- Local-only Docker gateway suitable for an existing host web server

## Server requirements

- Linux server
- Docker Engine and Docker Compose plugin
- Existing web server on ports 80/443
- A hostname such as `team.example.com` configured in that existing web server
- Recommended: 2 GB RAM, 2 CPU cores, 10+ GB free disk

## 1. Put the application on the server

```bash
sudo mkdir -p /opt/iea-team-portal
sudo chown "$USER":"$USER" /opt/iea-team-portal
cd /opt/iea-team-portal
unzip iea-team-portal-v1.0.1.zip
cd iea-team-portal-v1.0.1
```

Verify Docker:

```bash
docker --version
docker compose version
```

## 2. Create the environment file

```bash
cp .env.example .env
```

Generate strong secrets:

```bash
openssl rand -base64 48
openssl rand -base64 36
```

Edit `.env`:

```bash
nano .env
```

Example:

```ini
APP_PORT=8088
DJANGO_SECRET_KEY=YOUR-LONG-RANDOM-SECRET
DJANGO_DEBUG=0
DJANGO_ALLOWED_HOSTS=team.example.com
DJANGO_CSRF_TRUSTED_ORIGINS=https://team.example.com
POSTGRES_DB=iea_team
POSTGRES_USER=iea_team
POSTGRES_PASSWORD=YOUR-LONG-RANDOM-DATABASE-PASSWORD
POSTGRES_HOST=db
POSTGRES_PORT=5432
TIME_ZONE=America/New_York
SECURE_COOKIES=1
SECURE_HSTS_SECONDS=31536000
```

`APP_PORT=8088` is bound to localhost only. If another local service already uses 8088, choose another unused port such as 8089 or 8090.

## 3. Start Docker

```bash
docker compose up -d --build
```

Check it:

```bash
docker compose ps
docker compose logs --tail=100 web
docker compose logs --tail=100 gateway
```

Test the local backend from the host:

```bash
curl -I http://127.0.0.1:8088/
```

A redirect to the login page or an HTTP response from Django confirms that the Docker side is reachable.

## 4. Configure your existing web server

Use only one of the following examples.

### Nginx

Add a server block for the team hostname:

```nginx
server {
    listen 80;
    server_name team.example.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name team.example.com;

    # Use your existing certificate configuration here.
    ssl_certificate     /path/to/fullchain.pem;
    ssl_certificate_key /path/to/privkey.pem;

    client_max_body_size 20M;

    location / {
        proxy_pass http://127.0.0.1:8088;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
    }
}
```

Then validate and reload:

```bash
sudo nginx -t
sudo systemctl reload nginx
```

### Apache 2.4

Enable the proxy modules if necessary:

```bash
sudo a2enmod proxy proxy_http headers ssl
```

Example HTTPS virtual host:

```apache
<VirtualHost *:443>
    ServerName team.example.com

    SSLEngine on
    SSLCertificateFile /path/to/fullchain.pem
    SSLCertificateKeyFile /path/to/privkey.pem

    ProxyPreserveHost On
    RequestHeader set X-Forwarded-Proto "https"
    RequestHeader set X-Forwarded-Host "%{HTTP_HOST}s"

    ProxyPass        / http://127.0.0.1:8088/
    ProxyPassReverse / http://127.0.0.1:8088/
</VirtualHost>
```

If your existing Apache/Certbot setup already creates the HTTP-to-HTTPS redirect, keep using it. Then validate and reload:

```bash
sudo apachectl configtest
sudo systemctl reload apache2
```

### Host Caddy

If your server already uses Caddy on ports 80/443:

```caddy
team.example.com {
    reverse_proxy 127.0.0.1:8088
}
```

Then reload your existing host Caddy configuration.

The outer web server must pass `Host` and `X-Forwarded-Proto: https`. The examples above do this.

## 5. Bootstrap the team and first administrator

Run once:

```bash
docker compose exec web python manage.py bootstrap_team \
  --team "My Equestrian Team" \
  --season "2026-2027" \
  --username coachadmin \
  --email coach@example.com \
  --password 'USE-A-STRONG-UNIQUE-PASSWORD'
```

Then browse to:

```text
https://team.example.com
```

Django administration is at:

```text
https://team.example.com/admin/
```

## Updating from v1.0.0

If v1.0.0 failed only because port 80 or 443 was already occupied, your database may already exist in Docker volumes. Back it up first if it contains any data.

Replace the v1.0.0 application files with v1.0.1 while keeping your existing `.env` values, then add:

```ini
APP_PORT=8088
```

`SITE_DOMAIN` is no longer needed by Docker in v1.0.1. It can be removed from `.env`.

Then run:

```bash
docker compose down
docker compose up -d --build
```

Finally configure your host web server to proxy `team.example.com` to `127.0.0.1:8088` using one of the examples above.

## Initial setup in Admin

1. Open **Teams** and optionally upload your authorized team logo.
2. Confirm the active **Season** dates.
3. Add user accounts under **Users**.
4. For each account, open **User profiles**, choose the team, and select a role.
5. Add riders. Optionally link a Rider to a rider User account.
6. For parent/guardian visibility, add the parent User to the rider's **guardians** field.
7. Add **Season memberships** to capture division/class progression.
8. Post announcements and calendar events from the normal site or Admin.

## Roles and privacy behavior

- **Administrator / Coach**: can see all team riders and create/edit riders, events, announcements.
- **Parent/Guardian**: sees only riders explicitly connected through the rider's Guardians field.
- **Rider**: sees only the Rider record linked to their User account.
- **Superuser**: full Django Admin access.

Do not store medical data, emergency documentation, waivers, or other highly sensitive youth records in v1.

## Backups

Database backup:

```bash
mkdir -p backups
docker compose exec -T db pg_dump -U iea_team iea_team > backups/iea-team-$(date +%F).sql
```

Media backup:

```bash
docker run --rm \
  -v iea-team-portal_media_data:/source:ro \
  -v "$PWD/backups":/backup \
  alpine tar czf /backup/media-$(date +%F).tgz -C /source .
```

The volume prefix can differ according to your Compose project name. Use `docker volume ls` to confirm it.

## Security notes

- Docker publishes the application only to `127.0.0.1`, not to the public network.
- PostgreSQL is not published to the host at all.
- Keep `.env` private and out of Git.
- Keep HTTPS termination on your existing web server.
- Keep the OS, Docker, and host web server patched.
- Use unique passwords and limit admin accounts.
- Keep off-server backups.

## Useful commands

```bash
# Status
docker compose ps

# Logs
docker compose logs -f --tail=100

# Restart
docker compose restart

# Stop
docker compose down

# Start
docker compose up -d

# Django shell
docker compose exec web python manage.py shell

# Create another superuser
docker compose exec web python manage.py createsuperuser
```

## Planned v1.x / v2 features

Show records, IEA classes, entries, results/points, lesson groups and attendance, ICS subscriptions, document library, email notifications, qualification tracking, and reporting.
