from django.urls import path
from . import views
urlpatterns=[
 path("",views.dashboard,name="dashboard"), path("riders/",views.rider_list,name="rider_list"),
 path("riders/add/",views.rider_create,name="rider_create"), path("riders/<int:pk>/",views.rider_detail,name="rider_detail"),
 path("riders/<int:pk>/edit/",views.rider_edit,name="rider_edit"), path("calendar/",views.calendar,name="calendar"),
 path("calendar/add/",views.event_create,name="event_create"), path("announcements/add/",views.announcement_create,name="announcement_create"),
]
