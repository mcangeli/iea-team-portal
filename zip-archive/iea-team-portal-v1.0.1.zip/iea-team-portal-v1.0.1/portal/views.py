from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from .forms import RiderForm, AnnouncementForm, CalendarEventForm
from .models import Announcement, CalendarEvent, Rider, Season, UserProfile

def _team(user):
    if user.is_superuser:
        return user.profile.team if hasattr(user,"profile") else None
    if not hasattr(user,"profile") or not user.profile.team: raise PermissionDenied("Your account is not assigned to a team.")
    return user.profile.team

def _can_manage(user):
    return user.is_superuser or (hasattr(user,"profile") and user.profile.role in [UserProfile.Role.ADMIN,UserProfile.Role.COACH])

def _require_manage(user):
    if not _can_manage(user): raise PermissionDenied

@login_required
def dashboard(request):
    team=_team(request.user)
    if not team: return render(request,"portal/no_team.html")
    season=team.seasons.filter(is_active=True).first()
    now=timezone.now()
    announcements=team.announcements.filter(published=True).filter(Q(expires_at__isnull=True)|Q(expires_at__gt=now))[:5]
    events=team.events.filter(starts_at__gte=now)[:8]
    riders=team.riders.filter(active=True)
    if hasattr(request.user,"profile") and request.user.profile.role==UserProfile.Role.PARENT:
        riders=riders.filter(guardians=request.user)
    elif hasattr(request.user,"profile") and request.user.profile.role==UserProfile.Role.RIDER:
        riders=riders.filter(user=request.user)
    return render(request,"portal/dashboard.html",{"season":season,"announcements":announcements,"events":events,"riders":riders,"can_manage":_can_manage(request.user)})

@login_required
def rider_list(request):
    team=_team(request.user); qs=team.riders.all()
    if hasattr(request.user,"profile") and request.user.profile.role==UserProfile.Role.PARENT: qs=qs.filter(guardians=request.user)
    elif hasattr(request.user,"profile") and request.user.profile.role==UserProfile.Role.RIDER: qs=qs.filter(user=request.user)
    return render(request,"portal/rider_list.html",{"riders":qs,"can_manage":_can_manage(request.user)})

@login_required
def rider_detail(request,pk):
    team=_team(request.user); rider=get_object_or_404(Rider,pk=pk,team=team)
    if not _can_manage(request.user):
        allowed=(rider.user_id==request.user.id or rider.guardians.filter(pk=request.user.pk).exists())
        if not allowed: raise PermissionDenied
    return render(request,"portal/rider_detail.html",{"rider":rider,"can_manage":_can_manage(request.user)})

@login_required
def rider_create(request):
    _require_manage(request.user); team=_team(request.user); form=RiderForm(request.POST or None,request.FILES or None)
    if form.is_valid():
        obj=form.save(commit=False); obj.team=team; obj.save(); messages.success(request,"Rider added."); return redirect("rider_detail",pk=obj.pk)
    return render(request,"portal/form.html",{"form":form,"title":"Add rider"})

@login_required
def rider_edit(request,pk):
    _require_manage(request.user); team=_team(request.user); obj=get_object_or_404(Rider,pk=pk,team=team); form=RiderForm(request.POST or None,request.FILES or None,instance=obj)
    if form.is_valid(): form.save(); messages.success(request,"Rider updated."); return redirect("rider_detail",pk=obj.pk)
    return render(request,"portal/form.html",{"form":form,"title":"Edit rider"})

@login_required
def calendar(request):
    team=_team(request.user); return render(request,"portal/calendar.html",{"events":team.events.all()[:100],"can_manage":_can_manage(request.user)})

@login_required
def event_create(request):
    _require_manage(request.user); team=_team(request.user); form=CalendarEventForm(request.POST or None)
    if form.is_valid():
        obj=form.save(commit=False); obj.team=team; obj.season=team.seasons.filter(is_active=True).first(); obj.save(); messages.success(request,"Calendar event added."); return redirect("calendar")
    return render(request,"portal/form.html",{"form":form,"title":"Add calendar event"})

@login_required
def announcement_create(request):
    _require_manage(request.user); team=_team(request.user); form=AnnouncementForm(request.POST or None)
    if form.is_valid():
        obj=form.save(commit=False); obj.team=team; obj.season=team.seasons.filter(is_active=True).first(); obj.created_by=request.user; obj.save(); messages.success(request,"Announcement posted."); return redirect("dashboard")
    return render(request,"portal/form.html",{"form":form,"title":"Post announcement"})
