from django import forms
from .models import Rider, Announcement, CalendarEvent
class DateTimeLocalInput(forms.DateTimeInput): input_type="datetime-local"
class RiderForm(forms.ModelForm):
    class Meta: model=Rider; fields=["first_name","last_name","preferred_name","school","grade","iea_member_number","bio","photo","active"]
class AnnouncementForm(forms.ModelForm):
    class Meta: model=Announcement; fields=["title","body","priority","published","expires_at"]; widgets={"expires_at":DateTimeLocalInput(format="%Y-%m-%dT%H:%M")}
class CalendarEventForm(forms.ModelForm):
    class Meta: model=CalendarEvent; fields=["title","kind","starts_at","ends_at","location","description","visible_to_all"]; widgets={"starts_at":DateTimeLocalInput(format="%Y-%m-%dT%H:%M"),"ends_at":DateTimeLocalInput(format="%Y-%m-%dT%H:%M")}
