from django.contrib.auth.models import User
from django.db import models
from django.utils import timezone

class Team(models.Model):
    name = models.CharField(max_length=150)
    short_name = models.CharField(max_length=60, blank=True)
    discipline = models.CharField(max_length=30, choices=[("hunt_seat","Hunt Seat"),("western","Western"),("dressage","Dressage"),("multi","Multi-discipline")], default="hunt_seat")
    website = models.URLField(blank=True)
    logo = models.ImageField(upload_to="team_logos/", blank=True, null=True, help_text="Use only a logo your team is authorized to display.")
    def __str__(self): return self.name

class Season(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="seasons")
    name = models.CharField(max_length=50, help_text="Example: 2026–2027")
    start_date = models.DateField(); end_date = models.DateField(); is_active = models.BooleanField(default=False)
    class Meta: ordering = ["-start_date"]
    def __str__(self): return f"{self.team} — {self.name}"

class UserProfile(models.Model):
    class Role(models.TextChoices):
        ADMIN="admin","Administrator"; COACH="coach","Coach"; PARENT="parent","Parent/Guardian"; RIDER="rider","Rider"
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")
    team = models.ForeignKey(Team, on_delete=models.SET_NULL, null=True, blank=True, related_name="user_profiles")
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.PARENT)
    phone = models.CharField(max_length=30, blank=True)
    def __str__(self): return f"{self.user.get_full_name() or self.user.username} ({self.get_role_display()})"

class Rider(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="riders")
    user = models.OneToOneField(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="rider_record")
    first_name = models.CharField(max_length=80); last_name = models.CharField(max_length=80)
    preferred_name = models.CharField(max_length=80, blank=True)
    school = models.CharField(max_length=150, blank=True); grade = models.PositiveSmallIntegerField(null=True, blank=True)
    iea_member_number = models.CharField(max_length=40, blank=True)
    bio = models.TextField(blank=True)
    photo = models.ImageField(upload_to="riders/", blank=True, null=True)
    active = models.BooleanField(default=True)
    guardians = models.ManyToManyField(User, blank=True, related_name="guardian_riders")
    class Meta: ordering = ["last_name","first_name"]
    @property
    def display_name(self): return self.preferred_name or self.first_name
    def __str__(self): return f"{self.first_name} {self.last_name}"

class SeasonMembership(models.Model):
    rider = models.ForeignKey(Rider, on_delete=models.CASCADE, related_name="memberships")
    season = models.ForeignKey(Season, on_delete=models.CASCADE, related_name="memberships")
    division = models.CharField(max_length=100, blank=True)
    class_level = models.CharField(max_length=100, blank=True)
    notes = models.TextField(blank=True)
    class Meta: constraints=[models.UniqueConstraint(fields=["rider","season"], name="unique_rider_season")]
    def __str__(self): return f"{self.rider} — {self.season.name}"

class Announcement(models.Model):
    class Priority(models.TextChoices): NORMAL="normal","Normal"; IMPORTANT="important","Important"; URGENT="urgent","Urgent"
    team=models.ForeignKey(Team,on_delete=models.CASCADE,related_name="announcements")
    season=models.ForeignKey(Season,on_delete=models.SET_NULL,null=True,blank=True,related_name="announcements")
    title=models.CharField(max_length=160); body=models.TextField(); priority=models.CharField(max_length=20,choices=Priority.choices,default=Priority.NORMAL)
    published=models.BooleanField(default=True); created_by=models.ForeignKey(User,on_delete=models.SET_NULL,null=True,blank=True)
    created_at=models.DateTimeField(auto_now_add=True); expires_at=models.DateTimeField(null=True,blank=True)
    class Meta: ordering=["-created_at"]
    @property
    def is_current(self): return self.published and (not self.expires_at or self.expires_at > timezone.now())

class CalendarEvent(models.Model):
    class Kind(models.TextChoices): SHOW="show","Show"; LESSON="lesson","Lesson"; MEETING="meeting","Meeting"; DEADLINE="deadline","Deadline"; SOCIAL="social","Social"; OTHER="other","Other"
    team=models.ForeignKey(Team,on_delete=models.CASCADE,related_name="events")
    season=models.ForeignKey(Season,on_delete=models.SET_NULL,null=True,blank=True,related_name="events")
    title=models.CharField(max_length=160); kind=models.CharField(max_length=20,choices=Kind.choices,default=Kind.OTHER)
    starts_at=models.DateTimeField(); ends_at=models.DateTimeField(null=True,blank=True); location=models.CharField(max_length=200,blank=True); description=models.TextField(blank=True)
    visible_to_all=models.BooleanField(default=True)
    class Meta: ordering=["starts_at"]
    def __str__(self): return self.title
