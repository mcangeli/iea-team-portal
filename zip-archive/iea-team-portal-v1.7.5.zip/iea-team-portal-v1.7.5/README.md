# IEA Team Portal v1.7.3

Private team operations portal for an IEA team.

## v1.7.0 — Season History & Reporting

This release turns the operational data accumulated by the portal into a long-term team history.

### Season archive and review
- Browse current and historical seasons.
- Season Review combines rider participation, points, wins, lesson attendance, volunteer hours, qualification progress, and team qualification totals.
- Administrators can close a season into the archive and reopen it when corrections are required.
- Closed seasons are removed from active-season workflows and key operational edits are blocked until reopened.

### Rider development history
- Private multi-season history for the rider, linked family, Coaches, and Administrators.
- Season-by-season points, shows, wins, lesson attendance, volunteer hours, awards, and coach development notes.
- Development notes can remain staff-only or be explicitly shared with the rider/family.

### Awards and recognition
- Record configurable rider awards for a season.
- Awards support descriptions, presentation dates, draft/unpublished status, and historical display.
- Published awards feed the team record book.

### Printable rider summaries
- Print-friendly end-of-season rider summary.
- Includes performance, qualification, volunteer/lesson participation, published awards, and family-visible coach comments.
- Clearly labeled as a team-maintained record, not an official IEA record.

### Team record book
- Historical top rider season point totals and wins from portal data.
- Published awards archive.
- Explicitly presented as team records rather than official IEA records.

### Points Secretary
The Secretary / Points Secretary committee assignment now has meaningful delegated competition access:
- detailed standings review,
- standings CSV export,
- result entry/correction,
- qualification override/review.
The role does not receive general Coach/Admin access, contact-directory access, lesson administration, user management, or scoring-rule administration.

### Privacy
v1.6 privacy rules remain intact. Rider development history and printable summaries are private to Coaches/Admins and the rider/linked family. A Points Secretary can work with competition records but does not gain unrelated rider personal information.

## Upgrade

```bash
cd /opt/iea-team-portal/iea-team-portal-v1.7.0
chmod +x portalctl
./portalctl upgrade
```

Then verify:

```bash
./portalctl exec web python manage.py showmigrations portal
./portalctl exec web python manage.py check
```

Expected latest portal migration:

```text
[X] 0011_v170_season_history_reporting
```


## v1.7.1 — Existing Guardian Linking

- Rider pages now provide separate actions to create a new parent/guardian or link an existing GuardianContact.
- One GuardianContact can be linked to multiple riders without duplicate contact records or logins.
- Linking an existing guardian preserves the existing account relationship and syncs the legacy rider guardian user link when applicable.
- Managers can unlink a guardian from one rider without deleting the GuardianContact or its login.
- No database migration is required.


## v1.7.2 — Validation & Calendar Editing

- Duplicate records now fail gracefully instead of surfacing raw database 500 errors in common create workflows.
- Season Classes, Lesson Groups, Committee assignments, Show Leads, and Rider Awards have contextual duplicate validation before save.
- A database integrity fallback catches remaining create-time constraint collisions and returns a friendly message.
- Existing manually-created calendar events can now be edited.
- Calendar entries synced from Shows or Lessons provide direct links to edit their source record so synchronization remains authoritative.
- No database migration is required.


## v1.7.3 — Rider Season Enrollment

- Rider creation now optionally enrolls the new rider into a season in the same workflow.
- The active season is preselected when available.
- Managers can choose Futures/Upper team level, season classes, and season-specific notes while creating the rider.
- Class choices dynamically follow the selected season and team level.
- The Rider remains a permanent person record; future years continue to use separate SeasonMembership records instead of recreating the rider.
- Existing Rider edit remains focused on permanent rider information; yearly assignments continue to use the Season Assignment workflow.
- No database migration is required.


## v1.7.5 — Navigation & Visual Refinement

- Keeps the simplified v1.7.4 navigation structure while substantially improving its presentation.
- Separates primary team navigation from utility/admin actions for clearer visual hierarchy.
- Dropdown menus now use refined spacing, labels, caret treatment, borders, and responsive behavior.
- Removes the rough appended v1.7.4 navigation CSS patch and consolidates the navigation styling into a coherent system.
- Refreshes the overall portal presentation with a restrained equestrian-club/editorial look:
  - deeper blue-green accents,
  - quieter neutral backgrounds,
  - more refined serif heading hierarchy,
  - lighter shadows and borders,
  - polished cards, buttons, tables, form controls, and flash messages.
- Mobile navigation is reorganized into a clean two-column layout that expands dropdown groups inline.
- No database migration is required.
