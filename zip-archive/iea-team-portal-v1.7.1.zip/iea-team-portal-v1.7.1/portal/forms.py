from django.core.exceptions import ValidationError
from django import forms
from django.db.models import Q
from .models import (
    Announcement, CalendarEvent, GuardianContact, Rider, RiderGuardian, SeasonClass,
    SeasonMembership, SeasonScoringConfig, QualificationOverride, Show, ShowClass, ShowEntry, ShowResult,
    LessonGroup, Lesson, LessonAttendance, ShowAvailability, VolunteerLog, Season, UserProfile,
    CommitteeAssignment, ShowLeadAssignment, ShowPlanningItem, RiderDevelopmentNote, RiderAward,
)


class DateTimeLocalInput(forms.DateTimeInput):
    input_type = "datetime-local"

class DateInput(forms.DateInput):
    input_type = "date"

class TimeInput(forms.TimeInput):
    input_type = "time"


class RiderForm(forms.ModelForm):
    class Meta:
        model = Rider
        fields = ["first_name", "last_name", "preferred_name", "email", "school", "grade", "iea_member_number", "bio", "photo", "active"]


class SeasonMembershipForm(forms.ModelForm):
    class Meta:
        model = SeasonMembership
        fields = ["team_level", "classes", "notes"]
        widgets = {"classes": forms.CheckboxSelectMultiple}

    def __init__(self, *args, season=None, **kwargs):
        super().__init__(*args, **kwargs)
        if season:
            self.fields["classes"].queryset = season.season_classes.filter(active=True)

    def clean(self):
        cleaned = super().clean()
        team_level = cleaned.get("team_level")
        classes = cleaned.get("classes")
        if team_level and classes:
            bad = classes.exclude(team_level__in=[team_level, SeasonClass.TeamLevel.BOTH])
            if bad.exists():
                self.add_error("classes", "Choose only classes available to this rider's Futures/Upper team.")
        return cleaned


class GuardianContactForm(forms.ModelForm):
    relationship = forms.CharField(max_length=50, required=False, initial="Parent")
    primary_contact = forms.BooleanField(required=False)

    class Meta:
        model = GuardianContact
        fields = ["first_name", "last_name", "email", "phone", "notes"]


class SeasonClassForm(forms.ModelForm):
    class Meta:
        model = SeasonClass
        fields = ["name", "team_level", "discipline", "sort_order", "active"]


class AnnouncementForm(forms.ModelForm):
    class Meta:
        model = Announcement
        fields = ["title", "body", "priority", "audience", "selected_users", "send_email", "published", "expires_at"]
        widgets = {
            "expires_at": DateTimeLocalInput(format="%Y-%m-%dT%H:%M"),
            "selected_users": forms.CheckboxSelectMultiple,
        }

    def __init__(self, *args, team=None, **kwargs):
        super().__init__(*args, **kwargs)
        if team:
            self.fields["selected_users"].queryset = self.fields["selected_users"].queryset.filter(profile__team=team, is_active=True).order_by("last_name", "first_name", "username")

    def clean(self):
        cleaned = super().clean()
        if cleaned.get("audience") == Announcement.Audience.SELECTED and not cleaned.get("selected_users"):
            self.add_error("selected_users", "Choose at least one user for a selected-user announcement.")
        return cleaned


class NotificationPreferenceForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ["email_announcements", "email_reminders"]


class CalendarEventForm(forms.ModelForm):
    class Meta:
        model = CalendarEvent
        fields = ["title", "kind", "starts_at", "ends_at", "all_day", "location", "description", "visible_to_all"]
        widgets = {"starts_at": DateTimeLocalInput(format="%Y-%m-%dT%H:%M"), "ends_at": DateTimeLocalInput(format="%Y-%m-%dT%H:%M")}


class ShowForm(forms.ModelForm):
    class Meta:
        model = Show
        fields = ["name", "show_date", "start_time", "venue", "address", "host_team", "iea_zone", "iea_region", "status", "entry_deadline", "notes"]
        widgets = {"show_date": DateInput(), "start_time": TimeInput(), "entry_deadline": DateInput()}


class ShowClassForm(forms.ModelForm):
    class Meta:
        model = ShowClass
        fields = ["season_class", "class_number", "sort_order"]

    def __init__(self, *args, show=None, **kwargs):
        super().__init__(*args, **kwargs)
        if show:
            used = show.classes.exclude(pk=getattr(self.instance, "pk", None)).values_list("season_class_id", flat=True)
            self.fields["season_class"].queryset = show.season.season_classes.filter(active=True).exclude(pk__in=used)


class ShowEntryForm(forms.ModelForm):
    class Meta:
        model = ShowEntry
        fields = ["show_class", "rider", "entry_type", "status", "notes"]

    def __init__(self, *args, show=None, team=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.show = show
        if show is not None:
            self.fields["show_class"].queryset = show.classes.select_related("season_class")
            riders = Rider.objects.filter(team=team, active=True, memberships__season=show.season)
            selected_class_id = self.data.get("show_class") if self.is_bound else getattr(self.instance, "show_class_id", None)
            if selected_class_id:
                try:
                    selected = show.classes.select_related("season_class").get(pk=selected_class_id)
                    if selected.season_class_id:
                        riders = riders.filter(memberships__season=show.season, memberships__classes=selected.season_class)
                        if selected.season_class.team_level != SeasonClass.TeamLevel.BOTH:
                            riders = riders.filter(memberships__team_level=selected.season_class.team_level)
                except (ShowClass.DoesNotExist, ValueError, TypeError):
                    pass
            self.fields["rider"].queryset = riders.distinct()

    def clean(self):
        cleaned = super().clean()
        show_class = cleaned.get("show_class")
        rider = cleaned.get("rider")
        if show_class and rider and self.show:
            entry = self.instance
            entry.show_class = show_class
            entry.rider = rider
            try:
                entry.clean()
            except ValidationError as exc:
                raise exc
        return cleaned


class ShowResultForm(forms.ModelForm):
    class Meta:
        model = ShowResult
        fields = ["place", "manual_points", "points", "horse_name", "notes"]

    def clean(self):
        cleaned = super().clean()
        if not cleaned.get("manual_points"):
            cleaned["points"] = None
        return cleaned


class SeasonScoringConfigForm(forms.ModelForm):
    class Meta:
        model = SeasonScoringConfig
        fields = [
            "first_points", "second_points", "third_points", "fourth_points",
            "fifth_points", "sixth_points", "individual_qualification_points",
            "team_qualification_points",
        ]


class QualificationOverrideForm(forms.ModelForm):
    class Meta:
        model = QualificationOverride
        fields = ["status", "notes"]


class LessonGroupForm(forms.ModelForm):
    class Meta:
        model = LessonGroup
        fields = ["name", "team_level", "coach", "riders", "default_location", "active"]
        widgets = {"riders": forms.CheckboxSelectMultiple}

    def __init__(self, *args, season=None, team=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.season = season
        if season:
            self.fields["riders"].queryset = Rider.objects.filter(team=season.team, active=True, memberships__season=season).distinct()
        if team:
            self.fields["coach"].queryset = self.fields["coach"].queryset.filter(profile__team=team, profile__role__in=["admin", "coach"])

    def clean(self):
        cleaned = super().clean()
        team_level = cleaned.get("team_level")
        riders = cleaned.get("riders")
        if team_level and team_level != LessonGroup.TeamLevel.BOTH and riders:
            season = self.season or (self.instance.season if self.instance and self.instance.pk else None)
            bad = riders.exclude(memberships__season=season, memberships__team_level=team_level) if season else riders
            if bad.exists():
                self.add_error("riders", "Choose only riders assigned to this lesson group's Futures/Upper team level.")
        return cleaned


class LessonForm(forms.ModelForm):
    recurrence_weeks = forms.IntegerField(min_value=1, max_value=26, initial=1, help_text="Create this lesson weekly for this many weeks.")

    class Meta:
        model = Lesson
        fields = ["group", "coach", "title", "starts_at", "ends_at", "location", "notes", "cancelled"]
        widgets = {
            "starts_at": DateTimeLocalInput(format="%Y-%m-%dT%H:%M"),
            "ends_at": DateTimeLocalInput(format="%Y-%m-%dT%H:%M"),
        }

    def __init__(self, *args, season=None, team=None, **kwargs):
        super().__init__(*args, **kwargs)
        if season:
            self.fields["group"].queryset = season.lesson_groups.filter(active=True)
        if team:
            self.fields["coach"].queryset = self.fields["coach"].queryset.filter(profile__team=team, profile__role__in=["admin", "coach"])
        if self.instance and self.instance.pk:
            self.fields.pop("recurrence_weeks", None)

    def clean(self):
        cleaned = super().clean()
        starts = cleaned.get("starts_at")
        ends = cleaned.get("ends_at")
        if starts and ends and ends <= starts:
            self.add_error("ends_at", "Lesson end time must be after the start time.")
        return cleaned


class LessonAttendanceForm(forms.ModelForm):
    class Meta:
        model = LessonAttendance
        fields = ["status", "horse_name", "notes"]


class ShowAvailabilityForm(forms.ModelForm):
    class Meta:
        model = ShowAvailability
        fields = ["status", "notes"]


class VolunteerLogForm(forms.ModelForm):
    class Meta:
        model = VolunteerLog
        fields = ["rider", "service_date", "hours", "category", "performed_by", "description"]
        widgets = {"service_date": DateInput()}

    def __init__(self, *args, team=None, season=None, visible_riders=None, **kwargs):
        super().__init__(*args, **kwargs)
        qs = Rider.objects.none()
        if visible_riders is not None:
            qs = visible_riders
        elif team:
            qs = Rider.objects.filter(team=team, active=True)
        if season:
            qs = qs.filter(memberships__season=season)
        self.fields["rider"].queryset = qs.distinct()


class VolunteerReviewForm(forms.ModelForm):
    class Meta:
        model = VolunteerLog
        fields = ["status", "coach_notes"]


class VolunteerRequirementForm(forms.ModelForm):
    class Meta:
        model = Season
        fields = ["futures_volunteer_hours_required", "upper_volunteer_hours_required"]
        labels = {
            "futures_volunteer_hours_required": "Futures required hours",
            "upper_volunteer_hours_required": "Upper School required hours",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["futures_volunteer_hours_required"].min_value = 0
        self.fields["upper_volunteer_hours_required"].min_value = 0

from django.conf import settings
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from .models import UserProfile


class UserOnboardingForm(forms.Form):
    first_name = forms.CharField(max_length=150)
    last_name = forms.CharField(max_length=150)
    email = forms.EmailField()
    username = forms.CharField(max_length=150)
    role = forms.ChoiceField(choices=UserProfile.Role.choices)
    rider = forms.ModelChoiceField(queryset=Rider.objects.none(), required=False, help_text="Required for Rider accounts.")
    guardian = forms.ModelChoiceField(queryset=GuardianContact.objects.none(), required=False, help_text="Required for Parent accounts; optional for Coach/Administrator accounts who are also a parent/guardian.")
    temporary_password = forms.CharField(
        required=False,
        widget=forms.PasswordInput(render_value=False),
        help_text="Leave blank to use DEFAULT_TEMP_PASSWORD from the server environment.",
    )

    def __init__(self, *args, team=None, actor=None, initial_rider=None, initial_guardian=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.team = team
        self.actor = actor
        self.fields["rider"].queryset = Rider.objects.filter(team=team, user__isnull=True).order_by("last_name", "first_name") if team else Rider.objects.none()
        self.fields["guardian"].queryset = GuardianContact.objects.filter(team=team, user__isnull=True).order_by("last_name", "first_name") if team else GuardianContact.objects.none()
        if initial_rider:
            self.fields["rider"].initial = initial_rider
            self.fields["first_name"].initial = initial_rider.first_name
            self.fields["last_name"].initial = initial_rider.last_name
            self.fields["email"].initial = initial_rider.email
            self.fields["role"].initial = UserProfile.Role.RIDER
            self.fields["username"].initial = f"{initial_rider.first_name}.{initial_rider.last_name}".lower().replace(" ", "")
        if initial_guardian:
            self.fields["guardian"].initial = initial_guardian
            self.fields["first_name"].initial = initial_guardian.first_name
            self.fields["last_name"].initial = initial_guardian.last_name
            self.fields["email"].initial = initial_guardian.email
            self.fields["role"].initial = UserProfile.Role.PARENT
            self.fields["username"].initial = f"{initial_guardian.first_name}.{initial_guardian.last_name}".lower().replace(" ", "")
        if actor and not (actor.is_superuser or (hasattr(actor, "profile") and actor.profile.role == UserProfile.Role.ADMIN)):
            self.fields["role"].choices = [
                (UserProfile.Role.PARENT, "Parent/Guardian"),
                (UserProfile.Role.RIDER, "Rider"),
            ]

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        if User.objects.filter(username__iexact=username).exists():
            raise forms.ValidationError("That username is already in use.")
        return username

    def clean(self):
        cleaned = super().clean()
        role = cleaned.get("role")
        rider = cleaned.get("rider")
        guardian = cleaned.get("guardian")
        if role == UserProfile.Role.RIDER and not rider:
            self.add_error("rider", "Choose the rider this login belongs to.")
        if role == UserProfile.Role.PARENT and not guardian:
            self.add_error("guardian", "Choose the parent/guardian this login belongs to.")
        if role != UserProfile.Role.RIDER and rider:
            self.add_error("rider", "A rider link can only be used with the Rider role.")
        if role == UserProfile.Role.RIDER and guardian:
            self.add_error("guardian", "A Rider login cannot also be linked as a parent/guardian. Staff accounts may also be linked as guardians.")
        if role in {UserProfile.Role.ADMIN, UserProfile.Role.COACH}:
            is_admin_actor = self.actor and (self.actor.is_superuser or (hasattr(self.actor, "profile") and self.actor.profile.role == UserProfile.Role.ADMIN))
            if not is_admin_actor:
                self.add_error("role", "Only administrators can create Coach or Administrator accounts.")
        temp = cleaned.get("temporary_password") or settings.DEFAULT_TEMP_PASSWORD
        if not temp:
            self.add_error("temporary_password", "Enter a temporary password or configure DEFAULT_TEMP_PASSWORD on the server.")
        else:
            candidate = User(username=cleaned.get("username", ""), first_name=cleaned.get("first_name", ""), last_name=cleaned.get("last_name", ""), email=cleaned.get("email", ""))
            try:
                validate_password(temp, user=candidate)
            except ValidationError as exc:
                self.add_error("temporary_password", exc)
            cleaned["resolved_password"] = temp
        return cleaned

    def save(self):
        data = self.cleaned_data
        user = User.objects.create_user(
            username=data["username"], email=data["email"], password=data["resolved_password"],
            first_name=data["first_name"], last_name=data["last_name"],
        )
        profile = user.profile
        profile.team = self.team
        profile.role = data["role"]
        profile.must_change_password = True
        profile.save(update_fields=["team", "role", "must_change_password"])
        rider = data.get("rider")
        guardian = data.get("guardian")
        if rider:
            rider.user = user
            if not rider.email:
                rider.email = user.email
            rider.save(update_fields=["user", "email"])
        if guardian:
            guardian.user = user
            if not guardian.email:
                guardian.email = user.email
            guardian.save(update_fields=["user", "email"])
            for link in guardian.rider_links.select_related("rider").all():
                link.rider.guardians.add(user)
        return user


class UserAccountEditForm(forms.Form):
    first_name = forms.CharField(max_length=150)
    last_name = forms.CharField(max_length=150)
    email = forms.EmailField()
    role = forms.ChoiceField(choices=UserProfile.Role.choices)
    is_active = forms.BooleanField(required=False)
    rider = forms.ModelChoiceField(queryset=Rider.objects.none(), required=False)
    guardian = forms.ModelChoiceField(queryset=GuardianContact.objects.none(), required=False, help_text="Optional for Coach/Administrator accounts who are also a parent/guardian.")

    def __init__(self, *args, team=None, actor=None, user_obj=None, **kwargs):
        self.team = team; self.actor = actor; self.user_obj = user_obj
        initial = kwargs.setdefault("initial", {})
        if user_obj:
            initial.update({"first_name": user_obj.first_name, "last_name": user_obj.last_name, "email": user_obj.email,
                            "role": user_obj.profile.role, "is_active": user_obj.is_active,
                            "rider": getattr(getattr(user_obj, "rider_record", None), "pk", None),
                            "guardian": getattr(getattr(user_obj, "guardian_contact", None), "pk", None)})
        super().__init__(*args, **kwargs)
        rider_qs = Rider.objects.filter(team=team).filter(Q(user__isnull=True) | Q(user=user_obj)).order_by("last_name", "first_name") if team else Rider.objects.none()
        guardian_qs = GuardianContact.objects.filter(team=team).filter(Q(user__isnull=True) | Q(user=user_obj)).order_by("last_name", "first_name") if team else GuardianContact.objects.none()
        self.fields["rider"].queryset = rider_qs
        self.fields["guardian"].queryset = guardian_qs
        if actor and not (actor.is_superuser or (hasattr(actor, "profile") and actor.profile.role == UserProfile.Role.ADMIN)):
            self.fields["role"].choices = [(UserProfile.Role.PARENT, "Parent/Guardian"), (UserProfile.Role.RIDER, "Rider")]

    def clean(self):
        cleaned = super().clean(); role = cleaned.get("role")
        if self.user_obj and self.user_obj == self.actor and not cleaned.get("is_active"):
            self.add_error("is_active", "You cannot deactivate your own account.")
        if role == UserProfile.Role.RIDER and not cleaned.get("rider"):
            self.add_error("rider", "Choose the linked rider.")
        if role == UserProfile.Role.PARENT and not cleaned.get("guardian"):
            self.add_error("guardian", "Choose the linked parent/guardian.")
        if role != UserProfile.Role.RIDER and cleaned.get("rider"):
            self.add_error("rider", "Rider links require the Rider role.")
        if role == UserProfile.Role.RIDER and cleaned.get("guardian"):
            self.add_error("guardian", "A Rider login cannot also be linked as a parent/guardian. Staff accounts may also be linked as guardians.")
        if role in {UserProfile.Role.ADMIN, UserProfile.Role.COACH}:
            is_admin_actor = self.actor and (self.actor.is_superuser or (hasattr(self.actor, "profile") and self.actor.profile.role == UserProfile.Role.ADMIN))
            if not is_admin_actor:
                self.add_error("role", "Only administrators can assign Coach or Administrator roles.")
        return cleaned

    def save(self):
        data=self.cleaned_data; user=self.user_obj
        old_rider = getattr(user, "rider_record", None); old_guardian = getattr(user, "guardian_contact", None)
        if old_rider and old_rider != data.get("rider"):
            old_rider.user = None; old_rider.save(update_fields=["user"])
        if old_guardian and old_guardian != data.get("guardian"):
            for link in old_guardian.rider_links.select_related("rider").all():
                link.rider.guardians.remove(user)
            old_guardian.user = None; old_guardian.save(update_fields=["user"])
        user.first_name=data["first_name"]; user.last_name=data["last_name"]; user.email=data["email"]; user.is_active=data["is_active"]; user.save()
        user.profile.role=data["role"]; user.profile.team=self.team; user.profile.save(update_fields=["role", "team"])
        if data.get("rider"):
            data["rider"].user=user; data["rider"].save(update_fields=["user"])
        if data.get("guardian"):
            data["guardian"].user=user; data["guardian"].save(update_fields=["user"])
            for link in data["guardian"].rider_links.select_related("rider").all(): link.rider.guardians.add(user)
        return user


class TemporaryPasswordResetForm(forms.Form):
    temporary_password = forms.CharField(required=False, widget=forms.PasswordInput(render_value=False), help_text="Leave blank to use DEFAULT_TEMP_PASSWORD.")

    def __init__(self, *args, user_obj=None, **kwargs):
        super().__init__(*args, **kwargs); self.user_obj=user_obj

    def clean(self):
        cleaned=super().clean(); temp=cleaned.get("temporary_password") or settings.DEFAULT_TEMP_PASSWORD
        if not temp:
            self.add_error("temporary_password", "Enter a temporary password or configure DEFAULT_TEMP_PASSWORD.")
        else:
            try: validate_password(temp, user=self.user_obj)
            except ValidationError as exc: self.add_error("temporary_password", exc)
            cleaned["resolved_password"] = temp
        return cleaned


class CommitteeAssignmentForm(forms.ModelForm):
    class Meta:
        model = CommitteeAssignment
        fields = ["user", "role", "active", "notes"]

    def __init__(self, *args, team=None, **kwargs):
        super().__init__(*args, **kwargs)
        if team:
            self.fields["user"].queryset = User.objects.filter(
                Q(profile__team=team, profile__role=UserProfile.Role.PARENT) | Q(profile__team=team, guardian_contact__isnull=False),
                is_active=True,
            ).distinct().order_by("last_name", "first_name", "username")


class ShowLeadAssignmentForm(forms.ModelForm):
    class Meta:
        model = ShowLeadAssignment
        fields = ["user", "active", "notes"]

    def __init__(self, *args, team=None, **kwargs):
        super().__init__(*args, **kwargs)
        if team:
            self.fields["user"].queryset = User.objects.filter(
                Q(profile__team=team, profile__role=UserProfile.Role.PARENT) | Q(profile__team=team, guardian_contact__isnull=False),
                is_active=True,
            ).distinct().order_by("last_name", "first_name", "username")


class ShowPlanningItemForm(forms.ModelForm):
    class Meta:
        model = ShowPlanningItem
        fields = ["category", "title", "quantity", "details", "assigned_to", "completed", "family_visible", "sort_order"]

    def __init__(self, *args, team=None, **kwargs):
        super().__init__(*args, **kwargs)
        if team:
            self.fields["assigned_to"].queryset = User.objects.filter(
                profile__team=team, is_active=True
            ).order_by("last_name", "first_name", "username")


class RiderDevelopmentNoteForm(forms.ModelForm):
    class Meta:
        model = RiderDevelopmentNote
        fields = ["note", "family_visible"]
        widgets = {"note": forms.Textarea(attrs={"rows": 5})}


class RiderAwardForm(forms.ModelForm):
    class Meta:
        model = RiderAward
        fields = ["rider", "title", "description", "presentation_date", "published"]
        widgets = {"presentation_date": DateInput()}

    def __init__(self, *args, season=None, **kwargs):
        super().__init__(*args, **kwargs)
        if season:
            self.fields["rider"].queryset = Rider.objects.filter(
                season_memberships__season=season, active=True
            ).distinct().order_by("last_name", "first_name")
