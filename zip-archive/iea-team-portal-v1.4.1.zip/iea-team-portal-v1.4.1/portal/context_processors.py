from django.conf import settings


def portal_context(request):
    team = None
    role = None
    can_manage = False
    if request.user.is_authenticated:
        can_manage = request.user.is_superuser
        if hasattr(request.user, "profile"):
            team = request.user.profile.team
            role = request.user.profile.role
            can_manage = can_manage or role in {"admin", "coach"}
    return {
        "portal_team": team,
        "portal_role": role,
        "portal_can_manage": can_manage,
        "site_version": settings.SITE_VERSION,
    }
