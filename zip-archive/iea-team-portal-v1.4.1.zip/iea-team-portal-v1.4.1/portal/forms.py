from django.core.exceptions import ValidationError
from django import forms
from .models import (
    Announcement, CalendarEvent, GuardianContact, Rider, RiderGuardian, SeasonClass,
    SeasonMembership, SeasonScoringConfig, QualificationOverride, Show, ShowClass, ShowEntry, ShowResult,
)


class DateTimeLocalInput(forms.DateTimeInput):
    input_type = "datetime-local"

class DateInput(forms.DateInput):
    input_type = "date"

class TimeInput(forms.TimeInput):
    input_type = "time"


class RiderForm(forms.ModelForm):
    class Meta:
        model = Rider
        fields = ["first_name", "last_name", "preferred_name", "email", "school", "grade", "iea_member_number", "bio", "photo", "active"]


class SeasonMembershipForm(forms.ModelForm):
    class Meta:
        model = SeasonMembership
        fields = ["team_level", "classes", "notes"]
        widgets = {"classes": forms.CheckboxSelectMultiple}

    def __init__(self, *args, season=None, **kwargs):
        super().__init__(*args, **kwargs)
        if season:
            self.fields["classes"].queryset = season.season_classes.filter(active=True)

    def clean(self):
        cleaned = super().clean()
        team_level = cleaned.get("team_level")
        classes = cleaned.get("classes")
        if team_level and classes:
            bad = classes.exclude(team_level__in=[team_level, SeasonClass.TeamLevel.BOTH])
            if bad.exists():
                self.add_error("classes", "Choose only classes available to this rider's Futures/Upper team.")
        return cleaned


class GuardianContactForm(forms.ModelForm):
    relationship = forms.CharField(max_length=50, required=False, initial="Parent")
    primary_contact = forms.BooleanField(required=False)

    class Meta:
        model = GuardianContact
        fields = ["first_name", "last_name", "email", "phone", "notes"]


class SeasonClassForm(forms.ModelForm):
    class Meta:
        model = SeasonClass
        fields = ["name", "team_level", "discipline", "sort_order", "active"]


class AnnouncementForm(forms.ModelForm):
    class Meta:
        model = Announcement
        fields = ["title", "body", "priority", "published", "expires_at"]
        widgets = {"expires_at": DateTimeLocalInput(format="%Y-%m-%dT%H:%M")}


class CalendarEventForm(forms.ModelForm):
    class Meta:
        model = CalendarEvent
        fields = ["title", "kind", "starts_at", "ends_at", "all_day", "location", "description", "visible_to_all"]
        widgets = {"starts_at": DateTimeLocalInput(format="%Y-%m-%dT%H:%M"), "ends_at": DateTimeLocalInput(format="%Y-%m-%dT%H:%M")}


class ShowForm(forms.ModelForm):
    class Meta:
        model = Show
        fields = ["name", "show_date", "start_time", "venue", "address", "host_team", "iea_zone", "iea_region", "status", "entry_deadline", "notes"]
        widgets = {"show_date": DateInput(), "start_time": TimeInput(), "entry_deadline": DateInput()}


class ShowClassForm(forms.ModelForm):
    class Meta:
        model = ShowClass
        fields = ["season_class", "class_number", "sort_order"]

    def __init__(self, *args, show=None, **kwargs):
        super().__init__(*args, **kwargs)
        if show:
            used = show.classes.exclude(pk=getattr(self.instance, "pk", None)).values_list("season_class_id", flat=True)
            self.fields["season_class"].queryset = show.season.season_classes.filter(active=True).exclude(pk__in=used)


class ShowEntryForm(forms.ModelForm):
    class Meta:
        model = ShowEntry
        fields = ["show_class", "rider", "entry_type", "status", "notes"]

    def __init__(self, *args, show=None, team=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.show = show
        if show is not None:
            self.fields["show_class"].queryset = show.classes.select_related("season_class")
            riders = Rider.objects.filter(team=team, active=True, memberships__season=show.season)
            selected_class_id = self.data.get("show_class") if self.is_bound else getattr(self.instance, "show_class_id", None)
            if selected_class_id:
                try:
                    selected = show.classes.select_related("season_class").get(pk=selected_class_id)
                    if selected.season_class_id:
                        riders = riders.filter(memberships__season=show.season, memberships__classes=selected.season_class)
                        if selected.season_class.team_level != SeasonClass.TeamLevel.BOTH:
                            riders = riders.filter(memberships__team_level=selected.season_class.team_level)
                except (ShowClass.DoesNotExist, ValueError, TypeError):
                    pass
            self.fields["rider"].queryset = riders.distinct()

    def clean(self):
        cleaned = super().clean()
        show_class = cleaned.get("show_class")
        rider = cleaned.get("rider")
        if show_class and rider and self.show:
            entry = self.instance
            entry.show_class = show_class
            entry.rider = rider
            try:
                entry.clean()
            except ValidationError as exc:
                raise exc
        return cleaned


class ShowResultForm(forms.ModelForm):
    class Meta:
        model = ShowResult
        fields = ["place", "manual_points", "points", "horse_name", "notes"]

    def clean(self):
        cleaned = super().clean()
        if not cleaned.get("manual_points"):
            cleaned["points"] = None
        return cleaned


class SeasonScoringConfigForm(forms.ModelForm):
    class Meta:
        model = SeasonScoringConfig
        fields = [
            "first_points", "second_points", "third_points", "fourth_points",
            "fifth_points", "sixth_points", "individual_qualification_points",
            "team_qualification_points",
        ]


class QualificationOverrideForm(forms.ModelForm):
    class Meta:
        model = QualificationOverride
        fields = ["status", "notes"]
