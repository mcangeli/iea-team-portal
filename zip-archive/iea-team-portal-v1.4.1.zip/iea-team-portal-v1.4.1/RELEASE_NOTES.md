# IEA Team Portal v1.4.1

## Privacy & Interface Polish

### Points-rider privacy
- Points-rider designations are visible only to Admin and Coach users.
- Rider and Parent/Guardian users no longer see the Point rider column or point-rider badges on show pages.
- Rider and Parent/Guardian standings still show team points and the classes that contributed, but do not identify the designated points rider.
- The detailed standings CSV is now restricted server-side to Admin/Coach users; hiding the button is no longer the only protection.
- Coach/Admin points-rider controls and team-scoring audit details remain unchanged.

### Site version display
- The active release version is displayed in the footer on every page.
- The value is read directly from the top-level `VERSION` file through Django settings/context, so future releases only need to update `VERSION`.

### Streamlined visual system
- Darker navy/teal IEA-inspired palette with a deeper application header/hero treatment.
- Reduced navigation, card, table, section, and form spacing for a more efficient desktop layout.
- Smaller radii and subtler shadows for a cleaner operational feel.
- More compact show rosters and standings tables while preserving mobile responsiveness.
- Darker theme-color metadata for browsers/mobile chrome.

## Database / deployment
- No database schema changes in v1.4.1.
- No new migration is required beyond `0005_v140_points_qualification`.
- Persistent `.env`, PostgreSQL/media volumes, reverse proxy, preflight, backup, and automatic migration workflow remain unchanged.
