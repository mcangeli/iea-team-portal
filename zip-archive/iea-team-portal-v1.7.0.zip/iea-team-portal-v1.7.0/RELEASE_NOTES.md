# IEA Team Portal v1.7.0 — Season History & Reporting

## Added
- Season archive and Season Review workspace.
- Administrator close/reopen season workflow.
- Rider Development History across seasons.
- Staff-only or family-visible rider development notes.
- Awards & Recognition.
- Printable end-of-season rider summaries.
- Team record book with historical season point totals, wins, and published awards.
- Delegated Points Secretary access for results, detailed standings, qualification review, and standings export.

## Privacy
Competition-reporting delegation does not expose rider contact details or unrelated private operational information. Rider history remains limited to staff and the rider/linked family.

## Database
Adds `0011_v170_season_history_reporting`:
- `Season.is_closed`
- `Season.closed_at`
- `RiderDevelopmentNote`
- `RiderAward`

## Upgrade
`./portalctl upgrade` creates the normal pre-upgrade database backup before applying the release.
