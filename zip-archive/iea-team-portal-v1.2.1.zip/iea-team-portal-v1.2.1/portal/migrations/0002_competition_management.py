from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [("portal", "0001_initial")]

    operations = [
        migrations.CreateModel(
            name="Show",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=180)),
                ("show_date", models.DateField()),
                ("start_time", models.TimeField(blank=True, null=True)),
                ("venue", models.CharField(blank=True, max_length=180)),
                ("address", models.CharField(blank=True, max_length=255)),
                ("host_team", models.CharField(blank=True, max_length=180)),
                ("iea_zone", models.CharField(blank=True, max_length=40)),
                ("iea_region", models.CharField(blank=True, max_length=40)),
                ("status", models.CharField(choices=[("planning", "Planning"), ("registration", "Registration open"), ("entered", "Entries submitted"), ("complete", "Complete"), ("cancelled", "Cancelled")], default="planning", max_length=20)),
                ("entry_deadline", models.DateField(blank=True, null=True)),
                ("notes", models.TextField(blank=True)),
                ("season", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="shows", to="portal.season")),
                ("team", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="shows", to="portal.team")),
            ],
            options={"ordering": ["show_date", "name"]},
        ),
        migrations.CreateModel(
            name="ShowClass",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=160)),
                ("division", models.CharField(blank=True, max_length=120)),
                ("discipline", models.CharField(choices=[("hunt_seat", "Hunt Seat"), ("western", "Western"), ("dressage", "Dressage"), ("other", "Other")], default="hunt_seat", max_length=30)),
                ("class_number", models.CharField(blank=True, max_length=30)),
                ("sort_order", models.PositiveIntegerField(default=0)),
                ("show", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="classes", to="portal.show")),
            ],
            options={"ordering": ["sort_order", "class_number", "name"]},
        ),
        migrations.CreateModel(
            name="ShowEntry",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("entry_type", models.CharField(choices=[("individual", "Individual"), ("team", "Team"), ("both", "Individual + Team")], default="individual", max_length=20)),
                ("is_point_rider", models.BooleanField(default=False)),
                ("status", models.CharField(choices=[("planned", "Planned"), ("entered", "Entered"), ("scratched", "Scratched")], default="planned", max_length=20)),
                ("notes", models.CharField(blank=True, max_length=255)),
                ("rider", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="show_entries", to="portal.rider")),
                ("show_class", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="entries", to="portal.showclass")),
            ],
            options={"ordering": ["show_class", "rider__last_name", "rider__first_name"]},
        ),
        migrations.CreateModel(
            name="ShowResult",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("place", models.PositiveSmallIntegerField(blank=True, null=True)),
                ("points", models.DecimalField(blank=True, decimal_places=1, max_digits=5, null=True)),
                ("horse_name", models.CharField(blank=True, max_length=100)),
                ("notes", models.TextField(blank=True)),
                ("entry", models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name="result", to="portal.showentry")),
            ],
        ),
        migrations.AddConstraint(
            model_name="showentry",
            constraint=models.UniqueConstraint(fields=("show_class", "rider"), name="unique_rider_show_class"),
        ),
    ]
