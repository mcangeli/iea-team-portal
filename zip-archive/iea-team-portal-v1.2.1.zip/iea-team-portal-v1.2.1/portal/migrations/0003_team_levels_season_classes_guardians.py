from django.db import migrations, models
import django.db.models.deletion


def forward_data(apps, schema_editor):
    Rider = apps.get_model('portal', 'Rider')
    SeasonMembership = apps.get_model('portal', 'SeasonMembership')
    SeasonClass = apps.get_model('portal', 'SeasonClass')
    ShowClass = apps.get_model('portal', 'ShowClass')
    GuardianContact = apps.get_model('portal', 'GuardianContact')
    RiderGuardian = apps.get_model('portal', 'RiderGuardian')

    # Preserve an existing rider login email as the rider contact email.
    for rider in Rider.objects.select_related('user').all():
        if rider.user_id and rider.user.email and not rider.email:
            rider.email = rider.user.email
            rider.save(update_fields=['email'])

    # Infer team level from current grade where possible.
    for membership in SeasonMembership.objects.select_related('rider').all():
        grade = membership.rider.grade
        if grade and 4 <= grade <= 8:
            membership.team_level = 'futures'
        elif grade and 9 <= grade <= 12:
            membership.team_level = 'upper'
        membership.save(update_fields=['team_level'])

    # Convert existing show-specific class names into a season catalog, and link
    # every existing entry's rider to the corresponding season class.
    for show_class in ShowClass.objects.select_related('show__season').all():
        sc, _ = SeasonClass.objects.get_or_create(
            season=show_class.show.season,
            name=show_class.name,
            team_level='both',
            defaults={
                'division': show_class.division,
                'discipline': show_class.discipline,
                'sort_order': show_class.sort_order,
                'active': True,
            },
        )
        show_class.season_class = sc
        show_class.save(update_fields=['season_class'])
        for entry in show_class.entries.select_related('rider').all():
            membership, _ = SeasonMembership.objects.get_or_create(
                rider=entry.rider,
                season=show_class.show.season,
                defaults={'team_level': 'futures' if entry.rider.grade and entry.rider.grade <= 8 else 'upper' if entry.rider.grade and entry.rider.grade >= 9 else ''},
            )
            membership.classes.add(sc)

    # Preserve existing parent login relationships as richer contact records.
    for rider in Rider.objects.all():
        for user in rider.guardians.all():
            contact, _ = GuardianContact.objects.get_or_create(
                user=user,
                defaults={
                    'team_id': rider.team_id,
                    'first_name': user.first_name or user.username,
                    'last_name': user.last_name or '',
                    'email': user.email or '',
                },
            )
            RiderGuardian.objects.get_or_create(rider=rider, guardian=contact, defaults={'relationship': 'Parent/Guardian'})


class Migration(migrations.Migration):
    dependencies = [('portal', '0002_competition_management')]

    operations = [
        # Keep Django migration state in sync while tolerating databases where
        # portal_rider.email was already created before this migration ran.
        # PostgreSQL's IF NOT EXISTS makes this safe for both fresh and upgraded
        # installations without requiring --fake or destructive schema changes.
        migrations.SeparateDatabaseAndState(
            database_operations=[
                migrations.RunSQL(
                    sql="""
                        ALTER TABLE portal_rider
                        ADD COLUMN IF NOT EXISTS email varchar(254) NOT NULL DEFAULT '';
                        ALTER TABLE portal_rider
                        ALTER COLUMN email DROP DEFAULT;
                    """,
                    reverse_sql=migrations.RunSQL.noop,
                ),
            ],
            state_operations=[
                migrations.AddField(
                    model_name='rider',
                    name='email',
                    field=models.EmailField(blank=True, max_length=254),
                ),
            ],
        ),
        migrations.CreateModel(
            name='GuardianContact',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('first_name', models.CharField(max_length=80)),
                ('last_name', models.CharField(max_length=80)),
                ('email', models.EmailField(blank=True, max_length=254)),
                ('phone', models.CharField(blank=True, max_length=30)),
                ('notes', models.TextField(blank=True)),
                ('team', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='guardian_contacts', to='portal.team')),
                ('user', models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='guardian_contact', to='auth.user')),
            ],
            options={'ordering': ['last_name', 'first_name']},
        ),
        migrations.CreateModel(
            name='SeasonClass',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=160)),
                ('team_level', models.CharField(choices=[('futures', 'Futures Team'), ('upper', 'Upper School Team'), ('both', 'Both teams')], default='both', max_length=20)),
                ('division', models.CharField(blank=True, max_length=120)),
                ('discipline', models.CharField(choices=[('hunt_seat', 'Hunt Seat'), ('western', 'Western'), ('dressage', 'Dressage'), ('other', 'Other')], default='hunt_seat', max_length=30)),
                ('sort_order', models.PositiveIntegerField(default=0)),
                ('active', models.BooleanField(default=True)),
                ('season', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='season_classes', to='portal.season')),
            ],
            options={'ordering': ['team_level', 'sort_order', 'name']},
        ),
        migrations.AddConstraint(
            model_name='seasonclass',
            constraint=models.UniqueConstraint(fields=('season', 'name', 'team_level'), name='unique_season_class_by_team'),
        ),
        migrations.AddField(
            model_name='seasonmembership',
            name='team_level',
            field=models.CharField(blank=True, choices=[('futures', 'Futures Team'), ('upper', 'Upper School Team')], max_length=20),
        ),
        migrations.AddField(
            model_name='seasonmembership',
            name='classes',
            field=models.ManyToManyField(blank=True, related_name='rider_memberships', to='portal.seasonclass'),
        ),
        migrations.AddField(
            model_name='showclass',
            name='season_class',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='show_classes', to='portal.seasonclass'),
        ),
        migrations.CreateModel(
            name='RiderGuardian',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('relationship', models.CharField(blank=True, help_text='Example: Parent, Mother, Father, Guardian', max_length=50)),
                ('primary_contact', models.BooleanField(default=False)),
                ('guardian', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='rider_links', to='portal.guardiancontact')),
                ('rider', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='guardian_links', to='portal.rider')),
            ],
        ),
        migrations.AddConstraint(
            model_name='riderguardian',
            constraint=models.UniqueConstraint(fields=('rider', 'guardian'), name='unique_rider_guardian_contact'),
        ),
        migrations.RunPython(forward_data, migrations.RunPython.noop),
    ]
