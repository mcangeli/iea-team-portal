from django.urls import path
from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("riders/", views.rider_list, name="rider_list"),
    path("riders/add/", views.rider_create, name="rider_create"),
    path("riders/<int:pk>/", views.rider_detail, name="rider_detail"),
    path("riders/<int:pk>/edit/", views.rider_edit, name="rider_edit"),
    path("riders/<int:pk>/season/", views.rider_membership_edit, name="rider_membership_edit"),
    path("riders/<int:pk>/season/<int:season_pk>/", views.rider_membership_edit, name="rider_membership_edit_season"),
    path("riders/<int:pk>/parents/add/", views.rider_guardian_add, name="rider_guardian_add"),
    path("riders/<int:pk>/parents/<int:guardian_pk>/edit/", views.rider_guardian_edit, name="rider_guardian_edit"),
    path("parents/", views.parent_list, name="parent_list"),
    path("season/", views.season_setup, name="season_setup"),
    path("season/classes/add/", views.season_class_create, name="season_class_create"),
    path("season/classes/<int:class_pk>/edit/", views.season_class_edit, name="season_class_edit"),
    path("calendar/", views.calendar, name="calendar"),
    path("calendar/add/", views.event_create, name="event_create"),
    path("announcements/add/", views.announcement_create, name="announcement_create"),
    path("shows/", views.show_list, name="show_list"),
    path("shows/add/", views.show_create, name="show_create"),
    path("shows/<int:pk>/", views.show_detail, name="show_detail"),
    path("shows/<int:pk>/edit/", views.show_edit, name="show_edit"),
    path("shows/<int:show_pk>/classes/add/", views.show_class_create, name="show_class_create"),
    path("shows/<int:show_pk>/entries/add/", views.show_entry_create, name="show_entry_create"),
    path("entries/<int:entry_pk>/result/", views.show_result_edit, name="show_result_edit"),
]
