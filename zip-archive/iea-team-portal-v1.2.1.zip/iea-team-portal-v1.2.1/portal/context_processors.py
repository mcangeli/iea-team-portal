def portal_context(request):
    team = None; role = None
    if request.user.is_authenticated and hasattr(request.user, "profile"):
        team=request.user.profile.team; role=request.user.profile.role
    return {"portal_team":team,"portal_role":role}
