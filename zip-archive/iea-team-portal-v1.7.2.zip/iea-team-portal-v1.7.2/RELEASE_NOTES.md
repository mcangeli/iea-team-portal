# IEA Team Portal v1.7.2 — Validation & Calendar Editing

## Fixed
- Duplicate create attempts no longer produce raw 500 errors in the hardened workflows.
- Context-aware validation catches duplicates whose uniqueness includes season/show context that is assigned after normal form validation.

## Added
- Edit action for manually-created calendar events.
- Synced show calendar entries link to Edit Show.
- Synced lesson calendar entries link to Edit Lesson.
- Friendly fallback message for database constraint collisions in key create workflows.

## Database
No migration is required for v1.7.2.

# IEA Team Portal v1.7.1 — Existing Guardian Linking

## Fixed
The rider page previously allowed creating a new parent/guardian but did not expose the existing many-to-many family relationship workflow.

## Added
- **Create new parent** and **Link existing parent** are now separate actions on Rider profiles.
- The existing-parent workflow lists GuardianContact records on the same team that are not already linked to that rider.
- Relationship label and primary-contact status can be set when linking.
- Existing guardian user accounts are preserved and linked to the additional rider.
- A guardian can be unlinked from one rider without deleting the guardian contact or user account.

## Database
No migration is required for v1.7.1.

# IEA Team Portal v1.7.0 — Season History & Reporting

## Added
- Season archive and Season Review workspace.
- Administrator close/reopen season workflow.
- Rider Development History across seasons.
- Staff-only or family-visible rider development notes.
- Awards & Recognition.
- Printable end-of-season rider summaries.
- Team record book with historical season point totals, wins, and published awards.
- Delegated Points Secretary access for results, detailed standings, qualification review, and standings export.

## Privacy
Competition-reporting delegation does not expose rider contact details or unrelated private operational information. Rider history remains limited to staff and the rider/linked family.

## Database
Adds `0011_v170_season_history_reporting`:
- `Season.is_closed`
- `Season.closed_at`
- `RiderDevelopmentNote`
- `RiderAward`

## Upgrade
`./portalctl upgrade` creates the normal pre-upgrade database backup before applying the release.
