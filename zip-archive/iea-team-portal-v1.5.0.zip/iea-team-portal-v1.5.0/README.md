# IEA Team Portal v1.5.0

A self-hosted Django portal for an interscholastic equestrian team with Futures and Upper School season rosters, season class assignments, shows, points-rider designation, results, qualification/standings, lessons, attendance, show availability, volunteer-hour tracking, calendar, rider profiles, parent/guardian contacts, announcements, and role-based access.

The application uses an IEA-inspired palette but does not bundle official IEA logo artwork. Upload only branding your team is authorized to use. This private team portal complements rather than replaces AccessIEA.

## v1.5.0 highlights

### Lessons & attendance
- Reusable lesson groups with Futures, Upper School, or combined team scope.
- Assign riders and a coach to each lesson group.
- Schedule one lesson or create a weekly recurring series for up to 26 weeks.
- Lessons automatically create/update linked calendar events.
- Attendance statuses: Expected, Present, Absent, Excused, Makeup.
- Optional horse assignment and attendance notes per rider.
- Recent lesson attendance appears on each rider profile.
- Lesson detail pages include a print-friendly attendance sheet.

### Show availability
- Every rostered rider can have a show-specific availability response.
- Responses: No response, Available, Available with conditions, Unavailable.
- Riders/Parents can respond only for riders they are authorized to see.
- Coaches/Admins can view and update the whole roster.
- Dashboard surfaces outstanding responses for upcoming shows.

### Volunteer hours
- Configure required volunteer hours separately for Futures and Upper School for each season.
- Record the rider receiving credit, service date, hours, category, who performed the work, and description.
- Rider/Parent submissions enter Pending approval status.
- Coach/Admin entries are approved immediately and Coaches/Admins can review pending entries.
- Only approved hours count toward the season requirement.
- Progress shows approved, pending, required, remaining, and completion status.
- Rider profiles display current-season volunteer progress.
- Coach/Admin CSV export includes both progress totals and detailed volunteer records.

### Operations dashboard & calendar
- Dashboard now includes upcoming lesson count and riders with volunteer hours remaining.
- Coach/Admin dashboard alerts for pending volunteer approvals and unanswered show availability.
- Calendar filters by Shows, Lessons, Meetings, Deadlines, Social, and Other events.
- Shows and lessons remain linked to their source records from the calendar.

### Upgrade tooling
- `portalctl upgrade` continues to create a PostgreSQL backup, run schema preflight, build, and start the release.
- Backup filenames and startup messages now use the actual `VERSION` file instead of a hard-coded older release number.

## Persistent deployment layout

```text
/opt/iea-team-portal/
├── .env
├── backups/
├── iea-team-portal-v1.4.1/
└── iea-team-portal-v1.5.0/
```

The Compose project and persistent volumes remain unchanged:

```text
iea-team-portal_postgres_data
iea-team-portal_media_data
```

The existing host reverse proxy can continue forwarding HTTPS traffic to:

```text
http://127.0.0.1:8088
```

## Upgrade to v1.5.0

Extract the release under `/opt/iea-team-portal/`, then run:

```bash
cd /opt/iea-team-portal/iea-team-portal-v1.5.0
chmod +x portalctl
./portalctl upgrade
```

`upgrade` creates a timestamped PostgreSQL backup such as:

```text
/opt/iea-team-portal/backups/pre-v1.5.0-20260909-091500.sql
```

It then builds the release, runs schema preflight, starts the application, and Django applies migrations automatically using `migrate --fake-initial --noinput` before Gunicorn starts.

Verify after startup:

```bash
./portalctl ps
./portalctl logs --tail=150 web
./portalctl exec web python manage.py showmigrations portal
./portalctl exec web python manage.py check
```

Expected portal migration history:

```text
[X] 0001_initial
[X] 0002_competition_management
[X] 0003_team_levels_season_classes_guardians
[X] 0004_v130_workflow
[X] 0005_v140_points_qualification
[X] 0006_v150_team_operations
```

## First-time v1.5 setup

After upgrade:

1. Open **Volunteer → Set requirements** and enter the required hours for Futures and Upper School.
2. Open **Lessons → Lesson groups** and create the recurring riding groups for the active season.
3. Use **Schedule lesson** to create individual or recurring weekly lessons.
4. Open an upcoming show and choose **View availability** to collect rider responses before entries are finalized.

## Roles

- **Administrator / Coach:** full lesson, attendance, availability, volunteer approval, export, competition and scoring management.
- **Parent/Guardian:** linked-rider lesson schedule, show availability response, volunteer submission/progress, competition information with points-rider privacy retained.
- **Rider:** own lesson schedule, show availability response, volunteer submission/progress, competition information with points-rider privacy retained.
