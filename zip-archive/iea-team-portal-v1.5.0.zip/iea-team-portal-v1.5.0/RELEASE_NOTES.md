# IEA Team Portal v1.5.0

## Lessons, Attendance & Team Operations

### Lesson scheduling
- Added `LessonGroup`, `Lesson`, and `LessonAttendance` models.
- Lesson groups are season-specific and can be Futures, Upper School, or both teams.
- Coaches can assign riders, coach, and default location to a lesson group.
- Lesson creation supports weekly recurrence for 1–26 weeks.
- Lesson group riders are automatically seeded into attendance for each created lesson.
- Editing a lesson can add newly assigned group riders without deleting historical attendance records.
- Lesson calendar events are linked directly back to the lesson.
- Lesson detail pages are print-friendly.

### Attendance
- Attendance states: Expected, Present, Absent, Excused, Makeup.
- Optional horse name and rider-specific notes.
- Parent/Rider users see only attendance for riders they are authorized to access.
- Current-season attendance history is shown on rider profiles.

### Show availability / RSVP
- Added `ShowAvailability` with show+rider uniqueness.
- Statuses: No response, Available, Available with conditions, Unavailable.
- Parent/Rider accounts can respond only for linked/self riders.
- Coach/Admin users can manage responses for the full season roster.
- Upcoming show response gaps are surfaced on the coach dashboard.

### Volunteer-hour tracking
- Added per-season Futures and Upper School volunteer-hour requirements.
- Added `VolunteerLog` with rider credit, service date, hours, category, performer, description, approval status, submitter and approver metadata.
- Rider/Parent submissions require Coach/Admin approval before counting.
- Coach/Admin-created records are approved automatically.
- Dashboard displays approved/pending/required/remaining totals and completion status.
- Current-season progress appears on rider profiles.
- Coach/Admin CSV export provides both requirement summary and detailed records.

### Calendar and dashboard
- Calendar can now be filtered by event type.
- Calendar privacy now honors `visible_to_all` for non-managers.
- Dashboard adds upcoming lessons, volunteer requirement status, volunteer approval alerts, and show availability alerts.

### Deployment
- New migration: `0006_v150_team_operations`.
- Existing `.env`, PostgreSQL volume, media volume, reverse proxy and automatic migration behavior remain unchanged.
- `portalctl` backup naming and startup messages now derive from `VERSION` instead of retaining a hard-coded v1.3.0 label.
