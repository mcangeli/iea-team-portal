from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist, ValidationError
from django.db import models
from django.utils import timezone


class Team(models.Model):
    name = models.CharField(max_length=150)
    short_name = models.CharField(max_length=60, blank=True)
    discipline = models.CharField(
        max_length=30,
        choices=[
            ("hunt_seat", "Hunt Seat"),
            ("western", "Western"),
            ("dressage", "Dressage"),
            ("multi", "Multi-discipline"),
        ],
        default="hunt_seat",
    )
    website = models.URLField(blank=True)
    logo = models.ImageField(upload_to="team_logos/", blank=True, null=True,
        help_text="Use only a logo your team is authorized to display.")

    def __str__(self):
        return self.name


class Season(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="seasons")
    name = models.CharField(max_length=50, help_text="Example: 2026–2027")
    start_date = models.DateField()
    end_date = models.DateField()
    is_active = models.BooleanField(default=False)
    futures_volunteer_hours_required = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    upper_volunteer_hours_required = models.DecimalField(max_digits=5, decimal_places=2, default=0)

    class Meta:
        ordering = ["-start_date"]

    def __str__(self):
        return f"{self.team} — {self.name}"


class UserProfile(models.Model):
    class Role(models.TextChoices):
        ADMIN = "admin", "Administrator"
        COACH = "coach", "Coach"
        PARENT = "parent", "Parent/Guardian"
        RIDER = "rider", "Rider"

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")
    team = models.ForeignKey(Team, on_delete=models.SET_NULL, null=True, blank=True, related_name="user_profiles")
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.PARENT)
    phone = models.CharField(max_length=30, blank=True)

    def __str__(self):
        return f"{self.user.get_full_name() or self.user.username} ({self.get_role_display()})"


class Rider(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="riders")
    user = models.OneToOneField(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="rider_record")
    first_name = models.CharField(max_length=80)
    last_name = models.CharField(max_length=80)
    preferred_name = models.CharField(max_length=80, blank=True)
    email = models.EmailField(blank=True)
    school = models.CharField(max_length=150, blank=True)
    grade = models.PositiveSmallIntegerField(null=True, blank=True)
    iea_member_number = models.CharField(max_length=40, blank=True)
    bio = models.TextField(blank=True)
    photo = models.ImageField(upload_to="riders/", blank=True, null=True)
    active = models.BooleanField(default=True)
    # Legacy authorization relation retained for seamless upgrades. New parent details
    # live in GuardianContact / RiderGuardian.
    guardians = models.ManyToManyField(User, blank=True, related_name="guardian_riders")

    class Meta:
        ordering = ["last_name", "first_name"]

    @property
    def display_name(self):
        return self.preferred_name or self.first_name

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class GuardianContact(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="guardian_contacts")
    user = models.OneToOneField(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="guardian_contact")
    first_name = models.CharField(max_length=80)
    last_name = models.CharField(max_length=80)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=30, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["last_name", "first_name"]

    @property
    def display_name(self):
        return f"{self.first_name} {self.last_name}".strip()

    def __str__(self):
        return self.display_name


class RiderGuardian(models.Model):
    rider = models.ForeignKey(Rider, on_delete=models.CASCADE, related_name="guardian_links")
    guardian = models.ForeignKey(GuardianContact, on_delete=models.CASCADE, related_name="rider_links")
    relationship = models.CharField(max_length=50, blank=True, help_text="Example: Parent, Mother, Father, Guardian")
    primary_contact = models.BooleanField(default=False)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["rider", "guardian"], name="unique_rider_guardian_contact")]

    def __str__(self):
        return f"{self.guardian} — {self.rider}"


class SeasonClass(models.Model):
    class TeamLevel(models.TextChoices):
        FUTURES = "futures", "Futures Team"
        UPPER = "upper", "Upper School Team"
        BOTH = "both", "Both teams"

    season = models.ForeignKey(Season, on_delete=models.CASCADE, related_name="season_classes")
    name = models.CharField(max_length=160)
    team_level = models.CharField(max_length=20, choices=TeamLevel.choices, default=TeamLevel.BOTH)
    discipline = models.CharField(
        max_length=30,
        choices=[
            ("hunt_seat", "Hunt Seat"),
            ("western", "Western"),
            ("dressage", "Dressage"),
            ("other", "Other"),
        ],
        default="hunt_seat",
    )
    sort_order = models.PositiveIntegerField(default=0)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ["team_level", "sort_order", "name"]
        constraints = [models.UniqueConstraint(fields=["season", "name", "team_level"], name="unique_season_class_by_team")]

    def __str__(self):
        return f"{self.get_team_level_display()} — {self.name}"


class SeasonMembership(models.Model):
    class TeamLevel(models.TextChoices):
        FUTURES = "futures", "Futures Team"
        UPPER = "upper", "Upper School Team"

    rider = models.ForeignKey(Rider, on_delete=models.CASCADE, related_name="memberships")
    season = models.ForeignKey(Season, on_delete=models.CASCADE, related_name="memberships")
    team_level = models.CharField(max_length=20, choices=TeamLevel.choices, blank=True)
    division = models.CharField(max_length=100, blank=True)
    class_level = models.CharField(max_length=100, blank=True)
    classes = models.ManyToManyField(SeasonClass, blank=True, related_name="rider_memberships")
    notes = models.TextField(blank=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["rider", "season"], name="unique_rider_season")]

    def save(self, *args, **kwargs):
        if not self.team_level and self.rider.grade:
            if 4 <= self.rider.grade <= 8:
                self.team_level = self.TeamLevel.FUTURES
            elif 9 <= self.rider.grade <= 12:
                self.team_level = self.TeamLevel.UPPER
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.rider} — {self.season.name}"


class Announcement(models.Model):
    class Priority(models.TextChoices):
        NORMAL = "normal", "Normal"
        IMPORTANT = "important", "Important"
        URGENT = "urgent", "Urgent"

    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="announcements")
    season = models.ForeignKey(Season, on_delete=models.SET_NULL, null=True, blank=True, related_name="announcements")
    title = models.CharField(max_length=160)
    body = models.TextField()
    priority = models.CharField(max_length=20, choices=Priority.choices, default=Priority.NORMAL)
    published = models.BooleanField(default=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    @property
    def is_current(self):
        return self.published and (not self.expires_at or self.expires_at > timezone.now())


class CalendarEvent(models.Model):
    class Kind(models.TextChoices):
        SHOW = "show", "Show"
        LESSON = "lesson", "Lesson"
        MEETING = "meeting", "Meeting"
        DEADLINE = "deadline", "Deadline"
        SOCIAL = "social", "Social"
        OTHER = "other", "Other"

    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="events")
    season = models.ForeignKey(Season, on_delete=models.SET_NULL, null=True, blank=True, related_name="events")
    title = models.CharField(max_length=160)
    kind = models.CharField(max_length=20, choices=Kind.choices, default=Kind.OTHER)
    starts_at = models.DateTimeField()
    ends_at = models.DateTimeField(null=True, blank=True)
    location = models.CharField(max_length=200, blank=True)
    description = models.TextField(blank=True)
    visible_to_all = models.BooleanField(default=True)
    all_day = models.BooleanField(default=False)
    show = models.OneToOneField("Show", on_delete=models.CASCADE, null=True, blank=True, related_name="calendar_event")
    lesson = models.OneToOneField("Lesson", on_delete=models.CASCADE, null=True, blank=True, related_name="calendar_event")

    class Meta:
        ordering = ["starts_at"]

    def __str__(self):
        return self.title


class Show(models.Model):
    class Status(models.TextChoices):
        PLANNING = "planning", "Planning"
        REGISTRATION = "registration", "Registration open"
        ENTERED = "entered", "Entries submitted"
        COMPLETE = "complete", "Complete"
        CANCELLED = "cancelled", "Cancelled"

    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="shows")
    season = models.ForeignKey(Season, on_delete=models.CASCADE, related_name="shows")
    name = models.CharField(max_length=180)
    show_date = models.DateField()
    start_time = models.TimeField(null=True, blank=True)
    venue = models.CharField(max_length=180, blank=True)
    address = models.CharField(max_length=255, blank=True)
    host_team = models.CharField(max_length=180, blank=True)
    iea_zone = models.CharField(max_length=40, blank=True)
    iea_region = models.CharField(max_length=40, blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PLANNING)
    entry_deadline = models.DateField(null=True, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["show_date", "name"]

    def __str__(self):
        return self.name


class ShowClass(models.Model):
    show = models.ForeignKey(Show, on_delete=models.CASCADE, related_name="classes")
    season_class = models.ForeignKey(SeasonClass, on_delete=models.PROTECT, null=True, blank=True, related_name="show_classes")
    # Legacy copies are kept for upgrade compatibility and snapshots of old data.
    name = models.CharField(max_length=160)
    division = models.CharField(max_length=120, blank=True)
    discipline = models.CharField(
        max_length=30,
        choices=[
            ("hunt_seat", "Hunt Seat"),
            ("western", "Western"),
            ("dressage", "Dressage"),
            ("other", "Other"),
        ],
        default="hunt_seat",
    )
    class_number = models.CharField(max_length=30, blank=True)
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort_order", "class_number", "name"]

    @property
    def display_name(self):
        return self.season_class.name if self.season_class else self.name

    @property
    def team_level(self):
        return self.season_class.team_level if self.season_class else "both"

    def save(self, *args, **kwargs):
        if self.season_class:
            self.name = self.season_class.name
            self.discipline = self.season_class.discipline
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.show.name} — {self.display_name}"


class ShowEntry(models.Model):
    class EntryType(models.TextChoices):
        INDIVIDUAL = "individual", "Individual"
        TEAM = "team", "Team"
        BOTH = "both", "Individual + Team"

    class Status(models.TextChoices):
        PLANNED = "planned", "Planned"
        ENTERED = "entered", "Entered"
        SCRATCHED = "scratched", "Scratched"

    show_class = models.ForeignKey(ShowClass, on_delete=models.CASCADE, related_name="entries")
    rider = models.ForeignKey(Rider, on_delete=models.CASCADE, related_name="show_entries")
    entry_type = models.CharField(max_length=20, choices=EntryType.choices, default=EntryType.INDIVIDUAL)
    is_point_rider = models.BooleanField(default=False)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PLANNED)
    notes = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["show_class", "rider__last_name", "rider__first_name"]
        constraints = [models.UniqueConstraint(fields=["show_class", "rider"], name="unique_rider_show_class")]

    def clean(self):
        super().clean()
        if not self.show_class_id or not self.rider_id or not self.show_class.season_class_id:
            return
        membership = SeasonMembership.objects.filter(rider=self.rider, season=self.show_class.show.season).first()
        if not membership:
            raise ValidationError("This rider is not on the roster for this show's season.")
        sc = self.show_class.season_class
        if sc.team_level != SeasonClass.TeamLevel.BOTH and membership.team_level != sc.team_level:
            raise ValidationError("This class belongs to a different team level than the rider's season roster.")
        if not membership.classes.filter(pk=sc.pk).exists():
            raise ValidationError("This rider is not assigned to this class for the season.")
        if self.is_point_rider:
            if self.entry_type == self.EntryType.INDIVIDUAL:
                raise ValidationError("A points rider must be entered as Team or Individual + Team.")
            conflict_ids = []
            for other in self.show_class.entries.filter(is_point_rider=True).exclude(pk=self.pk).select_related("rider"):
                other_membership = SeasonMembership.objects.filter(rider=other.rider, season=self.show_class.show.season).first()
                if other_membership and other_membership.team_level == membership.team_level:
                    conflict_ids.append(other.pk)
            if conflict_ids:
                raise ValidationError(f"A {membership.get_team_level_display()} points rider is already designated for this class.")

    @property
    def result_or_none(self):
        try:
            return self.result
        except ObjectDoesNotExist:
            return None

    def __str__(self):
        return f"{self.rider} — {self.show_class.display_name}"


class ShowResult(models.Model):
    entry = models.OneToOneField(ShowEntry, on_delete=models.CASCADE, related_name="result")
    place = models.PositiveSmallIntegerField(null=True, blank=True)
    points = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True)
    manual_points = models.BooleanField(default=False, help_text="Keep the entered points instead of calculating from placing.")
    horse_name = models.CharField(max_length=100, blank=True)
    notes = models.TextField(blank=True)
    def save(self, *args, **kwargs):
        if not self.manual_points and self.place:
            config, _ = SeasonScoringConfig.objects.get_or_create(season=self.entry.show_class.show.season)
            self.points = config.points_for_place(self.place)
        elif not self.manual_points and not self.place:
            self.points = None
        super().save(*args, **kwargs)


class SeasonScoringConfig(models.Model):
    season = models.OneToOneField(Season, on_delete=models.CASCADE, related_name="scoring_config")
    first_points = models.DecimalField(max_digits=4, decimal_places=1, default=7)
    second_points = models.DecimalField(max_digits=4, decimal_places=1, default=5)
    third_points = models.DecimalField(max_digits=4, decimal_places=1, default=4)
    fourth_points = models.DecimalField(max_digits=4, decimal_places=1, default=3)
    fifth_points = models.DecimalField(max_digits=4, decimal_places=1, default=2)
    sixth_points = models.DecimalField(max_digits=4, decimal_places=1, default=1)
    individual_qualification_points = models.DecimalField(max_digits=5, decimal_places=1, default=18)
    team_qualification_points = models.DecimalField(max_digits=5, decimal_places=1, default=20)

    def points_for_place(self, place):
        return {
            1: self.first_points, 2: self.second_points, 3: self.third_points,
            4: self.fourth_points, 5: self.fifth_points, 6: self.sixth_points,
        }.get(place, 0)

    def __str__(self):
        return f"Scoring — {self.season.name}"


class QualificationOverride(models.Model):
    class Status(models.TextChoices):
        AUTO = "auto", "Automatic"
        QUALIFIED = "qualified", "Qualified"
        NOT_QUALIFIED = "not_qualified", "Not qualified"

    membership = models.ForeignKey(SeasonMembership, on_delete=models.CASCADE, related_name="qualification_overrides")
    season_class = models.ForeignKey(SeasonClass, on_delete=models.CASCADE, related_name="qualification_overrides")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.AUTO)
    notes = models.TextField(blank=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["membership", "season_class"], name="unique_qualification_override")]

    def __str__(self):
        return f"{self.membership.rider} — {self.season_class.name}"


class LessonGroup(models.Model):
    class TeamLevel(models.TextChoices):
        FUTURES = "futures", "Futures Team"
        UPPER = "upper", "Upper School Team"
        BOTH = "both", "Both teams"

    season = models.ForeignKey(Season, on_delete=models.CASCADE, related_name="lesson_groups")
    name = models.CharField(max_length=120)
    team_level = models.CharField(max_length=20, choices=TeamLevel.choices, default=TeamLevel.BOTH)
    coach = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="lesson_groups_coached")
    riders = models.ManyToManyField(Rider, blank=True, related_name="lesson_groups")
    default_location = models.CharField(max_length=180, blank=True)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ["team_level", "name"]
        constraints = [models.UniqueConstraint(fields=["season", "name"], name="unique_lesson_group_season")]

    def __str__(self):
        return f"{self.name} — {self.season.name}"


class Lesson(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="lessons")
    season = models.ForeignKey(Season, on_delete=models.CASCADE, related_name="lessons")
    group = models.ForeignKey(LessonGroup, on_delete=models.SET_NULL, null=True, blank=True, related_name="lessons")
    coach = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="lessons_coached")
    title = models.CharField(max_length=160, default="Team lesson")
    starts_at = models.DateTimeField()
    ends_at = models.DateTimeField(null=True, blank=True)
    location = models.CharField(max_length=180, blank=True)
    notes = models.TextField(blank=True)
    cancelled = models.BooleanField(default=False)

    class Meta:
        ordering = ["starts_at"]

    def __str__(self):
        return f"{self.title} — {timezone.localtime(self.starts_at):%b %d, %Y}"


class LessonAttendance(models.Model):
    class Status(models.TextChoices):
        EXPECTED = "expected", "Expected"
        PRESENT = "present", "Present"
        ABSENT = "absent", "Absent"
        EXCUSED = "excused", "Excused"
        MAKEUP = "makeup", "Makeup"

    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE, related_name="attendance")
    rider = models.ForeignKey(Rider, on_delete=models.CASCADE, related_name="lesson_attendance")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.EXPECTED)
    horse_name = models.CharField(max_length=100, blank=True)
    notes = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["rider__last_name", "rider__first_name"]
        constraints = [models.UniqueConstraint(fields=["lesson", "rider"], name="unique_lesson_rider_attendance")]

    def __str__(self):
        return f"{self.rider} — {self.lesson}"


class ShowAvailability(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending", "No response"
        AVAILABLE = "available", "Available"
        CONDITIONAL = "conditional", "Available with conditions"
        UNAVAILABLE = "unavailable", "Unavailable"

    show = models.ForeignKey(Show, on_delete=models.CASCADE, related_name="availability")
    rider = models.ForeignKey(Rider, on_delete=models.CASCADE, related_name="show_availability")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    notes = models.CharField(max_length=255, blank=True)
    responded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="show_availability_responses")
    responded_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["rider__last_name", "rider__first_name"]
        constraints = [models.UniqueConstraint(fields=["show", "rider"], name="unique_show_rider_availability")]

    def save(self, *args, **kwargs):
        if self.status != self.Status.PENDING and not self.responded_at:
            self.responded_at = timezone.now()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.rider} — {self.show}"


class VolunteerLog(models.Model):
    class Category(models.TextChoices):
        SHOW = "show", "Show support"
        BARN = "barn", "Barn/team support"
        FUNDRAISING = "fundraising", "Fundraising"
        TEAM = "team", "Team event"
        OTHER = "other", "Other"

    class Status(models.TextChoices):
        PENDING = "pending", "Pending approval"
        APPROVED = "approved", "Approved"
        REJECTED = "rejected", "Rejected"

    season = models.ForeignKey(Season, on_delete=models.CASCADE, related_name="volunteer_logs")
    rider = models.ForeignKey(Rider, on_delete=models.CASCADE, related_name="volunteer_logs")
    service_date = models.DateField()
    hours = models.DecimalField(max_digits=5, decimal_places=2)
    category = models.CharField(max_length=30, choices=Category.choices, default=Category.TEAM)
    performed_by = models.CharField(max_length=160, blank=True, help_text="Name of the family member/person who completed the hours.")
    description = models.CharField(max_length=255)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    submitted_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="volunteer_logs_submitted")
    submitted_at = models.DateTimeField(auto_now_add=True)
    approved_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="volunteer_logs_approved")
    approved_at = models.DateTimeField(null=True, blank=True)
    coach_notes = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["-service_date", "-submitted_at"]

    def clean(self):
        super().clean()
        if self.hours is not None and self.hours <= 0:
            raise ValidationError("Volunteer hours must be greater than zero.")
        if self.rider_id and self.season_id and self.rider.team_id != self.season.team_id:
            raise ValidationError("Rider and season must belong to the same team.")

    def __str__(self):
        return f"{self.rider} — {self.hours} hours"
