# Interscholastic Equestrian Team Portal — v1.0.0

A private, self-hosted team portal for coaches, parents/guardians, and riders. Version 1 includes authentication, role-aware access, seasons, rider profiles and bios, announcements, and a team calendar foundation.

## Important branding note

The visual theme uses the IEA primary blue (#007297) and a restrained cyan accent (#00AEEF) based on the current IEA Brand Manual. This project is not an official IEA product. No IEA logo artwork is bundled. Upload only logos/marks your team is authorized to use.

## v1 features

- Django authentication with strong password validation
- Roles: Administrator, Coach, Parent/Guardian, Rider
- Team and active-season records
- Rider roster, photos, school/grade, IEA member number, and bios
- Per-season rider membership/history
- Parent accounts restricted to riders assigned to them
- Rider accounts restricted to their own profile
- Announcements with priority and expiration
- Team calendar for shows, lessons, meetings, deadlines, and events
- Coach/admin create tools
- Full Django Admin for deeper setup
- PostgreSQL, Docker Compose, Caddy HTTPS, persistent media/data volumes

## Server requirements

- Linux server (Ubuntu 24.04 LTS or Debian 12 are good choices)
- A domain/subdomain pointed at the server, e.g. `team.example.com`
- TCP ports 80 and 443 open to the Internet
- Docker Engine and Docker Compose plugin
- Recommended: 2 GB RAM, 2 CPU cores, 10+ GB available disk

## 1. Install Docker on Ubuntu/Debian

Use Docker's official repository for production. If Docker is already installed, skip this section.

Verify afterward:

```bash
docker --version
docker compose version
```

## 2. Put the application on the server

```bash
sudo mkdir -p /opt/iea-team-portal
sudo chown "$USER":"$USER" /opt/iea-team-portal
cd /opt/iea-team-portal
```

Copy this project into that directory (or clone it from your own Git repository).

## 3. Configure DNS

Create an A/AAAA record such as:

```text
team.example.com -> YOUR_SERVER_IP
```

Wait until the name resolves to the server before starting Caddy if you want automatic public HTTPS certificates.

## 4. Create the environment file

```bash
cp .env.example .env
```

Generate strong random values:

```bash
openssl rand -base64 48
openssl rand -base64 36
```

Edit `.env`:

```bash
nano .env
```

At minimum change `SITE_DOMAIN`, `DJANGO_SECRET_KEY`, `DJANGO_ALLOWED_HOSTS`, `DJANGO_CSRF_TRUSTED_ORIGINS`, and `POSTGRES_PASSWORD`.

For a LAN-only initial test with plain HTTP, set `SECURE_COOKIES=0`, `SECURE_HSTS_SECONDS=0`, and use a local reverse-proxy/domain configuration. The supplied Caddyfile is intended for a real DNS name with HTTPS.

## 5. Start the application

```bash
docker compose up -d --build
```

Check status:

```bash
docker compose ps
docker compose logs --tail=100 web
docker compose logs --tail=100 caddy
```

## 6. Bootstrap your team and first admin

Run this exactly once, replacing the example values:

```bash
docker compose exec web python manage.py bootstrap_team \
  --team "My Equestrian Team" \
  --season "2026-2027" \
  --username coachadmin \
  --email coach@example.com \
  --password 'USE-A-STRONG-UNIQUE-PASSWORD'
```

Then browse to:

```text
https://team.example.com
```

Django administration is at:

```text
https://team.example.com/admin/
```

## 7. Initial setup in Admin

1. Open **Teams** and optionally upload your authorized team logo.
2. Confirm the active **Season** dates.
3. Add user accounts under **Users**.
4. For each account, open **User profiles**, choose the team, and select a role.
5. Add riders. Optionally link a Rider to a rider User account.
6. For parent/guardian visibility, add the parent User to the rider's **guardians** field.
7. Add **Season memberships** to capture division/class progression.
8. Post announcements and calendar events from the normal site or Admin.

## Roles and privacy behavior

- **Administrator / Coach**: can see all team riders and create/edit riders, events, announcements.
- **Parent/Guardian**: sees only riders explicitly connected through the rider's Guardians field.
- **Rider**: sees only the Rider record linked to their User account.
- **Superuser**: full Django Admin access.

Do not store medical data, emergency documentation, waivers, or other highly sensitive youth records in v1. The initial release is intended for ordinary team operational information.

## Updates

Before updating, back up the database and media volume. Then replace/checkout the new application version and run:

```bash
docker compose build --pull
docker compose up -d
docker compose exec web python manage.py migrate
```

## Backups

Create a PostgreSQL backup:

```bash
mkdir -p backups
docker compose exec -T db pg_dump -U "$POSTGRES_USER" "$POSTGRES_DB" > backups/iea-team-$(date +%F).sql
```

Because shell variables in `.env` are not automatically loaded into your interactive shell, you can alternatively use explicit database/user names from `.env` in that command.

Back up uploaded photos/media:

```bash
docker run --rm \
  -v iea-team-portal_media_data:/source:ro \
  -v "$PWD/backups":/backup \
  alpine tar czf /backup/media-$(date +%F).tgz -C /source .
```

The Docker volume prefix can differ with your Compose project directory/name. Run `docker volume ls` to confirm it.

## Restore database

Stop web writes first, then restore to an empty/appropriate PostgreSQL database. Test restores periodically; a backup is only useful when it can be restored.

## Security checklist

- Keep `.env` private and out of Git.
- Use HTTPS; Caddy provides it automatically for a valid public domain.
- Keep the OS and Docker patched.
- Use unique passwords and limit administrator accounts.
- Set up automated off-server backups.
- Do not expose PostgreSQL port 5432 publicly; this Compose file does not publish it.
- Consider firewalling SSH to trusted IPs or using a VPN.
- Review account access at the start/end of each season.

## Useful commands

```bash
# Status
docker compose ps

# Logs
docker compose logs -f --tail=100

# Restart
docker compose restart

# Stop
docker compose down

# Start
docker compose up -d

# Django shell
docker compose exec web python manage.py shell

# Create another superuser
docker compose exec web python manage.py createsuperuser
```

## Planned v1.x / v2 features

Show records, IEA classes, entries, results/points, lesson groups and attendance, ICS subscriptions, document library, email notifications, qualification tracking, and reporting.
