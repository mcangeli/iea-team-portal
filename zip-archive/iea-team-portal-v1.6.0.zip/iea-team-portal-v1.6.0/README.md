# IEA Team Portal v1.6.0

A private self-hosted portal for an interscholastic equestrian team. v1.6.0 adds targeted communications, in-app/email notifications, show-week summaries, reminders, and stricter rider/family privacy controls.

## Upgrade

Keep the shared environment file at the release parent, for example:

```text
/opt/iea-team-portal/.env
```

Extract the release into its own directory and run:

```bash
cd /opt/iea-team-portal/iea-team-portal-v1.6.0
chmod +x portalctl
./portalctl upgrade
```

The upgrade workflow creates a PostgreSQL backup, builds the web image, runs schema preflight, starts the release, and applies migrations automatically.

Verify with:

```bash
./portalctl logs --tail=150 web
./portalctl exec web python manage.py showmigrations portal
./portalctl exec web python manage.py check
```

Expected latest portal migration:

```text
[X] 0009_v160_communications_privacy
```

## Communications

Coaches/Admins can post targeted announcements from the Dashboard. Recipients receive in-app notifications. Email is optional.

### Optional SMTP

Add SMTP values to the existing persistent `.env`:

```env
EMAIL_HOST=smtp.example.com
EMAIL_PORT=587
EMAIL_HOST_USER=your-user
EMAIL_HOST_PASSWORD=your-password
EMAIL_USE_TLS=1
EMAIL_USE_SSL=0
DEFAULT_FROM_EMAIL=team@example.com
```

Leave `EMAIL_HOST` blank for in-app notifications only.

## Reminders

Run reminders manually with:

```bash
./portalctl reminders
```

For automatic daily reminders, schedule that command from the host (for example with cron or a systemd timer). The command is safe to run daily and avoids same-day duplicate reminders.

## Privacy model

Coaches/Admins retain full team operations access. Parents have private access only to linked riders. Riders have private access only to themselves. Teammate profiles expose only team-facing information and do not expose contact, family, account, attendance, volunteer, or private operational information.

## Deployment

The application continues to bind its internal gateway only to the configured localhost port (default `127.0.0.1:8088`) and is intended to sit behind the host's existing HTTPS reverse proxy. Persistent PostgreSQL/media volumes and the parent `.env` remain unchanged across release directories.
