# IEA Team Portal v1.6.0

## Communications & Privacy

### Targeted announcements
- Announcements can target the Entire Team, Futures Team, Upper School Team, Coaches/Admins, Parents/Guardians, Riders, or selected portal users.
- Targeted announcements only appear to intended recipients on the dashboard.
- Published announcements create an in-app notification for each recipient.
- Optional email delivery is supported when SMTP is configured.

### Notification center
- New Notifications page with unread counts in the main navigation.
- Users can mark individual notifications or all notifications read.
- Users can independently opt in/out of announcement emails and reminder emails.
- The portal remains fully functional with in-app notifications when SMTP is not configured.

### Show-week communication
- New Show Week page for every show with schedule/location, entries, and permitted availability information.
- Coaches/Admins can send the show-week summary to entered riders, linked parents/guardians, and staff.
- Rider/Parent summaries do not expose points-rider strategy.

### Reminder engine
- New `./portalctl reminders` command.
- Reminds families about unanswered availability for shows within the next seven days.
- Reminds riders/families about remaining volunteer requirements.
- Avoids duplicate reminders to the same user/title on the same day.
- Respects each user's reminder-email preference.

### Rider & family privacy
- Team roster cards no longer expose school, grade, email, or other contact details.
- Riders and Parents can view a teammate's team profile (name/photo, season team/classes and season competition points) without seeing personal data.
- Email, school, grade, IEA member number, bio, family contacts, lesson attendance, volunteer progress, and operational details are shown only to:
  - the rider,
  - linked parents/guardians,
  - Coaches/Admins.
- Parent directory, user administration, roster/contact exports, volunteer detail, lesson attendance detail, and availability detail remain permission-scoped.
- The privacy boundary is enforced in views/querysets as well as templates.

### SMTP configuration (optional)
Add these to the persistent `.env` only if email delivery is desired:

```env
EMAIL_HOST=
EMAIL_PORT=587
EMAIL_HOST_USER=
EMAIL_HOST_PASSWORD=
EMAIL_USE_TLS=1
EMAIL_USE_SSL=0
DEFAULT_FROM_EMAIL=team@example.com
```

If `EMAIL_HOST` is blank, notifications remain in-app only.

### Database
Adds migration:

`0009_v160_communications_privacy`

This adds announcement audience/email fields, selected-recipient links, notification preferences, and the Notification model.
