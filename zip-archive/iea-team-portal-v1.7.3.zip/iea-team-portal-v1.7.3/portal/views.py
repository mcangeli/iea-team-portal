import csv
from datetime import datetime, time, timedelta
from functools import wraps

from django.contrib import messages
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.core.exceptions import PermissionDenied
from django.db import IntegrityError, transaction
from django.db.models import Q, Sum
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from .forms import (
    AnnouncementForm, CalendarEventForm, GuardianContactForm, RiderForm,
    SeasonClassForm, SeasonMembershipForm, ShowClassForm, ShowEntryForm,
    ShowForm, ShowResultForm, SeasonScoringConfigForm, QualificationOverrideForm,
    LessonGroupForm, LessonForm, LessonAttendanceForm, ShowAvailabilityForm,
    VolunteerLogForm, VolunteerReviewForm, VolunteerRequirementForm,
    UserOnboardingForm, UserAccountEditForm, TemporaryPasswordResetForm, NotificationPreferenceForm,
    CommitteeAssignmentForm, ShowLeadAssignmentForm, ShowPlanningItemForm,
    RiderDevelopmentNoteForm, RiderAwardForm,
)
from .models import (
    Announcement, CalendarEvent, GuardianContact, Rider, RiderGuardian, Season,
    SeasonClass, SeasonMembership, SeasonScoringConfig, QualificationOverride, Show, ShowClass, ShowEntry, ShowResult, UserProfile,
    LessonGroup, Lesson, LessonAttendance, ShowAvailability, VolunteerLog, Notification,
    CommitteeAssignment, ShowLeadAssignment, ShowPlanningItem, RiderDevelopmentNote, RiderAward,
)

TEAM_LEVELS = {SeasonMembership.TeamLevel.FUTURES, SeasonMembership.TeamLevel.UPPER}


def friendly_integrity_errors(view_func):
    """Turn database constraint collisions in create workflows into a useful UI message."""
    @wraps(view_func)
    def wrapped(request, *args, **kwargs):
        try:
            with transaction.atomic():
                return view_func(request, *args, **kwargs)
        except IntegrityError:
            if request.method == "POST":
                messages.error(
                    request,
                    "That record could not be added because it conflicts with an existing record. "
                    "Review the existing entries and edit or link the existing record instead."
                )
                return redirect(request.path)
            raise
    return wrapped


def _team(user):
    if user.is_superuser:
        return user.profile.team if hasattr(user, "profile") else None
    if not hasattr(user, "profile") or not user.profile.team:
        raise PermissionDenied("Your account is not assigned to a team.")
    return user.profile.team


def _can_manage(user):
    return user.is_superuser or (
        hasattr(user, "profile") and user.profile.role in [UserProfile.Role.ADMIN, UserProfile.Role.COACH]
    )


def _active_committee_roles(user, season=None):
    qs = CommitteeAssignment.objects.filter(user=user, active=True)
    if season:
        qs = qs.filter(season=season)
    return set(qs.values_list("role", flat=True))


def _can_manage_points(user, season=None):
    return _can_manage(user) or CommitteeAssignment.Role.POINTS_SECRETARY in _active_committee_roles(user, season)


def _can_coordinate_team(user, team_level, season=None):
    if _can_manage(user):
        return True
    roles = _active_committee_roles(user, season)
    return (
        team_level == SeasonMembership.TeamLevel.FUTURES and CommitteeAssignment.Role.FUTURES_PARENT in roles
    ) or (
        team_level == SeasonMembership.TeamLevel.UPPER and CommitteeAssignment.Role.UPPER_PARENT in roles
    )


def _is_show_lead(user, show):
    return ShowLeadAssignment.objects.filter(show=show, user=user, active=True).exists()


def _can_plan_show(user, show):
    return _can_manage(user) or _is_show_lead(user, show)


def _ensure_season_open(season):
    if season and season.is_closed:
        raise PermissionDenied("This season is archived. An Administrator must reopen it before operational records can be changed.")



def _is_admin(user):
    return user.is_superuser or (hasattr(user, "profile") and user.profile.role == UserProfile.Role.ADMIN)


def _can_manage_user(actor, target):
    if _is_admin(actor):
        return True
    return _can_manage(actor) and hasattr(target, "profile") and target.profile.role in {UserProfile.Role.PARENT, UserProfile.Role.RIDER}


def _require_manage(user):
    if not _can_manage(user):
        raise PermissionDenied


def _visible_riders(user, team):
    """Riders whose private/operational data the user may access."""
    qs = team.riders.all()
    if hasattr(user, "profile") and user.profile.role == UserProfile.Role.PARENT:
        qs = qs.filter(Q(guardians=user) | Q(guardian_links__guardian__user=user)).distinct()
    elif hasattr(user, "profile") and user.profile.role == UserProfile.Role.RIDER:
        qs = qs.filter(user=user)
    return qs


def _can_view_private_rider(user, rider):
    if _can_manage(user):
        return True
    if rider.user_id == user.id:
        return True
    return rider.guardians.filter(pk=user.pk).exists() or rider.guardian_links.filter(guardian__user=user).exists()


def _team_roster(user, team):
    """Team-visible roster. Personal fields are filtered by the detail template/view."""
    return team.riders.filter(active=True)


def _announcement_recipients(announcement):
    users = User.objects.filter(profile__team=announcement.team, is_active=True).select_related("profile")
    audience = announcement.audience
    if audience == Announcement.Audience.COACHES:
        users = users.filter(profile__role__in=[UserProfile.Role.ADMIN, UserProfile.Role.COACH])
    elif audience == Announcement.Audience.PARENTS:
        users = users.filter(Q(profile__role=UserProfile.Role.PARENT) | Q(guardian_contact__isnull=False)).distinct()
    elif audience == Announcement.Audience.RIDERS:
        users = users.filter(profile__role=UserProfile.Role.RIDER)
    elif audience in {Announcement.Audience.FUTURES, Announcement.Audience.UPPER}:
        season = announcement.season or _active_season(announcement.team)
        if not season:
            return users.none()
        rider_users = Rider.objects.filter(
            team=announcement.team, memberships__season=season, memberships__team_level=audience, user__isnull=False
        ).values_list("user_id", flat=True)
        guardian_users = GuardianContact.objects.filter(
            team=announcement.team, rider_links__rider__memberships__season=season,
            rider_links__rider__memberships__team_level=audience, user__isnull=False
        ).values_list("user_id", flat=True)
        users = users.filter(Q(id__in=rider_users) | Q(id__in=guardian_users) | Q(profile__role__in=[UserProfile.Role.ADMIN, UserProfile.Role.COACH]))
    elif audience == Announcement.Audience.SELECTED:
        users = users.filter(id__in=announcement.selected_users.values("id"))
    return users.distinct()


def _visible_announcements(user, team):
    now = timezone.now()
    qs = team.announcements.filter(published=True).filter(Q(expires_at__isnull=True) | Q(expires_at__gt=now))
    if _can_manage(user):
        return qs
    allowed = []
    for announcement in qs.prefetch_related("selected_users"):
        if _announcement_recipients(announcement).filter(pk=user.pk).exists():
            allowed.append(announcement.pk)
    return qs.filter(pk__in=allowed)


def _deliver_announcement(announcement):
    recipients = list(_announcement_recipients(announcement))
    Notification.objects.filter(announcement=announcement).delete()
    Notification.objects.bulk_create([
        Notification(user=user, announcement=announcement, title=announcement.title, body=announcement.body, link="/")
        for user in recipients
    ])
    if announcement.send_email and settings.EMAIL_HOST:
        for user in recipients:
            profile = getattr(user, "profile", None)
            if not user.email or (profile and not profile.email_announcements):
                continue
            send_mail(
                subject=f"{announcement.team.short_name or announcement.team.name}: {announcement.title}",
                message=announcement.body,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[user.email],
                fail_silently=True,
            )
    return len(recipients)


def _active_season(team):
    return team.seasons.filter(is_active=True).first()


def _selected_team(request):
    value = request.GET.get("team", "all").lower()
    return value if value in TEAM_LEVELS | {"all", "unassigned"} else "all"


def _sync_show_calendar(show):
    tz = timezone.get_current_timezone()
    clock = show.start_time or time(0, 0)
    starts_at = timezone.make_aware(datetime.combine(show.show_date, clock), tz)
    location = " · ".join(part for part in [show.venue, show.address] if part)
    CalendarEvent.objects.update_or_create(
        show=show,
        defaults={
            "team": show.team,
            "season": show.season,
            "title": show.name,
            "kind": CalendarEvent.Kind.SHOW,
            "starts_at": starts_at,
            "ends_at": None,
            "all_day": not bool(show.start_time),
            "location": location,
            "description": show.notes,
            "visible_to_all": True,
        },
    )


@login_required
def dashboard(request):
    team = _team(request.user)
    if not team:
        return render(request, "portal/no_team.html")
    season = _active_season(team)
    now = timezone.now()
    today = timezone.localdate()
    announcements = _visible_announcements(request.user, team)[:5]
    events = team.events.filter(starts_at__gte=now)[:6]
    riders = _visible_riders(request.user, team).filter(active=True)
    shows = team.shows.filter(show_date__gte=today).order_by("show_date")[:4]
    memberships = season.memberships.select_related("rider") if season else SeasonMembership.objects.none()
    upcoming_lessons = Lesson.objects.none()
    volunteer_due = 0
    pending_volunteer = 0
    pending_availability = 0
    if season:
        upcoming_lessons = season.lessons.filter(starts_at__gte=now, cancelled=False).order_by("starts_at")
        if not _can_manage(request.user):
            upcoming_lessons = upcoming_lessons.filter(attendance__rider__in=riders).distinct()
        progress = _volunteer_progress_rows(season, riders)
        volunteer_due = sum(1 for row in progress if not row["complete"])
        pending_volunteer = VolunteerLog.objects.filter(season=season, rider__in=riders, status=VolunteerLog.Status.PENDING).count()
        upcoming_shows_qs = season.shows.filter(show_date__gte=today)
        for show in upcoming_shows_qs:
            for rider in riders:
                ShowAvailability.objects.get_or_create(show=show, rider=rider)
        pending_availability = ShowAvailability.objects.filter(show__in=upcoming_shows_qs, rider__in=riders, status=ShowAvailability.Status.PENDING).count()
    return render(request, "portal/dashboard.html", {
        "season": season, "announcements": announcements, "events": events, "riders": riders,
        "shows": shows, "can_manage": _can_manage(request.user),
        "futures_count": memberships.filter(team_level=SeasonMembership.TeamLevel.FUTURES).count(),
        "upper_count": memberships.filter(team_level=SeasonMembership.TeamLevel.UPPER).count(),
        "upcoming_lessons": upcoming_lessons[:4], "lesson_count": upcoming_lessons.count(),
        "volunteer_due": volunteer_due, "pending_volunteer": pending_volunteer,
        "pending_availability": pending_availability,
    })


@login_required
def rider_list(request):
    team = _team(request.user)
    qs = _team_roster(request.user, team).prefetch_related("memberships")
    season = _active_season(team)
    selected = _selected_team(request)
    if season:
        futures = qs.filter(memberships__season=season, memberships__team_level=SeasonMembership.TeamLevel.FUTURES).distinct()
        upper = qs.filter(memberships__season=season, memberships__team_level=SeasonMembership.TeamLevel.UPPER).distinct()
        unassigned = qs.exclude(memberships__season=season).distinct()
    else:
        futures = Rider.objects.none(); upper = Rider.objects.none(); unassigned = qs
    return render(request, "portal/rider_list.html", {
        "riders": qs, "futures": futures, "upper": upper, "unassigned": unassigned,
        "season": season, "can_manage": _can_manage(request.user), "selected_team": selected,
    })


@login_required
def rider_export(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team); selected = _selected_team(request)
    qs = team.riders.filter(active=True).order_by("last_name", "first_name")
    if season and selected in TEAM_LEVELS:
        qs = qs.filter(memberships__season=season, memberships__team_level=selected).distinct()
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="rider-roster.csv"'
    writer = csv.writer(response)
    writer.writerow(["Rider", "Email", "Grade", "School", "Team", "Season classes", "IEA member number"])
    for rider in qs:
        membership = rider.memberships.filter(season=season).prefetch_related("classes").first() if season else None
        writer.writerow([
            str(rider), rider.email, rider.grade or "", rider.school,
            membership.get_team_level_display() if membership else "Unassigned",
            "; ".join(c.name for c in membership.classes.all()) if membership else "",
            rider.iea_member_number,
        ])
    return response


@login_required
def rider_detail(request, pk):
    team = _team(request.user)
    rider = get_object_or_404(Rider.objects.prefetch_related("memberships__classes", "guardian_links__guardian"), pk=pk, team=team)
    private_view = _can_view_private_rider(request.user, rider)
    active_season = _active_season(team)
    entries = rider.show_entries.filter(result__isnull=False)
    if active_season:
        entries = entries.filter(show_class__show__season=active_season)
    season_points = entries.aggregate(total=Sum("result__points"))["total"] or 0
    lesson_history = LessonAttendance.objects.none()
    volunteer_progress = None
    if active_season and private_view:
        lesson_history = rider.lesson_attendance.filter(lesson__season=active_season).select_related("lesson").order_by("-lesson__starts_at")[:10]
        progress_rows = _volunteer_progress_rows(active_season, Rider.objects.filter(pk=rider.pk))
        volunteer_progress = progress_rows[0] if progress_rows else None
    return render(request, "portal/rider_detail.html", {
        "rider": rider, "season_points": season_points, "can_manage": _can_manage(request.user),
        "active_season": active_season, "lesson_history": lesson_history, "volunteer_progress": volunteer_progress,
        "private_view": private_view,
    })


@login_required
def rider_create(request):
    _require_manage(request.user); team = _team(request.user)
    form = RiderForm(
        request.POST or None,
        request.FILES or None,
        team=team,
        include_season=True,
    )
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.save()

        season = form.cleaned_data.get("season")
        if season:
            membership = SeasonMembership.objects.create(
                rider=obj,
                season=season,
                team_level=form.cleaned_data["team_level"],
                notes=form.cleaned_data.get("season_notes", ""),
            )
            membership.classes.set(form.cleaned_data.get("classes"))

            messages.success(
                request,
                f"Rider added and enrolled in {season.name}. The rider record will remain available for future seasons."
            )
        else:
            messages.success(
                request,
                "Rider added. No season enrollment was created; you can assign this rider to a season at any time."
            )
        return redirect("rider_detail", pk=obj.pk)
    return render(request, "portal/rider_form.html", {
        "form": form,
        "title": "Add rider",
        "eyebrow": "ROSTER",
        "creating": True,
    })


@login_required
def rider_edit(request, pk):
    _require_manage(request.user); team = _team(request.user)
    obj = get_object_or_404(Rider, pk=pk, team=team)
    form = RiderForm(request.POST or None, request.FILES or None, instance=obj, team=team)
    if form.is_valid():
        form.save(); messages.success(request, "Rider updated."); return redirect("rider_detail", pk=obj.pk)
    return render(request, "portal/rider_form.html", {
        "form": form,
        "title": "Edit rider",
        "eyebrow": "ROSTER",
        "creating": False,
    })


@login_required
def rider_membership_edit(request, pk, season_pk=None):
    _require_manage(request.user); team = _team(request.user)
    rider = get_object_or_404(Rider, pk=pk, team=team)
    season = get_object_or_404(Season, pk=season_pk, team=team) if season_pk else _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("rider_detail", pk=rider.pk)
    _ensure_season_open(season)
    membership, _ = SeasonMembership.objects.get_or_create(rider=rider, season=season)
    form = SeasonMembershipForm(request.POST or None, instance=membership, season=season)
    if form.is_valid():
        form.save(); messages.success(request, f"{season.name} team and class assignments updated.")
        return redirect("rider_detail", pk=rider.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"{rider.display_name} · {season.name}", "eyebrow": "SEASON ASSIGNMENT"})


@login_required
def rider_guardian_add(request, pk):
    _require_manage(request.user); team = _team(request.user)
    rider = get_object_or_404(Rider, pk=pk, team=team)
    form = GuardianContactForm(request.POST or None)
    if form.is_valid():
        relationship = form.cleaned_data.get("relationship", "")
        primary = form.cleaned_data.get("primary_contact", False)
        guardian = form.save(commit=False); guardian.team = team; guardian.save()
        RiderGuardian.objects.create(rider=rider, guardian=guardian, relationship=relationship, primary_contact=primary)
        messages.success(request, "Parent/guardian contact added."); return redirect("rider_detail", pk=rider.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Add parent/guardian · {rider.display_name}", "eyebrow": "FAMILY CONTACT"})


@login_required
def rider_guardian_edit(request, pk, guardian_pk):
    _require_manage(request.user); team = _team(request.user)
    rider = get_object_or_404(Rider, pk=pk, team=team)
    link = get_object_or_404(RiderGuardian.objects.select_related("guardian"), rider=rider, guardian_id=guardian_pk, guardian__team=team)
    form = GuardianContactForm(request.POST or None, instance=link.guardian, initial={"relationship": link.relationship, "primary_contact": link.primary_contact})
    if form.is_valid():
        form.save(); link.relationship = form.cleaned_data.get("relationship", ""); link.primary_contact = form.cleaned_data.get("primary_contact", False); link.save()
        messages.success(request, "Parent/guardian contact updated."); return redirect("rider_detail", pk=rider.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Edit {link.guardian.display_name}", "eyebrow": "FAMILY CONTACT"})


@login_required
def parent_list(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team); selected = _selected_team(request)
    guardians = team.guardian_contacts.prefetch_related("rider_links__rider").all()
    if season and selected in TEAM_LEVELS:
        guardians = guardians.filter(rider_links__rider__memberships__season=season, rider_links__rider__memberships__team_level=selected).distinct()
    return render(request, "portal/parent_list.html", {"guardians": guardians, "selected_team": selected, "season": season})


@login_required
def parent_export(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team); selected = _selected_team(request)
    guardians = team.guardian_contacts.prefetch_related("rider_links__rider").all()
    if season and selected in TEAM_LEVELS:
        guardians = guardians.filter(rider_links__rider__memberships__season=season, rider_links__rider__memberships__team_level=selected).distinct()
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="parent-guardian-directory.csv"'
    writer = csv.writer(response); writer.writerow(["Parent/Guardian", "Email", "Phone", "Riders", "Relationships"])
    for g in guardians:
        links = list(g.rider_links.select_related("rider").all())
        writer.writerow([g.display_name, g.email, g.phone, "; ".join(str(x.rider) for x in links), "; ".join(x.relationship for x in links if x.relationship)])
    return response


@login_required
def season_setup(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team); selected = _selected_team(request)
    classes = season.season_classes.all() if season else SeasonClass.objects.none()
    memberships = season.memberships.select_related("rider").prefetch_related("classes") if season else SeasonMembership.objects.none()
    if selected in TEAM_LEVELS:
        memberships = memberships.filter(team_level=selected)
    return render(request, "portal/season_setup.html", {"season": season, "classes": classes, "memberships": memberships, "selected_team": selected})


@login_required
@friendly_integrity_errors
def season_class_create(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    initial = {"discipline": team.discipline if team.discipline != "multi" else "hunt_seat"}
    form = SeasonClassForm(request.POST or None, initial=initial, season=season)
    if form.is_valid():
        obj = form.save(commit=False); obj.season = season; obj.save()
        messages.success(request, "Season class added."); return redirect("season_setup")
    return render(request, "portal/form.html", {"form": form, "title": "Add season class", "eyebrow": season.name})


@login_required
def season_class_edit(request, class_pk):
    _require_manage(request.user); team = _team(request.user)
    season_class = get_object_or_404(SeasonClass, pk=class_pk, season__team=team)
    form = SeasonClassForm(request.POST or None, instance=season_class, season=season_class.season)
    if form.is_valid():
        form.save(); messages.success(request, "Season class updated."); return redirect("season_setup")
    return render(request, "portal/form.html", {"form": form, "title": f"Edit {season_class.name}", "eyebrow": season_class.season.name})


@login_required
def calendar(request):
    team = _team(request.user)
    selected_kind = request.GET.get("kind", "all")
    valid_kinds = {value for value, _label in CalendarEvent.Kind.choices}
    events = team.events.select_related("show", "lesson").all()
    if not _can_manage(request.user):
        events = events.filter(visible_to_all=True)
    if selected_kind in valid_kinds:
        events = events.filter(kind=selected_kind)
    else:
        selected_kind = "all"
    return render(request, "portal/calendar.html", {
        "events": events[:100], "can_manage": _can_manage(request.user),
        "selected_kind": selected_kind, "event_kinds": CalendarEvent.Kind.choices,
    })


@login_required
def event_create(request):
    _require_manage(request.user); team = _team(request.user)
    form = CalendarEventForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.team = team; obj.season = _active_season(team); obj.save()
        messages.success(request, "Calendar event added."); return redirect("calendar")
    return render(request, "portal/form.html", {"form": form, "title": "Add calendar event", "eyebrow": "SCHEDULE"})


@login_required
def event_edit(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    event = get_object_or_404(CalendarEvent.objects.select_related("show", "lesson"), pk=pk, team=team)

    if event.show_id:
        messages.info(request, "This calendar entry is synced from a show. Edit the show to update the calendar.")
        return redirect("show_edit", pk=event.show_id)
    if event.lesson_id:
        messages.info(request, "This calendar entry is synced from a lesson. Edit the lesson to update the calendar.")
        return redirect("lesson_edit", pk=event.lesson_id)

    form = CalendarEventForm(request.POST or None, instance=event)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.save()
        messages.success(request, "Calendar event updated.")
        return redirect("calendar")
    return render(request, "portal/form.html", {
        "form": form,
        "title": f"Edit calendar event · {event.title}",
        "eyebrow": "SCHEDULE",
    })


@login_required
def announcement_create(request):
    _require_manage(request.user); team = _team(request.user)
    form = AnnouncementForm(request.POST or None, team=team)
    if form.is_valid():
        obj = form.save(commit=False); obj.team = team; obj.season = _active_season(team); obj.created_by = request.user; obj.save(); form.save_m2m()
        recipient_count = _deliver_announcement(obj) if obj.published else 0
        messages.success(request, f"Announcement posted to {recipient_count} portal user{'s' if recipient_count != 1 else ''}."); return redirect("dashboard")
    return render(request, "portal/form.html", {"form": form, "title": "Post announcement", "eyebrow": "TEAM NEWS"})


@login_required
def show_list(request):
    team = _team(request.user); today = timezone.localdate(); selected = _selected_team(request)
    qs = team.shows.select_related("season")
    if selected in TEAM_LEVELS:
        qs = qs.filter(classes__season_class__team_level__in=[selected, SeasonClass.TeamLevel.BOTH]).distinct()
    upcoming = qs.filter(show_date__gte=today).order_by("show_date")
    past = qs.filter(show_date__lt=today).order_by("-show_date")[:20]
    return render(request, "portal/show_list.html", {"upcoming": upcoming, "past": past, "can_manage": _can_manage(request.user), "selected_team": selected})


@login_required
def show_detail(request, pk):
    team = _team(request.user)
    can_manage = _can_manage(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    classes = show.classes.select_related("season_class").prefetch_related("entries__rider", "entries__result", "entries__rider__memberships")
    if can_manage:
        for show_class in classes:
            for entry in show_class.entries.all():
                membership = next((m for m in entry.rider.memberships.all() if m.season_id == show.season_id), None)
                entry.point_team_label = membership.get_team_level_display() if membership else "Team"
    return render(request, "portal/show_detail.html", {"show": show, "classes": classes, "can_manage": can_manage})


@login_required
def show_week_summary(request, pk):
    team = _team(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    can_manage = _can_manage(request.user)
    classes = show.classes.select_related("season_class").prefetch_related("entries__rider", "entries__result")
    roster = Rider.objects.filter(show_entries__show_class__show=show).distinct().order_by("last_name", "first_name")
    availability = ShowAvailability.objects.filter(show=show, rider__in=roster).select_related("rider")
    if not can_manage:
        availability = availability.filter(rider__in=_visible_riders(request.user, team))
    return render(request, "portal/show_week_summary.html", {
        "show": show, "classes": classes, "roster": roster, "availability": availability, "can_manage": can_manage,
    })


@login_required
@require_POST
def show_week_summary_send(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    show = get_object_or_404(Show, pk=pk, team=team)
    riders = Rider.objects.filter(show_entries__show_class__show=show).distinct()
    recipient_ids = set(riders.exclude(user__isnull=True).values_list("user_id", flat=True))
    recipient_ids.update(GuardianContact.objects.filter(rider_links__rider__in=riders, user__isnull=False).values_list("user_id", flat=True))
    recipient_ids.update(User.objects.filter(profile__team=team, profile__role__in=[UserProfile.Role.ADMIN, UserProfile.Role.COACH]).values_list("id", flat=True))
    title = f"Show week: {show.name}"
    body = f"{show.name} is {show.show_date:%A, %B %d}. Check the portal for entries, schedule, venue, and your availability status."
    created = 0
    for user in User.objects.filter(id__in=recipient_ids, is_active=True).select_related("profile"):
        notification = Notification.objects.create(user=user, title=title, body=body, link=f"/shows/{show.pk}/week/")
        created += 1
        profile = getattr(user, "profile", None)
        if settings.EMAIL_HOST and user.email and (not profile or profile.email_reminders):
            send_mail(title, body, settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=True)
    messages.success(request, f"Show-week summary sent to {created} portal user{'s' if created != 1 else ''}.")
    return redirect("show_week_summary", pk=show.pk)


@login_required
def show_create(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season before adding a show."); return redirect("show_list")
    form = ShowForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.team = team; obj.season = season; obj.save(); _sync_show_calendar(obj)
        messages.success(request, "Show added and synced to the calendar."); return redirect("show_detail", pk=obj.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add show", "eyebrow": "COMPETITION"})


@login_required
def show_edit(request, pk):
    _require_manage(request.user); team = _team(request.user)
    show = get_object_or_404(Show, pk=pk, team=team); form = ShowForm(request.POST or None, instance=show)
    if form.is_valid():
        form.save(); _sync_show_calendar(show); messages.success(request, "Show and calendar updated."); return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Edit show", "eyebrow": "COMPETITION"})


@login_required
def show_delete(request, pk):
    _require_manage(request.user); team = _team(request.user); show = get_object_or_404(Show, pk=pk, team=team)
    if request.method == "POST":
        show.delete(); messages.success(request, "Show deleted."); return redirect("show_list")
    return render(request, "portal/confirm_delete.html", {"object": show, "title": "Delete show", "message": "This also removes its show classes, entries, results, and linked calendar event."})


@login_required
@friendly_integrity_errors
def show_class_create(request, show_pk):
    _require_manage(request.user); team = _team(request.user); show = get_object_or_404(Show, pk=show_pk, team=team)
    if not show.season.season_classes.filter(active=True).exists():
        messages.error(request, "Set up season classes first, then add them to the show."); return redirect("season_setup")
    form = ShowClassForm(request.POST or None, show=show)
    if form.is_valid():
        obj = form.save(commit=False); obj.show = show; obj.save(); messages.success(request, "Season class added to this show."); return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add season class to show", "eyebrow": show.name})


@login_required
def show_class_edit(request, class_pk):
    _require_manage(request.user); team = _team(request.user)
    obj = get_object_or_404(ShowClass.objects.select_related("show"), pk=class_pk, show__team=team)
    form = ShowClassForm(request.POST or None, instance=obj, show=obj.show)
    if form.is_valid():
        form.save(); messages.success(request, "Show class updated."); return redirect("show_detail", pk=obj.show_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Edit {obj.display_name}", "eyebrow": obj.show.name})


@login_required
def show_class_delete(request, class_pk):
    _require_manage(request.user); team = _team(request.user)
    obj = get_object_or_404(ShowClass.objects.select_related("show"), pk=class_pk, show__team=team); show_id = obj.show_id
    if request.method == "POST":
        obj.delete(); messages.success(request, "Show class and its entries removed."); return redirect("show_detail", pk=show_id)
    return render(request, "portal/confirm_delete.html", {"object": obj, "title": "Remove class from show", "message": "Entries and results recorded under this show class will also be deleted."})


@login_required
@friendly_integrity_errors
def show_entry_create(request, show_pk):
    _require_manage(request.user); team = _team(request.user); show = get_object_or_404(Show, pk=show_pk, team=team)
    form = ShowEntryForm(request.POST or None, show=show, team=team)
    if form.is_valid():
        entry = form.save(commit=False)
        if entry.show_class.show_id != show.id or entry.rider.team_id != team.id: raise PermissionDenied
        entry.full_clean(); entry.save(); messages.success(request, "Rider entry added from season class assignment."); return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add rider entry", "eyebrow": show.name})


@login_required
def show_entry_edit(request, entry_pk):
    _require_manage(request.user); team = _team(request.user)
    entry = get_object_or_404(ShowEntry.objects.select_related("show_class__show", "rider"), pk=entry_pk, show_class__show__team=team); show = entry.show_class.show
    form = ShowEntryForm(request.POST or None, instance=entry, show=show, team=team)
    if form.is_valid():
        obj = form.save(commit=False); obj.full_clean(); obj.save(); messages.success(request, "Rider entry updated."); return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Edit entry · {entry.rider}", "eyebrow": show.name})


@login_required
def show_entry_delete(request, entry_pk):
    _require_manage(request.user); team = _team(request.user)
    entry = get_object_or_404(ShowEntry.objects.select_related("show_class__show", "rider"), pk=entry_pk, show_class__show__team=team); show_id = entry.show_class.show_id
    if request.method == "POST":
        entry.delete(); messages.success(request, "Rider entry removed."); return redirect("show_detail", pk=show_id)
    return render(request, "portal/confirm_delete.html", {"object": entry, "title": "Remove rider entry", "message": "Any result attached to this entry will also be deleted."})


@login_required
def show_result_edit(request, entry_pk):
    team = _team(request.user)
    entry_probe = get_object_or_404(ShowEntry.objects.select_related("show_class__show__season"), pk=entry_pk, show_class__show__team=team)
    if not _can_manage_points(request.user, entry_probe.show_class.show.season):
        raise PermissionDenied
    _ensure_season_open(entry_probe.show_class.show.season)
    entry = get_object_or_404(ShowEntry.objects.select_related("show_class__show", "rider"), pk=entry_pk, show_class__show__team=team)
    result, _ = ShowResult.objects.get_or_create(entry=entry); form = ShowResultForm(request.POST or None, instance=result)
    if form.is_valid():
        form.save(); messages.success(request, "Result saved."); return redirect("show_detail", pk=entry.show_class.show_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Result · {entry.rider}", "eyebrow": entry.show_class.display_name})



def _qualification_rows(season, team_level="all"):
    config, _ = SeasonScoringConfig.objects.get_or_create(season=season)
    memberships = season.memberships.select_related("rider").prefetch_related("classes", "qualification_overrides")
    if team_level in TEAM_LEVELS:
        memberships = memberships.filter(team_level=team_level)
    rows = []
    for membership in memberships:
        for season_class in membership.classes.filter(active=True).order_by("sort_order", "name"):
            total = ShowResult.objects.filter(
                entry__rider=membership.rider,
                entry__show_class__show__season=season,
                entry__show_class__season_class=season_class,
                entry__status__in=[ShowEntry.Status.PLANNED, ShowEntry.Status.ENTERED],
            ).aggregate(total=Sum("points"))["total"] or 0
            override = membership.qualification_overrides.filter(season_class=season_class).first()
            auto_qualified = total >= config.individual_qualification_points
            if override and override.status == QualificationOverride.Status.QUALIFIED:
                qualified = True
            elif override and override.status == QualificationOverride.Status.NOT_QUALIFIED:
                qualified = False
            else:
                qualified = auto_qualified
            rows.append({
                "membership": membership, "rider": membership.rider, "season_class": season_class,
                "points": total, "threshold": config.individual_qualification_points,
                "qualified": qualified, "override": override,
            })
    return rows


def _team_scoring_rows(season, team_level="all", include_riders=True):
    config, _ = SeasonScoringConfig.objects.get_or_create(season=season)
    levels = [SeasonMembership.TeamLevel.FUTURES, SeasonMembership.TeamLevel.UPPER]
    if team_level in TEAM_LEVELS:
        levels = [team_level]
    rows = []
    totals = {level: 0 for level in levels}
    shows = season.shows.order_by("show_date", "name")
    for show in shows:
        for level in levels:
            entries = ShowEntry.objects.filter(
                show_class__show=show, is_point_rider=True,
                status__in=[ShowEntry.Status.PLANNED, ShowEntry.Status.ENTERED],
                rider__memberships__season=season, rider__memberships__team_level=level,
            ).select_related("rider", "show_class__season_class", "result").distinct()
            class_rows = []
            show_total = 0
            for entry in entries:
                result = entry.result_or_none
                points = result.points if result and result.points is not None else 0
                show_total += points
                class_row = {
                    "class_name": entry.show_class.display_name,
                    "points": points,
                    "result": result,
                }
                if include_riders:
                    class_row["entry"] = entry
                    class_row["rider"] = entry.rider
                class_rows.append(class_row)
            totals[level] += show_total
            rows.append({"show": show, "team_level": level, "team_label": dict(SeasonMembership.TeamLevel.choices)[level], "points": show_total, "classes": class_rows})
    summary = [{
        "team_level": level, "team_label": dict(SeasonMembership.TeamLevel.choices)[level],
        "points": totals[level], "threshold": config.team_qualification_points,
        "qualified": totals[level] >= config.team_qualification_points,
    } for level in levels]
    return rows, summary


@login_required
def standings(request):
    team = _team(request.user)
    season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season before viewing standings.")
        return redirect("season_setup")
    selected = _selected_team(request)
    config, _ = SeasonScoringConfig.objects.get_or_create(season=season)
    individual = _qualification_rows(season, selected)
    can_manage = _can_manage(request.user)
    can_manage_points = _can_manage_points(request.user, season)
    team_rows, team_summary = _team_scoring_rows(season, selected, include_riders=can_manage_points)
    return render(request, "portal/standings.html", {
        "season": season, "config": config, "individual_rows": individual,
        "team_rows": team_rows, "team_summary": team_summary,
        "selected_team": selected, "can_manage": can_manage, "can_manage_points": can_manage_points,
    })


@login_required
def scoring_settings(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    config, _ = SeasonScoringConfig.objects.get_or_create(season=season)
    form = SeasonScoringConfigForm(request.POST or None, instance=config)
    if form.is_valid():
        form.save(); messages.success(request, "Season scoring and qualification rules updated."); return redirect("standings")
    return render(request, "portal/form.html", {"form": form, "title": "Scoring & qualification rules", "eyebrow": season.name})


@login_required
def qualification_override_edit(request, membership_pk, class_pk):
    team = _team(request.user)
    membership_probe = get_object_or_404(SeasonMembership.objects.select_related("season"), pk=membership_pk, season__team=team)
    if not _can_manage_points(request.user, membership_probe.season):
        raise PermissionDenied
    _ensure_season_open(membership_probe.season)
    membership = membership_probe
    membership = SeasonMembership.objects.select_related("rider", "season").get(pk=membership.pk)
    season_class = get_object_or_404(SeasonClass, pk=class_pk, season=membership.season)
    if not membership.classes.filter(pk=season_class.pk).exists():
        raise PermissionDenied("This rider is not assigned to that season class.")
    override, _ = QualificationOverride.objects.get_or_create(membership=membership, season_class=season_class)
    form = QualificationOverrideForm(request.POST or None, instance=override)
    if form.is_valid():
        obj = form.save()
        if obj.status == QualificationOverride.Status.AUTO and not obj.notes:
            obj.delete()
        messages.success(request, "Qualification status updated."); return redirect("standings")
    return render(request, "portal/form.html", {"form": form, "title": f"Qualification · {membership.rider}", "eyebrow": season_class.name})


@login_required
def standings_export(request):
    team = _team(request.user); season = _active_season(team)
    if season and not _can_manage_points(request.user, season):
        raise PermissionDenied
    if not season:
        return HttpResponse("No active season", status=400)
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="{season.name}-standings.csv"'
    writer = csv.writer(response)
    writer.writerow(["Individual qualification"])
    writer.writerow(["Team", "Rider", "Class", "Points", "Threshold", "Qualified"])
    for row in _qualification_rows(season):
        writer.writerow([row["membership"].get_team_level_display(), row["rider"], row["season_class"].name, row["points"], row["threshold"], "Yes" if row["qualified"] else "No"])
    writer.writerow([]); writer.writerow(["Team points"])
    writer.writerow(["Show", "Team", "Points rider", "Class", "Place", "Points"])
    team_rows, _ = _team_scoring_rows(season, include_riders=True)
    for row in team_rows:
        for cr in row["classes"]:
            result = cr["result"]
            writer.writerow([row["show"].name, row["team_label"], cr["entry"].rider, cr["entry"].show_class.display_name, result.place if result else "", cr["points"]])
    return response


@login_required
@require_POST
def point_rider_set(request, entry_pk):
    _require_manage(request.user); team = _team(request.user)
    entry = get_object_or_404(
        ShowEntry.objects.select_related("show_class__show", "rider"),
        pk=entry_pk, show_class__show__team=team,
    )
    show = entry.show_class.show
    membership = SeasonMembership.objects.filter(rider=entry.rider, season=show.season).first()
    if not membership:
        messages.error(request, "This rider is not on the season roster.")
        return redirect("show_detail", pk=show.pk)
    clear = request.POST.get("clear") == "1"
    if clear:
        entry.is_point_rider = False
        entry.save(update_fields=["is_point_rider"])
        messages.success(request, f"Cleared {entry.rider} as the points rider for {entry.show_class.display_name}.")
        return redirect("show_detail", pk=show.pk)
    for other in entry.show_class.entries.filter(is_point_rider=True).exclude(pk=entry.pk).select_related("rider"):
        other_membership = SeasonMembership.objects.filter(rider=other.rider, season=show.season).first()
        if other_membership and other_membership.team_level == membership.team_level:
            other.is_point_rider = False
            other.save(update_fields=["is_point_rider"])
    entry.is_point_rider = True
    update_fields = ["is_point_rider"]
    if entry.entry_type == ShowEntry.EntryType.INDIVIDUAL:
        entry.entry_type = ShowEntry.EntryType.BOTH
        update_fields.append("entry_type")
    entry.full_clean()
    entry.save(update_fields=update_fields)
    messages.success(request, f"{entry.rider} is the {membership.get_team_level_display()} points rider for {entry.show_class.display_name}.")
    return redirect("show_detail", pk=show.pk)


def _sync_lesson_calendar(lesson):
    CalendarEvent.objects.update_or_create(
        lesson=lesson,
        defaults={
            "team": lesson.team,
            "season": lesson.season,
            "title": lesson.title,
            "kind": CalendarEvent.Kind.LESSON,
            "starts_at": lesson.starts_at,
            "ends_at": lesson.ends_at,
            "all_day": False,
            "location": lesson.location,
            "description": lesson.notes,
            "visible_to_all": True,
        },
    )


def _seed_lesson_attendance(lesson):
    if not lesson.group_id:
        return
    for rider in lesson.group.riders.filter(active=True):
        LessonAttendance.objects.get_or_create(lesson=lesson, rider=rider)


def _volunteer_requirement(membership):
    if membership.team_level == SeasonMembership.TeamLevel.FUTURES:
        return membership.season.futures_volunteer_hours_required
    if membership.team_level == SeasonMembership.TeamLevel.UPPER:
        return membership.season.upper_volunteer_hours_required
    return 0


def _volunteer_progress_rows(season, riders):
    memberships = SeasonMembership.objects.filter(season=season, rider__in=riders).select_related("rider", "season").order_by("rider__last_name", "rider__first_name")
    rows = []
    for membership in memberships:
        approved = VolunteerLog.objects.filter(season=season, rider=membership.rider, status=VolunteerLog.Status.APPROVED).aggregate(total=Sum("hours"))["total"] or 0
        pending = VolunteerLog.objects.filter(season=season, rider=membership.rider, status=VolunteerLog.Status.PENDING).aggregate(total=Sum("hours"))["total"] or 0
        required = _volunteer_requirement(membership)
        remaining = max(required - approved, 0)
        rows.append({
            "membership": membership,
            "rider": membership.rider,
            "required": required,
            "approved": approved,
            "pending": pending,
            "remaining": remaining,
            "complete": required <= 0 or approved >= required,
        })
    return rows


@login_required
def lesson_list(request):
    team = _team(request.user)
    season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season before scheduling lessons.")
        return redirect("season_setup")
    lessons = season.lessons.select_related("group", "coach").prefetch_related("attendance__rider")
    if not _can_manage(request.user):
        visible = _visible_riders(request.user, team)
        lessons = lessons.filter(attendance__rider__in=visible).distinct()
    upcoming = lessons.filter(starts_at__gte=timezone.now()).order_by("starts_at")
    recent = lessons.filter(starts_at__lt=timezone.now()).order_by("-starts_at")[:12]
    return render(request, "portal/lesson_list.html", {
        "season": season, "upcoming": upcoming, "recent": recent, "can_manage": _can_manage(request.user),
    })


@login_required
def lesson_group_list(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    groups = season.lesson_groups.prefetch_related("riders").select_related("coach")
    return render(request, "portal/lesson_groups.html", {"season": season, "groups": groups})


@login_required
@friendly_integrity_errors
def lesson_group_create(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    form = LessonGroupForm(request.POST or None, season=season, team=team)
    if form.is_valid():
        obj = form.save(commit=False); obj.season = season; obj.save(); form.save_m2m()
        messages.success(request, "Lesson group created."); return redirect("lesson_group_list")
    return render(request, "portal/form.html", {"form": form, "title": "Create lesson group", "eyebrow": season.name})


@login_required
def lesson_group_edit(request, pk):
    _require_manage(request.user)
    team = _team(request.user); group = get_object_or_404(LessonGroup, pk=pk, season__team=team)
    form = LessonGroupForm(request.POST or None, instance=group, season=group.season, team=team)
    if form.is_valid():
        form.save(); messages.success(request, "Lesson group updated."); return redirect("lesson_group_list")
    return render(request, "portal/form.html", {"form": form, "title": f"Edit {group.name}", "eyebrow": group.season.name})


@login_required
def lesson_create(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    form = LessonForm(request.POST or None, season=season, team=team)
    if form.is_valid():
        base = form.save(commit=False)
        weeks = form.cleaned_data.get("recurrence_weeks", 1)
        created = []
        for index in range(weeks):
            lesson = Lesson.objects.create(
                team=team, season=season, group=base.group, coach=base.coach,
                title=base.title,
                starts_at=base.starts_at + timedelta(weeks=index),
                ends_at=(base.ends_at + timedelta(weeks=index)) if base.ends_at else None,
                location=base.location or (base.group.default_location if base.group else ""),
                notes=base.notes, cancelled=base.cancelled,
            )
            _seed_lesson_attendance(lesson); _sync_lesson_calendar(lesson); created.append(lesson)
        messages.success(request, f"Created {len(created)} lesson{'s' if len(created) != 1 else ''}.")
        return redirect("lesson_list")
    return render(request, "portal/form.html", {"form": form, "title": "Schedule lesson", "eyebrow": season.name})


@login_required
def lesson_detail(request, pk):
    team = _team(request.user)
    lesson = get_object_or_404(Lesson.objects.select_related("season", "group", "coach"), pk=pk, team=team)
    visible = _visible_riders(request.user, team)
    attendance = lesson.attendance.select_related("rider")
    if not _can_manage(request.user):
        attendance = attendance.filter(rider__in=visible)
        if not attendance.exists():
            raise PermissionDenied
    return render(request, "portal/lesson_detail.html", {"lesson": lesson, "attendance": attendance, "can_manage": _can_manage(request.user)})


@login_required
def lesson_edit(request, pk):
    _require_manage(request.user)
    team = _team(request.user); lesson = get_object_or_404(Lesson, pk=pk, team=team)
    form = LessonForm(request.POST or None, instance=lesson, season=lesson.season, team=team)
    if form.is_valid():
        obj = form.save(); _seed_lesson_attendance(obj); _sync_lesson_calendar(obj)
        messages.success(request, "Lesson updated."); return redirect("lesson_detail", pk=obj.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Edit lesson", "eyebrow": lesson.season.name})


@login_required
def lesson_delete(request, pk):
    _require_manage(request.user)
    team = _team(request.user); lesson = get_object_or_404(Lesson, pk=pk, team=team)
    if request.method == "POST":
        lesson.delete(); messages.success(request, "Lesson deleted."); return redirect("lesson_list")
    return render(request, "portal/confirm_delete.html", {"object": lesson, "title": "Delete lesson", "message": "Attendance and the linked calendar event will also be deleted."})


@login_required
def lesson_attendance_edit(request, attendance_pk):
    _require_manage(request.user)
    team = _team(request.user)
    attendance = get_object_or_404(LessonAttendance.objects.select_related("lesson", "rider"), pk=attendance_pk, lesson__team=team)
    form = LessonAttendanceForm(request.POST or None, instance=attendance)
    if form.is_valid():
        form.save(); messages.success(request, f"Attendance updated for {attendance.rider}."); return redirect("lesson_detail", pk=attendance.lesson_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Attendance · {attendance.rider}", "eyebrow": attendance.lesson.title})


@login_required
def show_availability(request, show_pk):
    team = _team(request.user); show = get_object_or_404(Show, pk=show_pk, team=team)
    roster = Rider.objects.filter(team=team, active=True, memberships__season=show.season).distinct().order_by("last_name", "first_name")
    if not _can_manage(request.user):
        roster = roster.filter(pk__in=_visible_riders(request.user, team).values("pk"))
    rows = []
    for rider in roster:
        response, _ = ShowAvailability.objects.get_or_create(show=show, rider=rider)
        rows.append(response)
    return render(request, "portal/show_availability.html", {"show": show, "responses": rows, "can_manage": _can_manage(request.user)})


@login_required
def show_availability_edit(request, show_pk, rider_pk):
    team = _team(request.user); show = get_object_or_404(Show, pk=show_pk, team=team)
    rider = get_object_or_404(Rider, pk=rider_pk, team=team, memberships__season=show.season)
    if not _can_manage(request.user) and not _visible_riders(request.user, team).filter(pk=rider.pk).exists():
        raise PermissionDenied
    response, _ = ShowAvailability.objects.get_or_create(show=show, rider=rider)
    form = ShowAvailabilityForm(request.POST or None, instance=response)
    if form.is_valid():
        obj = form.save(commit=False); obj.responded_by = request.user
        obj.responded_at = timezone.now() if obj.status != ShowAvailability.Status.PENDING else None
        obj.save(); messages.success(request, f"Availability updated for {rider}."); return redirect("show_availability", show_pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Show availability · {rider}", "eyebrow": show.name})


@login_required
def volunteer_dashboard(request):
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season before tracking volunteer hours."); return redirect("season_setup")
    riders = team.riders.filter(active=True, memberships__season=season).distinct() if _can_manage(request.user) else _visible_riders(request.user, team).filter(active=True, memberships__season=season).distinct()
    rows = _volunteer_progress_rows(season, riders)
    logs = VolunteerLog.objects.filter(season=season, rider__in=riders).select_related("rider", "submitted_by", "approved_by")
    return render(request, "portal/volunteer_dashboard.html", {
        "season": season, "rows": rows, "logs": logs[:60], "can_manage": _can_manage(request.user),
        "pending_count": logs.filter(status=VolunteerLog.Status.PENDING).count(),
    })


@login_required
def volunteer_submit(request):
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    visible = team.riders.filter(active=True) if _can_manage(request.user) else _visible_riders(request.user, team).filter(active=True)
    form = VolunteerLogForm(request.POST or None, team=team, season=season, visible_riders=visible)
    if form.is_valid():
        log = form.save(commit=False); log.season = season; log.submitted_by = request.user
        if _can_manage(request.user):
            log.status = VolunteerLog.Status.APPROVED; log.approved_by = request.user; log.approved_at = timezone.now()
        log.full_clean(); log.save()
        messages.success(request, "Volunteer hours recorded." if _can_manage(request.user) else "Volunteer hours submitted for coach approval.")
        return redirect("volunteer_dashboard")
    return render(request, "portal/form.html", {"form": form, "title": "Record volunteer hours", "eyebrow": season.name})


@login_required
def volunteer_review(request, pk):
    _require_manage(request.user)
    team = _team(request.user); log = get_object_or_404(VolunteerLog.objects.select_related("rider", "season"), pk=pk, season__team=team)
    form = VolunteerReviewForm(request.POST or None, instance=log)
    if form.is_valid():
        obj = form.save(commit=False)
        if obj.status == VolunteerLog.Status.APPROVED:
            obj.approved_by = request.user; obj.approved_at = timezone.now()
        else:
            obj.approved_by = None; obj.approved_at = None
        obj.save(); messages.success(request, "Volunteer entry reviewed."); return redirect("volunteer_dashboard")
    return render(request, "portal/form.html", {"form": form, "title": f"Review volunteer hours · {log.rider}", "eyebrow": f"{log.hours} hours · {log.service_date:%b %d, %Y}"})


@login_required
def volunteer_requirements(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    form = VolunteerRequirementForm(request.POST or None, instance=season)
    if form.is_valid():
        form.save(); messages.success(request, "Volunteer-hour requirements updated."); return redirect("volunteer_dashboard")
    return render(request, "portal/form.html", {"form": form, "title": "Volunteer-hour requirements", "eyebrow": season.name})


@login_required
def volunteer_export(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        return HttpResponse("No active season", status=400)
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="{season.name}-volunteer-hours.csv"'
    writer = csv.writer(response)
    writer.writerow(["Team", "Rider", "Required", "Approved", "Pending", "Remaining", "Complete"])
    riders = team.riders.filter(active=True, memberships__season=season).distinct()
    for row in _volunteer_progress_rows(season, riders):
        writer.writerow([row["membership"].get_team_level_display(), row["rider"], row["required"], row["approved"], row["pending"], row["remaining"], "Yes" if row["complete"] else "No"])
    writer.writerow([])
    writer.writerow(["Rider", "Date", "Hours", "Category", "Performed by", "Description", "Status", "Submitted by", "Approved by"])
    for log in season.volunteer_logs.select_related("rider", "submitted_by", "approved_by"):
        writer.writerow([log.rider, log.service_date, log.hours, log.get_category_display(), log.performed_by, log.description, log.get_status_display(), log.submitted_by or "", log.approved_by or ""])
    return response




def _season_rider_summary(season, riders):
    rows = []
    for rider in riders:
        membership = SeasonMembership.objects.filter(season=season, rider=rider).prefetch_related("classes").first()
        results = ShowResult.objects.filter(
            entry__rider=rider, entry__show_class__show__season=season
        ).select_related("entry__show_class__show")
        points = results.aggregate(total=Sum("points"))["total"] or 0
        shows = ShowEntry.objects.filter(rider=rider, show_class__show__season=season).values("show_class__show_id").distinct().count()
        wins = results.filter(place=1).count()
        attendance = LessonAttendance.objects.filter(
            rider=rider, lesson__season=season, status=LessonAttendance.Status.PRESENT
        ).count()
        approved_hours = VolunteerLog.objects.filter(
            rider=rider, season=season, status=VolunteerLog.Status.APPROVED
        ).aggregate(total=Sum("hours"))["total"] or 0
        rows.append({
            "rider": rider, "membership": membership, "points": points, "shows": shows,
            "wins": wins, "attendance": attendance, "volunteer_hours": approved_hours,
        })
    return rows


@login_required
def season_archive(request):
    team = _team(request.user)
    seasons = Season.objects.filter(team=team).order_by("-start_date")
    return render(request, "portal/season_archive.html", {
        "seasons": seasons, "can_manage": _can_manage(request.user)
    })


@login_required
def season_review(request, season_pk):
    team = _team(request.user)
    season = get_object_or_404(Season, pk=season_pk, team=team)
    points_access = _can_manage_points(request.user, season)
    if _can_manage(request.user) or points_access:
        riders = Rider.objects.filter(season_memberships__season=season).distinct().order_by("last_name", "first_name")
    else:
        riders = _visible_riders(request.user, team).filter(season_memberships__season=season).distinct()
    rider_rows = _season_rider_summary(season, riders)
    for row in rider_rows:
        row["can_history"] = _can_view_private_rider(request.user, row["rider"])
    qualification_rows = _qualification_rows(season) if points_access else [
        row for row in _qualification_rows(season) if row["rider"].pk in {r.pk for r in riders}
    ]
    awards = RiderAward.objects.filter(season=season, published=True).select_related("rider")
    if not (_can_manage(request.user) or points_access):
        awards = awards.filter(rider__in=riders)
    team_rows, team_summary = _team_scoring_rows(season, include_riders=points_access)
    return render(request, "portal/season_review.html", {
        "season": season, "rider_rows": rider_rows, "qualification_rows": qualification_rows,
        "awards": awards, "team_summary": team_summary, "can_manage": _can_manage(request.user),
        "can_manage_points": points_access,
    })


@login_required
@require_POST
def season_close(request, season_pk):
    if not _is_admin(request.user):
        raise PermissionDenied
    team = _team(request.user); season = get_object_or_404(Season, pk=season_pk, team=team)
    season.is_closed = True; season.is_active = False; season.closed_at = timezone.now()
    season.save(update_fields=["is_closed", "is_active", "closed_at"])
    messages.success(request, f"{season.name} is now archived.")
    return redirect("season_review", season_pk=season.pk)


@login_required
@require_POST
def season_reopen(request, season_pk):
    if not _is_admin(request.user):
        raise PermissionDenied
    team = _team(request.user); season = get_object_or_404(Season, pk=season_pk, team=team)
    season.is_closed = False; season.closed_at = None
    season.save(update_fields=["is_closed", "closed_at"])
    messages.success(request, f"{season.name} reopened for editing.")
    return redirect("season_review", season_pk=season.pk)


@login_required
def rider_history(request, pk):
    team = _team(request.user); rider = get_object_or_404(Rider, pk=pk, team=team)
    if not _can_view_private_rider(request.user, rider):
        raise PermissionDenied
    seasons = Season.objects.filter(memberships__rider=rider).distinct().order_by("-start_date")
    history = []
    for season in seasons:
        row = _season_rider_summary(season, [rider])[0]
        row["awards"] = RiderAward.objects.filter(season=season, rider=rider)
        if not _can_manage(request.user):
            row["awards"] = row["awards"].filter(published=True)
        notes = RiderDevelopmentNote.objects.filter(season=season, rider=rider).select_related("author")
        if not _can_manage(request.user):
            notes = notes.filter(family_visible=True)
        row["notes"] = notes
        history.append(row)
    return render(request, "portal/rider_history.html", {
        "rider": rider, "history": history, "can_manage": _can_manage(request.user)
    })


@login_required
def rider_summary_print(request, pk, season_pk):
    team = _team(request.user); rider = get_object_or_404(Rider, pk=pk, team=team)
    if not _can_view_private_rider(request.user, rider):
        raise PermissionDenied
    season = get_object_or_404(Season, pk=season_pk, team=team)
    summary = _season_rider_summary(season, [rider])[0]
    qualifications = [r for r in _qualification_rows(season) if r["rider"].pk == rider.pk]
    awards = RiderAward.objects.filter(season=season, rider=rider, published=True)
    notes = RiderDevelopmentNote.objects.filter(season=season, rider=rider, family_visible=True).select_related("author")
    return render(request, "portal/rider_summary_print.html", {
        "rider": rider, "season": season, "summary": summary,
        "qualifications": qualifications, "awards": awards, "notes": notes,
    })


@login_required
def development_note_add(request, pk, season_pk):
    _require_manage(request.user); team = _team(request.user)
    rider = get_object_or_404(Rider, pk=pk, team=team); season = get_object_or_404(Season, pk=season_pk, team=team)
    form = RiderDevelopmentNoteForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.rider = rider; obj.season = season; obj.author = request.user; obj.save()
        messages.success(request, "Development note added."); return redirect("rider_history", pk=rider.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Development note · {rider.display_name}", "eyebrow": season.name})


@login_required
def award_list(request, season_pk):
    team = _team(request.user); season = get_object_or_404(Season, pk=season_pk, team=team)
    awards = RiderAward.objects.filter(season=season).select_related("rider")
    if not _can_manage(request.user):
        awards = awards.filter(published=True, rider__in=_visible_riders(request.user, team))
    return render(request, "portal/award_list.html", {"season": season, "awards": awards, "can_manage": _can_manage(request.user)})


@login_required
@friendly_integrity_errors
def award_add(request, season_pk):
    _require_manage(request.user); team = _team(request.user); season = get_object_or_404(Season, pk=season_pk, team=team)
    form = RiderAwardForm(request.POST or None, season=season)
    if form.is_valid():
        obj = form.save(commit=False); obj.season = season; obj.created_by = request.user; obj.save()
        messages.success(request, "Award added."); return redirect("award_list", season_pk=season.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add award or recognition", "eyebrow": season.name})


@login_required
def team_record_book(request):
    team = _team(request.user)
    records = []
    for season in Season.objects.filter(team=team).order_by("-start_date"):
        for rider in Rider.objects.filter(season_memberships__season=season).distinct():
            points = ShowResult.objects.filter(entry__rider=rider, entry__show_class__show__season=season).aggregate(total=Sum("points"))["total"] or 0
            wins = ShowResult.objects.filter(entry__rider=rider, entry__show_class__show__season=season, place=1).count()
            if points or wins:
                records.append({"season": season, "rider": rider, "points": points, "wins": wins})
    records.sort(key=lambda x: (x["points"], x["wins"]), reverse=True)
    awards = RiderAward.objects.filter(season__team=team, published=True).select_related("season", "rider")[:50]
    return render(request, "portal/team_record_book.html", {"records": records[:25], "awards": awards})



@login_required
def rider_guardian_link(request, rider_pk):
    _require_manage(request.user)
    team = _team(request.user)
    rider = get_object_or_404(Rider, pk=rider_pk, team=team)

    existing_ids = RiderGuardian.objects.filter(rider=rider).values_list("guardian_id", flat=True)
    guardians = GuardianContact.objects.filter(team=team).exclude(pk__in=existing_ids).order_by("last_name", "first_name")

    if request.method == "POST":
        guardian_id = request.POST.get("guardian")
        relationship = (request.POST.get("relationship") or "Parent/Guardian").strip()
        primary_contact = request.POST.get("primary_contact") == "on"
        guardian = get_object_or_404(GuardianContact, pk=guardian_id, team=team)

        link, created = RiderGuardian.objects.get_or_create(
            rider=rider,
            guardian=guardian,
            defaults={
                "relationship": relationship,
                "primary_contact": primary_contact,
            },
        )
        if not created:
            messages.info(request, f"{guardian} is already linked to {rider}.")
        else:
            if guardian.user_id:
                rider.guardians.add(guardian.user)
            messages.success(request, f"{guardian} linked to {rider}.")
        return redirect("rider_detail", pk=rider.pk)

    return render(request, "portal/rider_guardian_link.html", {
        "rider": rider,
        "guardians": guardians,
    })


@login_required
@require_POST
def rider_guardian_unlink(request, rider_pk, link_pk):
    _require_manage(request.user)
    team = _team(request.user)
    rider = get_object_or_404(Rider, pk=rider_pk, team=team)
    link = get_object_or_404(RiderGuardian.objects.select_related("guardian"), pk=link_pk, rider=rider)

    guardian = link.guardian
    link.delete()

    if guardian.user_id:
        # Keep the legacy M2M only if this same user remains linked to the rider
        still_linked = RiderGuardian.objects.filter(rider=rider, guardian__user_id=guardian.user_id).exists()
        if not still_linked:
            rider.guardians.remove(guardian.user)

    messages.success(request, f"{guardian} unlinked from {rider}.")
    return redirect("rider_detail", pk=rider.pk)


@login_required
def committee_list(request):
    team = _team(request.user)
    season = _active_season(team)
    assignments = CommitteeAssignment.objects.filter(team=team, season=season).select_related("user") if season else []
    return render(request, "portal/committee_list.html", {
        "season": season, "assignments": assignments, "can_manage": _can_manage(request.user)
    })


@login_required
@friendly_integrity_errors
def committee_assignment_create(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season before assigning committee chairs.")
        return redirect("committee_list")
    form = CommitteeAssignmentForm(request.POST or None, team=team, season=season)
    if form.is_valid():
        obj = form.save(commit=False); obj.team = team; obj.season = season; obj.save()
        messages.success(request, "Committee assignment saved.")
        return redirect("committee_list")
    return render(request, "portal/form.html", {"form": form, "title": "Assign committee chair", "eyebrow": "COMMITTEES"})


@login_required
def committee_assignment_edit(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    obj = get_object_or_404(CommitteeAssignment, pk=pk, team=team)
    form = CommitteeAssignmentForm(request.POST or None, instance=obj, team=team)
    if form.is_valid():
        form.save(); messages.success(request, "Committee assignment updated."); return redirect("committee_list")
    return render(request, "portal/form.html", {"form": form, "title": "Edit committee assignment", "eyebrow": "COMMITTEES"})


@login_required
def show_planning(request, pk):
    team = _team(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    can_plan = _can_plan_show(request.user, show)
    leads = show.lead_assignments.filter(active=True).select_related("user")
    items = show.planning_items.select_related("assigned_to", "claimed_by")
    if not can_plan:
        items = items.filter(family_visible=True)
    return render(request, "portal/show_planning.html", {
        "show": show, "leads": leads, "items": items, "can_plan": can_plan, "can_manage": _can_manage(request.user)
    })


@login_required
@friendly_integrity_errors
def show_lead_add(request, pk):
    _require_manage(request.user)
    team = _team(request.user); show = get_object_or_404(Show, pk=pk, team=team)
    form = ShowLeadAssignmentForm(request.POST or None, team=team, show=show)
    if form.is_valid():
        obj = form.save(commit=False); obj.show = show; obj.save()
        messages.success(request, "Show lead assigned."); return redirect("show_planning", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Assign show lead · {show.name}", "eyebrow": "SHOW PLANNING"})


@login_required
def show_planning_item_add(request, pk):
    team = _team(request.user); show = get_object_or_404(Show, pk=pk, team=team)
    if not _can_plan_show(request.user, show):
        raise PermissionDenied
    form = ShowPlanningItemForm(request.POST or None, team=team)
    if form.is_valid():
        obj = form.save(commit=False); obj.show = show; obj.save()
        messages.success(request, "Show planning item added."); return redirect("show_planning", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Add show planning item · {show.name}", "eyebrow": "SHOW PLANNING"})


@login_required
def show_planning_item_edit(request, item_pk):
    team = _team(request.user); item = get_object_or_404(ShowPlanningItem.objects.select_related("show"), pk=item_pk, show__team=team)
    if not _can_plan_show(request.user, item.show):
        raise PermissionDenied
    form = ShowPlanningItemForm(request.POST or None, instance=item, team=team)
    if form.is_valid():
        form.save(); messages.success(request, "Show planning item updated."); return redirect("show_planning", pk=item.show_id)
    return render(request, "portal/form.html", {"form": form, "title": "Edit show planning item", "eyebrow": "SHOW PLANNING"})


@login_required
@require_POST
def show_planning_item_claim(request, item_pk):
    team = _team(request.user)
    item = get_object_or_404(ShowPlanningItem.objects.select_related("show"), pk=item_pk, show__team=team, family_visible=True)
    if item.claimed_by_id and item.claimed_by_id != request.user.id and not _can_plan_show(request.user, item.show):
        raise PermissionDenied
    if request.POST.get("clear") and (item.claimed_by_id == request.user.id or _can_plan_show(request.user, item.show)):
        item.claimed_by = None
    elif not item.claimed_by_id:
        item.claimed_by = request.user
    item.save(update_fields=["claimed_by"])
    return redirect("show_planning", pk=item.show_id)


@login_required
def notification_list(request):
    notifications = request.user.portal_notifications.select_related("announcement").all()[:100]
    return render(request, "portal/notifications.html", {"notifications": notifications})


@login_required
@require_POST
def notification_read(request, pk):
    notification = get_object_or_404(Notification, pk=pk, user=request.user)
    if not notification.read_at:
        notification.read_at = timezone.now(); notification.save(update_fields=["read_at"])
    return redirect(notification.link or "notification_list")


@login_required
@require_POST
def notification_read_all(request):
    request.user.portal_notifications.filter(read_at__isnull=True).update(read_at=timezone.now())
    return redirect("notification_list")


@login_required
def notification_preferences(request):
    if not hasattr(request.user, "profile"):
        raise PermissionDenied
    form = NotificationPreferenceForm(request.POST or None, instance=request.user.profile)
    if form.is_valid():
        form.save(); messages.success(request, "Notification preferences updated."); return redirect("notification_list")
    return render(request, "portal/form.html", {"form": form, "title": "Notification preferences", "eyebrow": "COMMUNICATIONS"})


@login_required
def user_list(request):
    _require_manage(request.user)
    team = _team(request.user)
    users = User.objects.filter(profile__team=team).select_related("profile", "rider_record", "guardian_contact").order_by("last_name", "first_name", "username")
    if not _is_admin(request.user):
        users = users.filter(profile__role__in=[UserProfile.Role.PARENT, UserProfile.Role.RIDER])
    return render(request, "portal/user_list.html", {"users": users, "is_admin_actor": _is_admin(request.user)})


@login_required
def user_create(request, rider_pk=None, guardian_pk=None):
    _require_manage(request.user)
    team = _team(request.user)
    rider = get_object_or_404(Rider, pk=rider_pk, team=team, user__isnull=True) if rider_pk else None
    guardian = get_object_or_404(GuardianContact, pk=guardian_pk, team=team, user__isnull=True) if guardian_pk else None
    form = UserOnboardingForm(request.POST or None, team=team, actor=request.user, initial_rider=rider, initial_guardian=guardian)
    if form.is_valid():
        user = form.save()
        messages.success(request, f"Login created for {user.get_full_name() or user.username}. They must change the temporary password at first login.")
        return redirect("user_list")
    return render(request, "portal/user_form.html", {"form": form, "title": "Add user", "eyebrow": "USER ONBOARDING", "default_password_configured": bool(settings.DEFAULT_TEMP_PASSWORD)})


@login_required
def user_edit(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    target = get_object_or_404(User.objects.select_related("profile"), pk=pk, profile__team=team)
    if not _can_manage_user(request.user, target):
        raise PermissionDenied
    form = UserAccountEditForm(request.POST or None, team=team, actor=request.user, user_obj=target)
    if form.is_valid():
        form.save(); messages.success(request, "User account and links updated."); return redirect("user_list")
    return render(request, "portal/user_form.html", {"form": form, "title": f"Manage {target.get_full_name() or target.username}", "eyebrow": "USERS", "target_user": target})


@login_required
def user_reset_password(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    target = get_object_or_404(User.objects.select_related("profile"), pk=pk, profile__team=team)
    if not _can_manage_user(request.user, target):
        raise PermissionDenied
    if target == request.user:
        messages.error(request, "Use Change password for your own account."); return redirect("user_list")
    form = TemporaryPasswordResetForm(request.POST or None, user_obj=target)
    if request.method == "POST" and form.is_valid():
        target.set_password(form.cleaned_data["resolved_password"]); target.save(update_fields=["password"])
        target.profile.must_change_password = True; target.profile.save(update_fields=["must_change_password"])
        messages.success(request, f"Temporary password reset for {target.get_full_name() or target.username}. A password change will be required at next login.")
        return redirect("user_list")
    return render(request, "portal/user_form.html", {"form": form, "title": "Reset temporary password", "eyebrow": target.username, "default_password_configured": bool(settings.DEFAULT_TEMP_PASSWORD)})


@login_required
def password_change_required(request):
    form = PasswordChangeForm(request.user, request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save(); update_session_auth_hash(request, user)
        if hasattr(user, "profile"):
            user.profile.must_change_password = False; user.profile.save(update_fields=["must_change_password"])
        messages.success(request, "Password changed. Your account is ready to use.")
        return redirect("dashboard")
    return render(request, "registration/password_change_required.html", {"form": form})
