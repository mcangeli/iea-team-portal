# IEA Team Portal v1.5.5

## User & Family Onboarding

### Account management
- Added portal-native Users page.
- Added guided user creation with role, rider/guardian linking, login credentials, and temporary-password setup.
- Added Create login / Manage login actions on rider records.
- Added Create login / Manage login actions for guardian contacts.
- Added user account editing for name, email, active state, role, and linked rider/guardian record.
- Coaches are limited to Parent/Guardian and Rider account management; only Administrators can grant Coach/Admin roles.

### First-login password requirement
- Added `UserProfile.must_change_password`.
- Added migration `0007_v155_user_onboarding`.
- Added optional `DEFAULT_TEMP_PASSWORD` environment setting.
- New users created through the portal must change their temporary password at first login.
- Added middleware that blocks normal portal navigation until the password change succeeds.
- Added Coach/Admin temporary-password reset action; reset accounts must change the new temporary password at next login.
- The server-configured temporary password is not rendered back into HTML.

### Compatibility
- Existing accounts are migrated with `must_change_password=False`, so current users are not unexpectedly locked out.
- Existing `.env`, PostgreSQL volume, media volume, reverse proxy, backup/preflight process, v1.5.0 lessons/attendance/availability/volunteer features, and scoring privacy behavior remain unchanged.
