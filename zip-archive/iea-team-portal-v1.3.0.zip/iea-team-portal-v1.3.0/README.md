# IEA Team Portal v1.3.0

A self-hosted Django portal for an interscholastic equestrian team with separate Futures (grades 4–8) and Upper School (grades 9–12) season rosters, season class assignments, shows, results, calendar, rider profiles, parent/guardian contacts, announcements, and role-based access.

The application uses the IEA-inspired primary blue `#007297` and related palette, but does not bundle official IEA logo artwork. Upload only branding your team is authorized to use. This is a private team operations portal and is not an official IEA website or replacement for AccessIEA.

## v1.3.0 highlights

- Season class setup no longer has the redundant Division field.
- Rider classes are assigned once at the season level.
- Show entry forms enforce those season class assignments.
- Show classes and rider entries can be edited/deleted in the normal UI.
- Shows automatically create/update linked calendar events.
- Rider points are scoped to the active season.
- Futures/Upper filters are available across roster, shows, families, and season setup.
- Coach/admin CSV exports are available for riders and parent/guardian contacts.
- New migration preflight and automatic database backup upgrade workflow.

## Persistent deployment layout

Keep the live environment file outside release directories:

```text
/opt/iea-team-portal/
├── .env
├── backups/
├── iea-team-portal-v1.2.3/
└── iea-team-portal-v1.3.0/
```

The Compose project and volumes remain stable:

```text
iea-team-portal_postgres_data
iea-team-portal_media_data
```

Your existing host Apache/Nginx/Caddy proxy should continue sending HTTPS traffic to the local gateway, normally:

```text
http://127.0.0.1:8088
```

## Upgrade to v1.3.0

Extract the release under `/opt/iea-team-portal/`, then run the new upgrade helper from the v1.3.0 directory:

```bash
cd /opt/iea-team-portal/iea-team-portal-v1.3.0
chmod +x portalctl
./portalctl upgrade
```

`upgrade` will:

1. Start the shared PostgreSQL service if needed.
2. Create a timestamped SQL backup under `/opt/iea-team-portal/backups/`.
3. Build the v1.3.0 web image.
4. Run schema preflight.
5. Start the new release.
6. Django then runs migrations with `--fake-initial` before Gunicorn starts.

Check status:

```bash
./portalctl ps
./portalctl logs --tail=150 web
./portalctl exec web python manage.py showmigrations portal
./portalctl exec web python manage.py check
```

Expected portal migrations:

```text
[X] 0001_initial
[X] 0002_competition_management
[X] 0003_team_levels_season_classes_guardians
[X] 0004_v130_workflow
```

## Migration preflight

Run independently at any time:

```bash
./portalctl preflight
```

The check detects an important failure mode seen in earlier upgrades: an initial Django schema that is only partly present while its migration record is missing. `migrate --fake-initial` is safe when the expected initial tables already exist as a set, but it cannot safely reconcile an arbitrary half-created initial schema. v1.3.0 stops with a clear diagnostic before Django attempts to recreate a table/constraint in that case.

Do not use `migrate --fake` blindly to bypass a failed preflight.

## Normal management commands

`portalctl` still passes ordinary commands through to Docker Compose:

```bash
./portalctl up -d --build
./portalctl ps
./portalctl logs -f web
./portalctl restart web
./portalctl exec web python manage.py check
```

## Shared `.env`

By default `portalctl` uses the `.env` one directory above the release. A custom persistent location is also supported:

```bash
export PORTAL_ENV_FILE=/some/permanent/path/iea-team.env
./portalctl upgrade
```

## Team workflow

### Season setup
1. Create/activate a season in Admin.
2. Create season classes and designate each as Futures, Upper School, or Both.
3. Assign each rider to Futures or Upper School for the season.
4. Assign the rider's season classes.

### Shows
1. Create a show. Its calendar event is created automatically.
2. Add classes from that season's class catalog.
3. Add rider entries. Only valid season-assigned combinations are accepted.
4. Record results and points.
5. Edit/remove classes or entries directly from the show page when needed.

### Family directory
Parent/guardian contact records are independent of portal logins and can store name, email, phone, relationship, primary-contact status, notes, and rider links.

## Roles
- Administrator
- Coach
- Parent/Guardian
- Rider

Parents/riders are restricted to linked rider information; coaches/admins can manage the team-wide operational data.
