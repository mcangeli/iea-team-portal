# IEA Team Portal v1.3.0

## Season & Show Workflow

### Class setup cleanup
- Removed the redundant **Division** field from season class setup.
- Rider season assignment now focuses on team level (Futures / Upper School), season classes, and notes.
- Legacy `division` / `class_level` database values are preserved rather than destructively dropped during upgrade.
- Show classes continue to reference the season class catalog as the source of truth.

### Show workflow
- Show classes can now be edited or removed from the normal portal UI.
- Rider show entries can now be edited or removed from the normal portal UI.
- Shows can now be deleted from the portal with an explicit confirmation screen.
- Entry forms narrow riders to those assigned to the selected season class/team when a class is selected.
- Missing results are rendered safely on show detail pages.

### Calendar sync
- Every show now has one linked calendar event.
- Creating/editing a show creates or updates its calendar event automatically.
- Existing shows receive linked calendar events during migration 0004.
- Shows without a start time are represented as all-day events.
- Deleting a show removes its linked calendar event.

### Active-season reporting
- Rider profile point totals are scoped to the active season.
- Futures / Upper School filters were added to Riders, Shows, Parents, and Season Setup.
- Coach/admin CSV exports were added for rider roster and parent/guardian directory.

### Safer upgrades
- New `./portalctl preflight` checks for partially-present initial Django schemas before migrations run.
- New `./portalctl upgrade` creates a timestamped PostgreSQL dump before building/preflighting/starting the release.
- Docker startup now runs schema preflight before `migrate --fake-initial`.
- Persistent `.env`, database volume, media volume, and loopback gateway architecture are unchanged.

## Migration
- Adds `portal.0004_v130_workflow`.
- Removes `SeasonClass.division` from Django model state while intentionally retaining the legacy physical column for compatibility.
- Adds `CalendarEvent.all_day` and a one-to-one `CalendarEvent.show` link using idempotent PostgreSQL schema operations.
