import csv
from datetime import datetime, time

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db.models import Q, Sum
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import (
    AnnouncementForm, CalendarEventForm, GuardianContactForm, RiderForm,
    SeasonClassForm, SeasonMembershipForm, ShowClassForm, ShowEntryForm,
    ShowForm, ShowResultForm,
)
from .models import (
    Announcement, CalendarEvent, GuardianContact, Rider, RiderGuardian, Season,
    SeasonClass, SeasonMembership, Show, ShowClass, ShowEntry, ShowResult, UserProfile,
)

TEAM_LEVELS = {SeasonMembership.TeamLevel.FUTURES, SeasonMembership.TeamLevel.UPPER}


def _team(user):
    if user.is_superuser:
        return user.profile.team if hasattr(user, "profile") else None
    if not hasattr(user, "profile") or not user.profile.team:
        raise PermissionDenied("Your account is not assigned to a team.")
    return user.profile.team


def _can_manage(user):
    return user.is_superuser or (
        hasattr(user, "profile") and user.profile.role in [UserProfile.Role.ADMIN, UserProfile.Role.COACH]
    )


def _require_manage(user):
    if not _can_manage(user):
        raise PermissionDenied


def _visible_riders(user, team):
    qs = team.riders.all()
    if hasattr(user, "profile") and user.profile.role == UserProfile.Role.PARENT:
        qs = qs.filter(Q(guardians=user) | Q(guardian_links__guardian__user=user)).distinct()
    elif hasattr(user, "profile") and user.profile.role == UserProfile.Role.RIDER:
        qs = qs.filter(user=user)
    return qs


def _active_season(team):
    return team.seasons.filter(is_active=True).first()


def _selected_team(request):
    value = request.GET.get("team", "all").lower()
    return value if value in TEAM_LEVELS | {"all", "unassigned"} else "all"


def _sync_show_calendar(show):
    tz = timezone.get_current_timezone()
    clock = show.start_time or time(0, 0)
    starts_at = timezone.make_aware(datetime.combine(show.show_date, clock), tz)
    location = " · ".join(part for part in [show.venue, show.address] if part)
    CalendarEvent.objects.update_or_create(
        show=show,
        defaults={
            "team": show.team,
            "season": show.season,
            "title": show.name,
            "kind": CalendarEvent.Kind.SHOW,
            "starts_at": starts_at,
            "ends_at": None,
            "all_day": not bool(show.start_time),
            "location": location,
            "description": show.notes,
            "visible_to_all": True,
        },
    )


@login_required
def dashboard(request):
    team = _team(request.user)
    if not team:
        return render(request, "portal/no_team.html")
    season = _active_season(team)
    now = timezone.now()
    today = timezone.localdate()
    announcements = team.announcements.filter(published=True).filter(Q(expires_at__isnull=True) | Q(expires_at__gt=now))[:5]
    events = team.events.filter(starts_at__gte=now)[:6]
    riders = _visible_riders(request.user, team).filter(active=True)
    shows = team.shows.filter(show_date__gte=today).order_by("show_date")[:4]
    memberships = season.memberships.select_related("rider") if season else SeasonMembership.objects.none()
    return render(request, "portal/dashboard.html", {
        "season": season, "announcements": announcements, "events": events, "riders": riders,
        "shows": shows, "can_manage": _can_manage(request.user),
        "futures_count": memberships.filter(team_level=SeasonMembership.TeamLevel.FUTURES).count(),
        "upper_count": memberships.filter(team_level=SeasonMembership.TeamLevel.UPPER).count(),
    })


@login_required
def rider_list(request):
    team = _team(request.user)
    qs = _visible_riders(request.user, team).prefetch_related("memberships")
    season = _active_season(team)
    selected = _selected_team(request)
    if season:
        futures = qs.filter(memberships__season=season, memberships__team_level=SeasonMembership.TeamLevel.FUTURES).distinct()
        upper = qs.filter(memberships__season=season, memberships__team_level=SeasonMembership.TeamLevel.UPPER).distinct()
        unassigned = qs.exclude(memberships__season=season).distinct()
    else:
        futures = Rider.objects.none(); upper = Rider.objects.none(); unassigned = qs
    return render(request, "portal/rider_list.html", {
        "riders": qs, "futures": futures, "upper": upper, "unassigned": unassigned,
        "season": season, "can_manage": _can_manage(request.user), "selected_team": selected,
    })


@login_required
def rider_export(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team); selected = _selected_team(request)
    qs = team.riders.filter(active=True).order_by("last_name", "first_name")
    if season and selected in TEAM_LEVELS:
        qs = qs.filter(memberships__season=season, memberships__team_level=selected).distinct()
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="rider-roster.csv"'
    writer = csv.writer(response)
    writer.writerow(["Rider", "Email", "Grade", "School", "Team", "Season classes", "IEA member number"])
    for rider in qs:
        membership = rider.memberships.filter(season=season).prefetch_related("classes").first() if season else None
        writer.writerow([
            str(rider), rider.email, rider.grade or "", rider.school,
            membership.get_team_level_display() if membership else "Unassigned",
            "; ".join(c.name for c in membership.classes.all()) if membership else "",
            rider.iea_member_number,
        ])
    return response


@login_required
def rider_detail(request, pk):
    team = _team(request.user)
    rider = get_object_or_404(Rider.objects.prefetch_related("memberships__classes", "guardian_links__guardian"), pk=pk, team=team)
    if not _can_manage(request.user):
        allowed = rider.user_id == request.user.id or rider.guardians.filter(pk=request.user.pk).exists() or rider.guardian_links.filter(guardian__user=request.user).exists()
        if not allowed:
            raise PermissionDenied
    active_season = _active_season(team)
    entries = rider.show_entries.filter(result__isnull=False)
    if active_season:
        entries = entries.filter(show_class__show__season=active_season)
    season_points = entries.aggregate(total=Sum("result__points"))["total"] or 0
    return render(request, "portal/rider_detail.html", {
        "rider": rider, "season_points": season_points, "can_manage": _can_manage(request.user),
        "active_season": active_season,
    })


@login_required
def rider_create(request):
    _require_manage(request.user); team = _team(request.user)
    form = RiderForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.team = team; obj.save()
        messages.success(request, "Rider added. Now assign the rider to the active season and classes.")
        return redirect("rider_detail", pk=obj.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add rider", "eyebrow": "ROSTER"})


@login_required
def rider_edit(request, pk):
    _require_manage(request.user); team = _team(request.user)
    obj = get_object_or_404(Rider, pk=pk, team=team)
    form = RiderForm(request.POST or None, request.FILES or None, instance=obj)
    if form.is_valid():
        form.save(); messages.success(request, "Rider updated."); return redirect("rider_detail", pk=obj.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Edit rider", "eyebrow": "ROSTER"})


@login_required
def rider_membership_edit(request, pk, season_pk=None):
    _require_manage(request.user); team = _team(request.user)
    rider = get_object_or_404(Rider, pk=pk, team=team)
    season = get_object_or_404(Season, pk=season_pk, team=team) if season_pk else _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("rider_detail", pk=rider.pk)
    membership, _ = SeasonMembership.objects.get_or_create(rider=rider, season=season)
    form = SeasonMembershipForm(request.POST or None, instance=membership, season=season)
    if form.is_valid():
        form.save(); messages.success(request, f"{season.name} team and class assignments updated.")
        return redirect("rider_detail", pk=rider.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"{rider.display_name} · {season.name}", "eyebrow": "SEASON ASSIGNMENT"})


@login_required
def rider_guardian_add(request, pk):
    _require_manage(request.user); team = _team(request.user)
    rider = get_object_or_404(Rider, pk=pk, team=team)
    form = GuardianContactForm(request.POST or None)
    if form.is_valid():
        relationship = form.cleaned_data.get("relationship", "")
        primary = form.cleaned_data.get("primary_contact", False)
        guardian = form.save(commit=False); guardian.team = team; guardian.save()
        RiderGuardian.objects.create(rider=rider, guardian=guardian, relationship=relationship, primary_contact=primary)
        messages.success(request, "Parent/guardian contact added."); return redirect("rider_detail", pk=rider.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Add parent/guardian · {rider.display_name}", "eyebrow": "FAMILY CONTACT"})


@login_required
def rider_guardian_edit(request, pk, guardian_pk):
    _require_manage(request.user); team = _team(request.user)
    rider = get_object_or_404(Rider, pk=pk, team=team)
    link = get_object_or_404(RiderGuardian.objects.select_related("guardian"), rider=rider, guardian_id=guardian_pk, guardian__team=team)
    form = GuardianContactForm(request.POST or None, instance=link.guardian, initial={"relationship": link.relationship, "primary_contact": link.primary_contact})
    if form.is_valid():
        form.save(); link.relationship = form.cleaned_data.get("relationship", ""); link.primary_contact = form.cleaned_data.get("primary_contact", False); link.save()
        messages.success(request, "Parent/guardian contact updated."); return redirect("rider_detail", pk=rider.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Edit {link.guardian.display_name}", "eyebrow": "FAMILY CONTACT"})


@login_required
def parent_list(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team); selected = _selected_team(request)
    guardians = team.guardian_contacts.prefetch_related("rider_links__rider").all()
    if season and selected in TEAM_LEVELS:
        guardians = guardians.filter(rider_links__rider__memberships__season=season, rider_links__rider__memberships__team_level=selected).distinct()
    return render(request, "portal/parent_list.html", {"guardians": guardians, "selected_team": selected, "season": season})


@login_required
def parent_export(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team); selected = _selected_team(request)
    guardians = team.guardian_contacts.prefetch_related("rider_links__rider").all()
    if season and selected in TEAM_LEVELS:
        guardians = guardians.filter(rider_links__rider__memberships__season=season, rider_links__rider__memberships__team_level=selected).distinct()
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="parent-guardian-directory.csv"'
    writer = csv.writer(response); writer.writerow(["Parent/Guardian", "Email", "Phone", "Riders", "Relationships"])
    for g in guardians:
        links = list(g.rider_links.select_related("rider").all())
        writer.writerow([g.display_name, g.email, g.phone, "; ".join(str(x.rider) for x in links), "; ".join(x.relationship for x in links if x.relationship)])
    return response


@login_required
def season_setup(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team); selected = _selected_team(request)
    classes = season.season_classes.all() if season else SeasonClass.objects.none()
    memberships = season.memberships.select_related("rider").prefetch_related("classes") if season else SeasonMembership.objects.none()
    if selected in TEAM_LEVELS:
        memberships = memberships.filter(team_level=selected)
    return render(request, "portal/season_setup.html", {"season": season, "classes": classes, "memberships": memberships, "selected_team": selected})


@login_required
def season_class_create(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    initial = {"discipline": team.discipline if team.discipline != "multi" else "hunt_seat"}
    form = SeasonClassForm(request.POST or None, initial=initial)
    if form.is_valid():
        obj = form.save(commit=False); obj.season = season; obj.save()
        messages.success(request, "Season class added."); return redirect("season_setup")
    return render(request, "portal/form.html", {"form": form, "title": "Add season class", "eyebrow": season.name})


@login_required
def season_class_edit(request, class_pk):
    _require_manage(request.user); team = _team(request.user)
    season_class = get_object_or_404(SeasonClass, pk=class_pk, season__team=team)
    form = SeasonClassForm(request.POST or None, instance=season_class)
    if form.is_valid():
        form.save(); messages.success(request, "Season class updated."); return redirect("season_setup")
    return render(request, "portal/form.html", {"form": form, "title": f"Edit {season_class.name}", "eyebrow": season_class.season.name})


@login_required
def calendar(request):
    team = _team(request.user)
    return render(request, "portal/calendar.html", {"events": team.events.select_related("show").all()[:100], "can_manage": _can_manage(request.user)})


@login_required
def event_create(request):
    _require_manage(request.user); team = _team(request.user)
    form = CalendarEventForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.team = team; obj.season = _active_season(team); obj.save()
        messages.success(request, "Calendar event added."); return redirect("calendar")
    return render(request, "portal/form.html", {"form": form, "title": "Add calendar event", "eyebrow": "SCHEDULE"})


@login_required
def announcement_create(request):
    _require_manage(request.user); team = _team(request.user)
    form = AnnouncementForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.team = team; obj.season = _active_season(team); obj.created_by = request.user; obj.save()
        messages.success(request, "Announcement posted."); return redirect("dashboard")
    return render(request, "portal/form.html", {"form": form, "title": "Post announcement", "eyebrow": "TEAM NEWS"})


@login_required
def show_list(request):
    team = _team(request.user); today = timezone.localdate(); selected = _selected_team(request)
    qs = team.shows.select_related("season")
    if selected in TEAM_LEVELS:
        qs = qs.filter(classes__season_class__team_level__in=[selected, SeasonClass.TeamLevel.BOTH]).distinct()
    upcoming = qs.filter(show_date__gte=today).order_by("show_date")
    past = qs.filter(show_date__lt=today).order_by("-show_date")[:20]
    return render(request, "portal/show_list.html", {"upcoming": upcoming, "past": past, "can_manage": _can_manage(request.user), "selected_team": selected})


@login_required
def show_detail(request, pk):
    team = _team(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    classes = show.classes.select_related("season_class").prefetch_related("entries__rider", "entries__result", "entries__rider__memberships")
    return render(request, "portal/show_detail.html", {"show": show, "classes": classes, "can_manage": _can_manage(request.user)})


@login_required
def show_create(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season before adding a show."); return redirect("show_list")
    form = ShowForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.team = team; obj.season = season; obj.save(); _sync_show_calendar(obj)
        messages.success(request, "Show added and synced to the calendar."); return redirect("show_detail", pk=obj.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add show", "eyebrow": "COMPETITION"})


@login_required
def show_edit(request, pk):
    _require_manage(request.user); team = _team(request.user)
    show = get_object_or_404(Show, pk=pk, team=team); form = ShowForm(request.POST or None, instance=show)
    if form.is_valid():
        form.save(); _sync_show_calendar(show); messages.success(request, "Show and calendar updated."); return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Edit show", "eyebrow": "COMPETITION"})


@login_required
def show_delete(request, pk):
    _require_manage(request.user); team = _team(request.user); show = get_object_or_404(Show, pk=pk, team=team)
    if request.method == "POST":
        show.delete(); messages.success(request, "Show deleted."); return redirect("show_list")
    return render(request, "portal/confirm_delete.html", {"object": show, "title": "Delete show", "message": "This also removes its show classes, entries, results, and linked calendar event."})


@login_required
def show_class_create(request, show_pk):
    _require_manage(request.user); team = _team(request.user); show = get_object_or_404(Show, pk=show_pk, team=team)
    if not show.season.season_classes.filter(active=True).exists():
        messages.error(request, "Set up season classes first, then add them to the show."); return redirect("season_setup")
    form = ShowClassForm(request.POST or None, show=show)
    if form.is_valid():
        obj = form.save(commit=False); obj.show = show; obj.save(); messages.success(request, "Season class added to this show."); return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add season class to show", "eyebrow": show.name})


@login_required
def show_class_edit(request, class_pk):
    _require_manage(request.user); team = _team(request.user)
    obj = get_object_or_404(ShowClass.objects.select_related("show"), pk=class_pk, show__team=team)
    form = ShowClassForm(request.POST or None, instance=obj, show=obj.show)
    if form.is_valid():
        form.save(); messages.success(request, "Show class updated."); return redirect("show_detail", pk=obj.show_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Edit {obj.display_name}", "eyebrow": obj.show.name})


@login_required
def show_class_delete(request, class_pk):
    _require_manage(request.user); team = _team(request.user)
    obj = get_object_or_404(ShowClass.objects.select_related("show"), pk=class_pk, show__team=team); show_id = obj.show_id
    if request.method == "POST":
        obj.delete(); messages.success(request, "Show class and its entries removed."); return redirect("show_detail", pk=show_id)
    return render(request, "portal/confirm_delete.html", {"object": obj, "title": "Remove class from show", "message": "Entries and results recorded under this show class will also be deleted."})


@login_required
def show_entry_create(request, show_pk):
    _require_manage(request.user); team = _team(request.user); show = get_object_or_404(Show, pk=show_pk, team=team)
    form = ShowEntryForm(request.POST or None, show=show, team=team)
    if form.is_valid():
        entry = form.save(commit=False)
        if entry.show_class.show_id != show.id or entry.rider.team_id != team.id: raise PermissionDenied
        entry.full_clean(); entry.save(); messages.success(request, "Rider entry added from season class assignment."); return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add rider entry", "eyebrow": show.name})


@login_required
def show_entry_edit(request, entry_pk):
    _require_manage(request.user); team = _team(request.user)
    entry = get_object_or_404(ShowEntry.objects.select_related("show_class__show", "rider"), pk=entry_pk, show_class__show__team=team); show = entry.show_class.show
    form = ShowEntryForm(request.POST or None, instance=entry, show=show, team=team)
    if form.is_valid():
        obj = form.save(commit=False); obj.full_clean(); obj.save(); messages.success(request, "Rider entry updated."); return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Edit entry · {entry.rider}", "eyebrow": show.name})


@login_required
def show_entry_delete(request, entry_pk):
    _require_manage(request.user); team = _team(request.user)
    entry = get_object_or_404(ShowEntry.objects.select_related("show_class__show", "rider"), pk=entry_pk, show_class__show__team=team); show_id = entry.show_class.show_id
    if request.method == "POST":
        entry.delete(); messages.success(request, "Rider entry removed."); return redirect("show_detail", pk=show_id)
    return render(request, "portal/confirm_delete.html", {"object": entry, "title": "Remove rider entry", "message": "Any result attached to this entry will also be deleted."})


@login_required
def show_result_edit(request, entry_pk):
    _require_manage(request.user); team = _team(request.user)
    entry = get_object_or_404(ShowEntry.objects.select_related("show_class__show", "rider"), pk=entry_pk, show_class__show__team=team)
    result, _ = ShowResult.objects.get_or_create(entry=entry); form = ShowResultForm(request.POST or None, instance=result)
    if form.is_valid():
        form.save(); messages.success(request, "Result saved."); return redirect("show_detail", pk=entry.show_class.show_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Result · {entry.rider}", "eyebrow": entry.show_class.display_name})
