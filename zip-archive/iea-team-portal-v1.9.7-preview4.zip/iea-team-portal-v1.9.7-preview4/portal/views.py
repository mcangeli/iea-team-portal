import re
import csv
from pathlib import Path
from datetime import datetime, time, timedelta
from decimal import Decimal
from functools import wraps
from urllib.parse import urlencode

from django.contrib import messages
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import IntegrityError, transaction
from django.db.models import Q, Sum
from django.core.paginator import Paginator
from django.http import HttpResponse, FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from .forms import (
    AnnouncementForm, CalendarEventForm, GuardianContactForm, RiderForm,
    SeasonClassForm, SeasonMembershipForm, ShowClassForm, ShowEntryForm,
    ShowForm, ShowResultForm, SeasonScoringConfigForm, QualificationOverrideForm,
    LessonGroupForm, LessonForm, LessonAttendanceForm, ShowAvailabilityForm,
    VolunteerLogForm, VolunteerReviewForm, VolunteerRequirementForm,
    UserOnboardingForm, UserAccountEditForm, TemporaryPasswordResetForm, NotificationPreferenceForm,
    CommitteeAssignmentForm, ShowLeadAssignmentForm, ShowPlanningItemForm, ShowDayUpdateForm,
    RiderDevelopmentNoteForm, RiderAwardForm, EventRSVPForm, ActionItemForm,
    HistoricalResultHeaderForm, HistoricalResultFormSet,
    FinancialAccountForm, FinancialCategoryForm, FinancialTransactionForm, SeasonBudgetForm,
    HomeBarnForm, MembershipDuesRateForm, FamilyChargeForm, FamilyCreditForm,
    ServiceAgreementCreditForm, FinancialAssistanceAwardForm, AssistanceClaimForm, FamilyPaymentForm,
    ShowBudgetLineForm, ReimbursementRequestForm, ReimbursementReviewForm, ShowFundingPolicyForm,
    ShowTransactionAllocationForm, FundraisingCampaignForm, FundraisingContributionForm,
    FundraisingPolicyForm,
)
from .models import (
    Announcement, CalendarEvent, GuardianContact, Rider, RiderGuardian, Season,
    SeasonClass, SeasonMembership, SeasonScoringConfig, QualificationOverride, Show, ShowClass, ShowEntry, ShowResult, UserProfile,
    LessonGroup, Lesson, LessonAttendance, ShowAvailability, ShowDayRiderStatus, VolunteerLog, Notification,
    CommitteeAssignment, ShowLeadAssignment, ShowPlanningItem, ShowDayUpdate, RiderDevelopmentNote, RiderAward,
    EventRSVP, ActionItem, FinancialAccount, FinancialCategory, FinancialTransaction, SeasonBudget,
    HomeBarn, MembershipDuesRate, FamilyCharge, FamilyCredit, ServiceAgreementCredit,
    FinancialAssistanceAward, AssistanceClaim, FamilyPayment, ShowBudgetLine, ReimbursementRequest,
    ShowTransactionAllocation, AuditEvent, FundraisingCampaign, FundraisingContribution,
    FundraisingPolicy,
)

TEAM_LEVELS = {SeasonMembership.TeamLevel.FUTURES, SeasonMembership.TeamLevel.UPPER}


def _audit_value(value):
    if value is None:
        return None
    if isinstance(value, Decimal):
        return str(value)
    if hasattr(value, "isoformat"):
        try:
            return value.isoformat()
        except Exception:
            pass
    return str(value)


def _audit_event(*, team, actor, action, obj=None, season=None, summary="", details=None,
                 entity_type=None, entity_id=None, entity_label=None):
    """Append a lightweight, immutable operational audit event."""
    if obj is not None:
        entity_type = entity_type or obj.__class__.__name__
        entity_id = entity_id if entity_id is not None else getattr(obj, "pk", None)
        entity_label = entity_label or str(obj)
        if season is None:
            season = getattr(obj, "season", None)
            if season is None and hasattr(obj, "membership"):
                season = getattr(obj.membership, "season", None)
            if season is None and hasattr(obj, "show"):
                season = getattr(obj.show, "season", None)
            if season is None and hasattr(obj, "transaction"):
                season = getattr(obj.transaction, "season", None)
    safe_details = {str(k): _audit_value(v) for k, v in (details or {}).items()}
    return AuditEvent.objects.create(
        team=team,
        season=season,
        actor=actor if getattr(actor, "is_authenticated", False) else None,
        action=action,
        entity_type=entity_type or "Unknown",
        entity_id=entity_id,
        entity_label=(entity_label or entity_type or "Record")[:255],
        summary=(summary or f"{action} {entity_label or entity_type or 'record'}")[:255],
        details=safe_details,
    )


def _finance_season_ids(user, team):
    if _is_rider_account(user):
        return []
    if user.is_superuser or (hasattr(user, "profile") and user.profile.role == UserProfile.Role.ADMIN):
        return list(Season.objects.filter(team=team).values_list("id", flat=True))
    return list(
        CommitteeAssignment.objects.filter(
            user=user, active=True, role=CommitteeAssignment.Role.TREASURER, season__team=team
        ).values_list("season_id", flat=True)
    )


def friendly_integrity_errors(view_func):
    """Turn database constraint collisions in create workflows into a useful UI message."""
    @wraps(view_func)
    def wrapped(request, *args, **kwargs):
        try:
            with transaction.atomic():
                return view_func(request, *args, **kwargs)
        except IntegrityError:
            if request.method == "POST":
                messages.error(
                    request,
                    "That record could not be added because it conflicts with an existing record. "
                    "Review the existing entries and edit or link the existing record instead."
                )
                return redirect(request.path)
            raise
    return wrapped


def _team(user):
    if user.is_superuser:
        return user.profile.team if hasattr(user, "profile") else None
    if not hasattr(user, "profile") or not user.profile.team:
        raise PermissionDenied("Your account is not assigned to a team.")
    return user.profile.team


def _can_manage(user):
    return user.is_superuser or (
        hasattr(user, "profile") and user.profile.role in [UserProfile.Role.ADMIN, UserProfile.Role.COACH]
    )


def _active_committee_roles(user, season=None):
    qs = CommitteeAssignment.objects.filter(user=user, active=True)
    if season:
        qs = qs.filter(season=season)
    return set(qs.values_list("role", flat=True))


def _can_manage_points(user, season=None):
    return _can_manage(user) or CommitteeAssignment.Role.POINTS_SECRETARY in _active_committee_roles(user, season)


def _is_rider_account(user):
    return bool(
        getattr(user, "is_authenticated", False)
        and hasattr(user, "profile")
        and user.profile.role == UserProfile.Role.RIDER
    )


def _can_finance(user, season=None):
    # Youth Rider accounts never receive Finance access, even if a committee
    # assignment is accidentally attached to the login.
    if _is_rider_account(user):
        return False
    if user.is_superuser:
        return True
    if hasattr(user, "profile") and user.profile.role == UserProfile.Role.ADMIN:
        return True
    return CommitteeAssignment.Role.TREASURER in _active_committee_roles(user, season)


def _require_finance(user, season=None):
    if not _can_finance(user, season):
        raise PermissionDenied


def _can_coordinate_team(user, team_level, season=None):
    if _can_manage(user):
        return True
    roles = _active_committee_roles(user, season)
    return (
        team_level == SeasonMembership.TeamLevel.FUTURES and CommitteeAssignment.Role.FUTURES_PARENT in roles
    ) or (
        team_level == SeasonMembership.TeamLevel.UPPER and CommitteeAssignment.Role.UPPER_PARENT in roles
    )


def _is_show_lead(user, show):
    return ShowLeadAssignment.objects.filter(show=show, user=user, active=True).exists()


def _show_planning_allowed_levels(user, show):
    if _is_rider_account(user):
        return set()
    if _can_manage(user) or _is_show_lead(user, show):
        return {
            ShowPlanningItem.TeamLevel.ALL,
            ShowPlanningItem.TeamLevel.FUTURES,
            ShowPlanningItem.TeamLevel.UPPER,
        }
    roles = _active_committee_roles(user, show.season)
    allowed = set()
    if CommitteeAssignment.Role.FUTURES_PARENT in roles:
        allowed.add(ShowPlanningItem.TeamLevel.FUTURES)
    if CommitteeAssignment.Role.UPPER_PARENT in roles:
        allowed.add(ShowPlanningItem.TeamLevel.UPPER)
    return allowed


def _can_plan_show(user, show):
    return bool(_show_planning_allowed_levels(user, show))


def _can_manage_planning_item(user, item):
    return item.team_level in _show_planning_allowed_levels(user, item.show)


def _planning_item_visible_to_user(user, item):
    if _can_manage(user) or _is_show_lead(user, item.show):
        return True
    if not item.family_visible:
        return False
    if item.team_level == ShowPlanningItem.TeamLevel.ALL:
        return True
    roles = _active_committee_roles(user, item.show.season)
    if (
        item.team_level == ShowPlanningItem.TeamLevel.FUTURES
        and CommitteeAssignment.Role.FUTURES_PARENT in roles
    ):
        return True
    if (
        item.team_level == ShowPlanningItem.TeamLevel.UPPER
        and CommitteeAssignment.Role.UPPER_PARENT in roles
    ):
        return True
    visible_rider_ids = _visible_riders(user, item.show.team).values_list("id", flat=True)
    return SeasonMembership.objects.filter(
        season=item.show.season,
        rider_id__in=visible_rider_ids,
        team_level=item.team_level,
    ).exists()


def _show_update_allowed_audiences(user, show):
    """Audiences this user may publish/edit for this show."""
    if _is_rider_account(user):
        return set()
    if _can_manage(user) or _is_show_lead(user, show):
        return {
            ShowDayUpdate.Audience.ALL,
            ShowDayUpdate.Audience.FUTURES,
            ShowDayUpdate.Audience.UPPER,
        }
    roles = _active_committee_roles(user, show.season)
    allowed = set()
    if CommitteeAssignment.Role.FUTURES_PARENT in roles:
        allowed.add(ShowDayUpdate.Audience.FUTURES)
    if CommitteeAssignment.Role.UPPER_PARENT in roles:
        allowed.add(ShowDayUpdate.Audience.UPPER)
    return allowed


def _can_publish_show_update(user, show, audience=None):
    allowed = _show_update_allowed_audiences(user, show)
    return bool(allowed) and (audience is None or audience in allowed)


def _show_schedule_edit_levels(user, show):
    """Team levels whose class schedule this user may edit for a show."""
    if _is_rider_account(user):
        return set()
    if (
        _can_manage(user)
        or _is_show_lead(user, show)
        or CommitteeAssignment.Role.POINTS_SECRETARY in _active_committee_roles(user, show.season)
    ):
        return {
            SeasonMembership.TeamLevel.FUTURES,
            SeasonMembership.TeamLevel.UPPER,
            SeasonClass.TeamLevel.BOTH,
        }

    roles = _active_committee_roles(user, show.season)
    levels = set()
    if CommitteeAssignment.Role.FUTURES_PARENT in roles:
        levels.update({SeasonMembership.TeamLevel.FUTURES, SeasonClass.TeamLevel.BOTH})
    if CommitteeAssignment.Role.UPPER_PARENT in roles:
        levels.update({SeasonMembership.TeamLevel.UPPER, SeasonClass.TeamLevel.BOTH})
    return levels


def _can_edit_show_schedule_class(user, show_class):
    return show_class.team_level in _show_schedule_edit_levels(user, show_class.show)


def _parse_schedule_time(value):
    value = (value or "").strip()
    if not value:
        return None
    for fmt in ("%H:%M", "%I:%M %p", "%I:%M%p"):
        try:
            return datetime.strptime(value.upper(), fmt).time()
        except ValueError:
            continue
    raise ValidationError("Enter times like 9:30 AM or 14:30.")


def _shift_schedule_time(value, minutes):
    if value is None:
        return None
    anchor = datetime.combine(timezone.localdate(), value)
    return (anchor + timedelta(minutes=minutes)).time().replace(second=0, microsecond=0)


def _rider_team_level_for_show(rider, show):
    membership = SeasonMembership.objects.filter(rider=rider, season=show.season).first()
    return membership.team_level if membership else None


def _can_update_show_day_rider_status(user, show, rider):
    if _is_rider_account(user):
        return rider.user_id == user.id
    if _can_manage(user) or _is_show_lead(user, show):
        return True

    team_level = _rider_team_level_for_show(rider, show)
    roles = _active_committee_roles(user, show.season)

    if (
        team_level == SeasonMembership.TeamLevel.FUTURES
        and CommitteeAssignment.Role.FUTURES_PARENT in roles
    ):
        return True
    if (
        team_level == SeasonMembership.TeamLevel.UPPER
        and CommitteeAssignment.Role.UPPER_PARENT in roles
    ):
        return True

    # Ordinary parents/guardians can update only their own rider.
    return (
        rider.guardians.filter(pk=user.pk).exists()
        or rider.guardian_links.filter(guardian__user=user).exists()
    )


def _show_day_operational_user(user, show):
    if _is_rider_account(user):
        return False
    roles = _active_committee_roles(user, show.season)
    return bool(
        _can_manage(user)
        or _is_show_lead(user, show)
        or CommitteeAssignment.Role.FUTURES_PARENT in roles
        or CommitteeAssignment.Role.UPPER_PARENT in roles
        or CommitteeAssignment.Role.POINTS_SECRETARY in roles
    )


def _show_day_participating_riders(show):
    return (
        Rider.objects.filter(
            show_entries__show_class__show=show,
            show_entries__status__in=[ShowEntry.Status.PLANNED, ShowEntry.Status.ENTERED],
        )
        .distinct()
        .order_by("last_name", "first_name")
    )


def _visible_show_day_updates(user, show):
    updates = show.day_updates.filter(published=True).select_related("created_by", "updated_by")
    if _can_manage(user) or _is_show_lead(user, show):
        return updates
    visible_ids = []
    for update in updates:
        if _show_update_recipients(update).filter(pk=user.pk).exists():
            visible_ids.append(update.pk)
    return updates.filter(pk__in=visible_ids)


def _show_update_family_user_ids(show, audience):
    entries = ShowEntry.objects.filter(show_class__show=show).exclude(status=ShowEntry.Status.SCRATCHED)
    if audience in {ShowDayUpdate.Audience.FUTURES, ShowDayUpdate.Audience.UPPER}:
        entries = entries.filter(
            rider__memberships__season=show.season,
            rider__memberships__team_level=audience,
        )
    rider_ids = entries.values_list("rider_id", flat=True).distinct()
    rider_user_ids = Rider.objects.filter(pk__in=rider_ids, user__isnull=False).values_list("user_id", flat=True)
    guardian_contact_ids = GuardianContact.objects.filter(
        rider_links__rider_id__in=rider_ids, user__isnull=False
    ).values_list("user_id", flat=True)
    legacy_guardian_ids = User.objects.filter(guardian_riders__id__in=rider_ids).values_list("id", flat=True)
    return set(rider_user_ids) | set(guardian_contact_ids) | set(legacy_guardian_ids)


def _show_update_recipients(update):
    show = update.show
    ids = _show_update_family_user_ids(show, update.audience)

    # Coaches/Admins and assigned Show Leads always receive show-day updates.
    ids.update(User.objects.filter(
        profile__team=show.team,
        profile__role__in=[UserProfile.Role.ADMIN, UserProfile.Role.COACH],
        is_active=True,
    ).values_list("id", flat=True))
    ids.update(ShowLeadAssignment.objects.filter(
        show=show, active=True, user__is_active=True
    ).values_list("user_id", flat=True))

    # The Secretary needs show-day context for results entry.
    ids.update(CommitteeAssignment.objects.filter(
        season=show.season, active=True,
        role=CommitteeAssignment.Role.POINTS_SECRETARY,
        user__is_active=True,
    ).values_list("user_id", flat=True))

    # Team Parent updates stay aligned to the parent's team designation.
    parent_roles = []
    if update.audience == ShowDayUpdate.Audience.FUTURES:
        parent_roles = [CommitteeAssignment.Role.FUTURES_PARENT]
    elif update.audience == ShowDayUpdate.Audience.UPPER:
        parent_roles = [CommitteeAssignment.Role.UPPER_PARENT]
    else:
        parent_roles = [CommitteeAssignment.Role.FUTURES_PARENT, CommitteeAssignment.Role.UPPER_PARENT]
    ids.update(CommitteeAssignment.objects.filter(
        season=show.season, active=True, role__in=parent_roles, user__is_active=True
    ).values_list("user_id", flat=True))

    return User.objects.filter(pk__in=ids, is_active=True).select_related("profile").distinct()


def _deliver_show_update(update, *, revised=False):
    recipients = list(_show_update_recipients(update))
    title = f"Updated: {update.title}" if revised else update.title
    link = f"/shows/{update.show_id}/updates/"
    Notification.objects.bulk_create([
        Notification(
            user=user,
            show_day_update=update,
            title=title,
            body=update.body,
            link=link,
        )
        for user in recipients
    ])
    if update.send_email and settings.EMAIL_HOST:
        subject_prefix = update.show.team.short_name or update.show.team.name
        for user in recipients:
            profile = getattr(user, "profile", None)
            if not user.email or (profile and not profile.email_show_updates):
                continue
            send_mail(
                subject=f"{subject_prefix}: {title}",
                message=f"{update.show.name}\n\n{update.body}",
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[user.email],
                fail_silently=True,
            )
    return len(recipients)


def _ensure_season_open(season):
    if season and season.is_closed:
        raise PermissionDenied("This season is archived. An Administrator must reopen it before operational records can be changed.")



def _is_admin(user):
    return user.is_superuser or (hasattr(user, "profile") and user.profile.role == UserProfile.Role.ADMIN)


def _can_manage_user(actor, target):
    if _is_admin(actor):
        return True
    return _can_manage(actor) and hasattr(target, "profile") and target.profile.role in {UserProfile.Role.PARENT, UserProfile.Role.RIDER}


def _require_manage(user):
    if not _can_manage(user):
        raise PermissionDenied


def _visible_riders(user, team):
    """Riders whose private/operational data the user may access."""
    qs = team.riders.all()
    if hasattr(user, "profile") and user.profile.role == UserProfile.Role.PARENT:
        qs = qs.filter(Q(guardians=user) | Q(guardian_links__guardian__user=user)).distinct()
    elif hasattr(user, "profile") and user.profile.role == UserProfile.Role.RIDER:
        qs = qs.filter(user=user)
    return qs


def _can_view_private_rider(user, rider):
    if _can_manage(user):
        return True
    if rider.user_id == user.id:
        return True
    return rider.guardians.filter(pk=user.pk).exists() or rider.guardian_links.filter(guardian__user=user).exists()


def _team_roster(user, team):
    """Team-visible roster. Personal fields are filtered by the detail template/view."""
    return team.riders.filter(active=True)


def _visible_action_items(user, team):
    qs = ActionItem.objects.filter(team=team).select_related(
        "season", "event", "show", "rider", "assigned_to", "claimed_by"
    )
    if _can_manage(user):
        return qs
    riders = _visible_riders(user, team)
    return qs.filter(family_visible=True).filter(
        Q(rider__in=riders) |
        Q(assigned_to=user) |
        Q(claimed_by=user) |
        Q(rider__isnull=True, assigned_to__isnull=True)
    ).distinct()


def _announcement_recipients(announcement):
    users = User.objects.filter(profile__team=announcement.team, is_active=True).select_related("profile")
    audience = announcement.audience
    if audience == Announcement.Audience.COACHES:
        users = users.filter(profile__role__in=[UserProfile.Role.ADMIN, UserProfile.Role.COACH])
    elif audience == Announcement.Audience.PARENTS:
        users = users.filter(Q(profile__role=UserProfile.Role.PARENT) | Q(guardian_contact__isnull=False)).distinct()
    elif audience == Announcement.Audience.RIDERS:
        users = users.filter(profile__role=UserProfile.Role.RIDER)
    elif audience in {Announcement.Audience.FUTURES, Announcement.Audience.UPPER}:
        season = announcement.season or _active_season(announcement.team)
        if not season:
            return users.none()
        rider_users = Rider.objects.filter(
            team=announcement.team, memberships__season=season, memberships__team_level=audience, user__isnull=False
        ).values_list("user_id", flat=True)
        guardian_users = GuardianContact.objects.filter(
            team=announcement.team, rider_links__rider__memberships__season=season,
            rider_links__rider__memberships__team_level=audience, user__isnull=False
        ).values_list("user_id", flat=True)
        users = users.filter(Q(id__in=rider_users) | Q(id__in=guardian_users) | Q(profile__role__in=[UserProfile.Role.ADMIN, UserProfile.Role.COACH]))
    elif audience == Announcement.Audience.SELECTED:
        users = users.filter(id__in=announcement.selected_users.values("id"))
    return users.distinct()


def _visible_announcements(user, team):
    now = timezone.now()
    qs = team.announcements.filter(published=True).filter(Q(expires_at__isnull=True) | Q(expires_at__gt=now))
    if _can_manage(user):
        return qs
    allowed = []
    for announcement in qs.prefetch_related("selected_users"):
        if _announcement_recipients(announcement).filter(pk=user.pk).exists():
            allowed.append(announcement.pk)
    return qs.filter(pk__in=allowed)


def _deliver_announcement(announcement):
    recipients = list(_announcement_recipients(announcement))
    Notification.objects.filter(announcement=announcement).delete()
    Notification.objects.bulk_create([
        Notification(user=user, announcement=announcement, title=announcement.title, body=announcement.body, link="/")
        for user in recipients
    ])
    if announcement.send_email and settings.EMAIL_HOST:
        for user in recipients:
            profile = getattr(user, "profile", None)
            if not user.email or (profile and not profile.email_announcements):
                continue
            send_mail(
                subject=f"{announcement.team.short_name or announcement.team.name}: {announcement.title}",
                message=announcement.body,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[user.email],
                fail_silently=True,
            )
    return len(recipients)


def _active_season(team):
    return team.seasons.filter(is_active=True).first()


def _selected_team(request):
    value = request.GET.get("team", "all").lower()
    return value if value in TEAM_LEVELS | {"all", "unassigned"} else "all"


def _sync_show_calendar(show):
    tz = timezone.get_current_timezone()
    clock = show.start_time or time(0, 0)
    starts_at = timezone.make_aware(datetime.combine(show.show_date, clock), tz)
    location = " · ".join(part for part in [show.venue, show.address] if part)
    CalendarEvent.objects.update_or_create(
        show=show,
        defaults={
            "team": show.team,
            "season": show.season,
            "title": show.name,
            "kind": CalendarEvent.Kind.SHOW,
            "starts_at": starts_at,
            "ends_at": None,
            "all_day": not bool(show.start_time),
            "location": location,
            "description": show.notes,
            "visible_to_all": True,
        },
    )


@login_required
def dashboard(request):
    team = _team(request.user)
    if not team:
        return render(request, "portal/no_team.html")
    season = _active_season(team)
    now = timezone.now()
    today = timezone.localdate()
    announcements = _visible_announcements(request.user, team)[:5]
    events = team.events.filter(starts_at__gte=now)[:6]
    riders = _visible_riders(request.user, team).filter(active=True)
    shows = team.shows.filter(show_date__gte=today).order_by("show_date")[:4]
    memberships = season.memberships.select_related("rider") if season else SeasonMembership.objects.none()
    upcoming_lessons = Lesson.objects.none()
    volunteer_due = 0
    pending_volunteer = 0
    pending_availability = 0
    if season:
        upcoming_lessons = season.lessons.filter(starts_at__gte=now, cancelled=False).order_by("starts_at")
        if not _can_manage(request.user):
            upcoming_lessons = upcoming_lessons.filter(attendance__rider__in=riders).distinct()
        progress = _volunteer_progress_rows(season, riders)
        volunteer_due = sum(1 for row in progress if not row["complete"])
        pending_volunteer = VolunteerLog.objects.filter(season=season, rider__in=riders, status=VolunteerLog.Status.PENDING).count()
        upcoming_shows_qs = season.shows.filter(show_date__gte=today)
        for show in upcoming_shows_qs:
            for rider in riders:
                ShowAvailability.objects.get_or_create(show=show, rider=rider)
        pending_availability = ShowAvailability.objects.filter(show__in=upcoming_shows_qs, rider__in=riders, status=ShowAvailability.Status.PENDING).count()
    action_items = _visible_action_items(request.user, team).filter(completed=False)
    my_action_items = action_items.filter(
        Q(assigned_to=request.user) | Q(claimed_by=request.user) | Q(rider__in=riders)
    ).distinct().order_by("due_at", "-created_at")[:6]
    pending_event_rsvps = 0
    unclaimed_actions = 0
    overdue_actions = 0
    rsvp_events = list(team.events.filter(
        starts_at__gte=now, rsvp_requested=True, visible_to_all=True
    ))
    rider_list = list(riders)
    responded_pairs = set(
        EventRSVP.objects.filter(
            event__in=rsvp_events, rider__in=rider_list
        ).exclude(status=EventRSVP.Status.PENDING).values_list("event_id", "rider_id")
    )
    pending_event_rsvps = sum(
        1 for event in rsvp_events for rider in rider_list
        if (event.pk, rider.pk) not in responded_pairs
    )
    if _can_manage(request.user):
        unclaimed_actions = action_items.filter(
            claimable=True, claimed_by__isnull=True, assigned_to__isnull=True
        ).count()
        overdue_actions = action_items.filter(
            due_at__lt=now, completed=False
        ).count()

    next_show = shows.first() if shows else None
    qualifier_count = 0
    if season:
        qualifier_count = sum(
            1 for row in _qualification_rows(season)
            if row["qualified"] and row["rider"] in riders
        )
    attention_count = (
        pending_availability + pending_event_rsvps + len(my_action_items)
    )

    return render(request, "portal/dashboard.html", {
        "season": season, "announcements": announcements, "events": events, "riders": riders,
        "shows": shows, "can_manage": _can_manage(request.user),
        "futures_count": memberships.filter(team_level=SeasonMembership.TeamLevel.FUTURES).count(),
        "upper_count": memberships.filter(team_level=SeasonMembership.TeamLevel.UPPER).count(),
        "upcoming_lessons": upcoming_lessons[:4], "lesson_count": upcoming_lessons.count(),
        "volunteer_due": volunteer_due, "pending_volunteer": pending_volunteer,
        "pending_availability": pending_availability,
        "my_action_items": my_action_items,
        "pending_event_rsvps": pending_event_rsvps,
        "unclaimed_actions": unclaimed_actions,
        "overdue_actions": overdue_actions,
        "next_show": next_show,
        "roster_count": memberships.count() if season else riders.count(),
        "qualifier_count": qualifier_count,
        "attention_count": attention_count,
    })


@login_required
def my_team(request):
    team = _team(request.user)
    season = _active_season(team)
    riders = list(
        _visible_riders(request.user, team).filter(active=True).prefetch_related(
            "memberships__season", "guardian_links__guardian"
        ).order_by("last_name", "first_name")
    )
    now = timezone.now()
    upcoming_events = list(
        team.events.filter(starts_at__gte=now, visible_to_all=True)
        .prefetch_related("rsvps")
        .order_by("starts_at")[:12]
    )
    rider_ids = [r.pk for r in riders]
    rsvp_map = {
        (rsvp.event_id, rsvp.rider_id): rsvp
        for rsvp in EventRSVP.objects.filter(
            event__in=upcoming_events, rider_id__in=rider_ids
        ).select_related("rider")
    }
    event_rows = []
    for event in upcoming_events:
        responses = []
        if event.rsvp_requested:
            for rider in riders:
                responses.append({
                    "rider": rider,
                    "rsvp": rsvp_map.get((event.pk, rider.pk)),
                })
        event_rows.append({"event": event, "responses": responses})

    action_items = list(
        _visible_action_items(request.user, team)
        .filter(completed=False)
        .order_by("due_at", "-created_at")[:20]
    )
    memberships = {}
    if season:
        memberships = {
            m.rider_id: m
            for m in SeasonMembership.objects.filter(
                season=season, rider_id__in=rider_ids
            ).select_related("home_barn").prefetch_related("classes")
        }
    rider_rows = []
    for rider in riders:
        membership = memberships.get(rider.pk)
        rider_rows.append({
            "rider": rider,
            "membership": membership,
            "can_view_family_account": bool(membership and _can_view_family_account(request.user, membership)),
        })

    return render(request, "portal/my_team.html", {
        "team": team,
        "season": season,
        "rider_rows": rider_rows,
        "event_rows": event_rows,
        "action_items": action_items,
        "can_manage": _can_manage(request.user),
    })


@login_required
def event_rsvp(request, pk, rider_pk):
    team = _team(request.user)
    event = get_object_or_404(CalendarEvent, pk=pk, team=team, rsvp_requested=True)
    rider = get_object_or_404(_visible_riders(request.user, team), pk=rider_pk)
    rsvp, _ = EventRSVP.objects.get_or_create(event=event, rider=rider)
    form = EventRSVPForm(request.POST or None, instance=rsvp)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.responded_by = request.user
        obj.save()
        messages.success(request, f"RSVP updated for {rider.display_name}.")
        return redirect("my_team")
    return render(request, "portal/form.html", {
        "form": form,
        "title": f"RSVP · {event.title}",
        "eyebrow": rider.display_name,
    })


@login_required
def action_item_list(request):
    team = _team(request.user)
    items = _visible_action_items(request.user, team)
    show_completed = request.GET.get("completed") == "1"
    if not show_completed:
        items = items.filter(completed=False)
    return render(request, "portal/action_item_list.html", {
        "items": items[:100],
        "can_manage": _can_manage(request.user),
        "show_completed": show_completed,
    })


@login_required
def action_item_create(request):
    _require_manage(request.user)
    team = _team(request.user)
    season = _active_season(team)
    form = ActionItemForm(request.POST or None, team=team, season=season)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.season = season
        obj.created_by = request.user
        obj.save()
        messages.success(request, "Action item created.")
        return redirect("action_item_list")
    return render(request, "portal/form.html", {
        "form": form, "title": "Add action item", "eyebrow": "TEAM HUB"
    })


@login_required
def action_item_edit(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    item = get_object_or_404(ActionItem, pk=pk, team=team)
    form = ActionItemForm(request.POST or None, instance=item, team=team, season=item.season)
    if form.is_valid():
        form.save()
        messages.success(request, "Action item updated.")
        return redirect("action_item_list")
    return render(request, "portal/form.html", {
        "form": form, "title": f"Edit · {item.title}", "eyebrow": "TEAM HUB"
    })


@login_required
@require_POST
def action_item_claim(request, pk):
    team = _team(request.user)
    item = get_object_or_404(_visible_action_items(request.user, team), pk=pk, completed=False)
    if not item.claimable:
        raise PermissionDenied
    if item.claimed_by_id and item.claimed_by_id != request.user.id and not _can_manage(request.user):
        messages.error(request, "This item has already been claimed.")
    else:
        item.claimed_by = None if item.claimed_by_id == request.user.id else request.user
        item.save(update_fields=["claimed_by"])
        messages.success(request, "Action item updated.")
    return redirect("action_item_list")


@login_required
@require_POST
def action_item_complete(request, pk):
    team = _team(request.user)
    item = get_object_or_404(_visible_action_items(request.user, team), pk=pk)
    allowed = _can_manage(request.user) or item.assigned_to_id == request.user.id or item.claimed_by_id == request.user.id
    if not allowed:
        raise PermissionDenied
    item.completed = not item.completed
    item.save()
    messages.success(request, "Action item updated.")
    return redirect("action_item_list")


@login_required
def rider_list(request):
    team = _team(request.user)
    qs = _team_roster(request.user, team).prefetch_related("memberships")
    season = _active_season(team)
    selected = _selected_team(request)
    if season:
        futures = qs.filter(memberships__season=season, memberships__team_level=SeasonMembership.TeamLevel.FUTURES).distinct()
        upper = qs.filter(memberships__season=season, memberships__team_level=SeasonMembership.TeamLevel.UPPER).distinct()
        unassigned = qs.exclude(memberships__season=season).distinct()
    else:
        futures = Rider.objects.none(); upper = Rider.objects.none(); unassigned = qs
    return render(request, "portal/rider_list.html", {
        "riders": qs, "futures": futures, "upper": upper, "unassigned": unassigned,
        "season": season, "can_manage": _can_manage(request.user), "selected_team": selected,
    })


@login_required
def rider_export(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team); selected = _selected_team(request)
    qs = team.riders.filter(active=True).order_by("last_name", "first_name")
    if season and selected in TEAM_LEVELS:
        qs = qs.filter(memberships__season=season, memberships__team_level=selected).distinct()
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="rider-roster.csv"'
    writer = csv.writer(response)
    writer.writerow(["Rider", "Email", "Grade", "School", "Team", "Season classes", "IEA member number"])
    for rider in qs:
        membership = rider.memberships.filter(season=season).prefetch_related("classes").first() if season else None
        writer.writerow([
            str(rider), rider.email, rider.grade or "", rider.school,
            membership.get_team_level_display() if membership else "Unassigned",
            "; ".join(c.name for c in membership.classes.all()) if membership else "",
            rider.iea_member_number,
        ])
    return response


@login_required
def rider_detail(request, pk):
    team = _team(request.user)
    rider = get_object_or_404(Rider.objects.prefetch_related("memberships__classes", "guardian_links__guardian"), pk=pk, team=team)
    private_view = _can_view_private_rider(request.user, rider)
    active_season = _active_season(team)
    entries = rider.show_entries.filter(result__isnull=False)
    if active_season:
        entries = entries.filter(show_class__show__season=active_season)
    season_points = entries.aggregate(total=Sum("result__points"))["total"] or 0
    lesson_history = LessonAttendance.objects.none()
    volunteer_progress = None
    if active_season and private_view:
        lesson_history = rider.lesson_attendance.filter(lesson__season=active_season).select_related("lesson").order_by("-lesson__starts_at")[:10]
        progress_rows = _volunteer_progress_rows(active_season, Rider.objects.filter(pk=rider.pk))
        volunteer_progress = progress_rows[0] if progress_rows else None
    return render(request, "portal/rider_detail.html", {
        "rider": rider, "season_points": season_points, "can_manage": _can_manage(request.user),
        "active_season": active_season, "lesson_history": lesson_history, "volunteer_progress": volunteer_progress,
        "private_view": private_view,
    })


@login_required
def rider_create(request):
    _require_manage(request.user); team = _team(request.user)
    form = RiderForm(
        request.POST or None,
        request.FILES or None,
        team=team,
        include_season=True,
    )
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.save()

        season = form.cleaned_data.get("season")
        if season:
            membership = SeasonMembership.objects.create(
                rider=obj,
                season=season,
                team_level=form.cleaned_data["team_level"],
                home_barn=form.cleaned_data.get("home_barn"),
                notes=form.cleaned_data.get("season_notes", ""),
            )
            membership.classes.set(form.cleaned_data.get("classes"))

            messages.success(
                request,
                f"Rider added and enrolled in {season.name}. The rider record will remain available for future seasons."
            )
        else:
            messages.success(
                request,
                "Rider added. No season enrollment was created; you can assign this rider to a season at any time."
            )
        return redirect("rider_detail", pk=obj.pk)
    return render(request, "portal/rider_form.html", {
        "form": form,
        "title": "Add rider",
        "eyebrow": "ROSTER",
        "creating": True,
    })


@login_required
def rider_edit(request, pk):
    _require_manage(request.user); team = _team(request.user)
    obj = get_object_or_404(Rider, pk=pk, team=team)
    form = RiderForm(request.POST or None, request.FILES or None, instance=obj, team=team)
    if form.is_valid():
        form.save(); messages.success(request, "Rider updated."); return redirect("rider_detail", pk=obj.pk)
    return render(request, "portal/rider_form.html", {
        "form": form,
        "title": "Edit rider",
        "eyebrow": "ROSTER",
        "creating": False,
    })


@login_required
def rider_membership_edit(request, pk, season_pk=None):
    _require_manage(request.user); team = _team(request.user)
    rider = get_object_or_404(Rider, pk=pk, team=team)
    season = get_object_or_404(Season, pk=season_pk, team=team) if season_pk else _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("rider_detail", pk=rider.pk)
    _ensure_season_open(season)
    membership, _ = SeasonMembership.objects.get_or_create(rider=rider, season=season)
    form = SeasonMembershipForm(request.POST or None, instance=membership, season=season)
    if form.is_valid():
        form.save(); messages.success(request, f"{season.name} team and class assignments updated.")
        return redirect("rider_detail", pk=rider.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"{rider.display_name} · {season.name}", "eyebrow": "SEASON ASSIGNMENT"})


@login_required
def rider_guardian_add(request, pk):
    _require_manage(request.user); team = _team(request.user)
    rider = get_object_or_404(Rider, pk=pk, team=team)
    form = GuardianContactForm(request.POST or None)
    if form.is_valid():
        relationship = form.cleaned_data.get("relationship", "")
        primary = form.cleaned_data.get("primary_contact", False)
        guardian = form.save(commit=False); guardian.team = team; guardian.save()
        RiderGuardian.objects.create(rider=rider, guardian=guardian, relationship=relationship, primary_contact=primary)
        messages.success(request, "Parent/guardian contact added."); return redirect("rider_detail", pk=rider.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Add parent/guardian · {rider.display_name}", "eyebrow": "FAMILY CONTACT"})


@login_required
def rider_guardian_edit(request, pk, guardian_pk):
    _require_manage(request.user); team = _team(request.user)
    rider = get_object_or_404(Rider, pk=pk, team=team)
    link = get_object_or_404(RiderGuardian.objects.select_related("guardian"), rider=rider, guardian_id=guardian_pk, guardian__team=team)
    form = GuardianContactForm(request.POST or None, instance=link.guardian, initial={"relationship": link.relationship, "primary_contact": link.primary_contact})
    if form.is_valid():
        form.save(); link.relationship = form.cleaned_data.get("relationship", ""); link.primary_contact = form.cleaned_data.get("primary_contact", False); link.save()
        messages.success(request, "Parent/guardian contact updated."); return redirect("rider_detail", pk=rider.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Edit {link.guardian.display_name}", "eyebrow": "FAMILY CONTACT"})


@login_required
def parent_list(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team); selected = _selected_team(request)
    guardians = team.guardian_contacts.prefetch_related("rider_links__rider").all()
    if season and selected in TEAM_LEVELS:
        guardians = guardians.filter(rider_links__rider__memberships__season=season, rider_links__rider__memberships__team_level=selected).distinct()
    return render(request, "portal/parent_list.html", {"guardians": guardians, "selected_team": selected, "season": season})


@login_required
def parent_export(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team); selected = _selected_team(request)
    guardians = team.guardian_contacts.prefetch_related("rider_links__rider").all()
    if season and selected in TEAM_LEVELS:
        guardians = guardians.filter(rider_links__rider__memberships__season=season, rider_links__rider__memberships__team_level=selected).distinct()
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="parent-guardian-directory.csv"'
    writer = csv.writer(response); writer.writerow(["Parent/Guardian", "Email", "Phone", "Riders", "Relationships"])
    for g in guardians:
        links = list(g.rider_links.select_related("rider").all())
        writer.writerow([g.display_name, g.email, g.phone, "; ".join(str(x.rider) for x in links), "; ".join(x.relationship for x in links if x.relationship)])
    return response


@login_required
def season_setup(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team); selected = _selected_team(request)
    classes = season.season_classes.all() if season else SeasonClass.objects.none()
    memberships = season.memberships.select_related("rider").prefetch_related("classes") if season else SeasonMembership.objects.none()
    if selected in TEAM_LEVELS:
        memberships = memberships.filter(team_level=selected)
    return render(request, "portal/season_setup.html", {"season": season, "classes": classes, "memberships": memberships, "selected_team": selected})


@login_required
@friendly_integrity_errors
def season_class_create(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    initial = {"discipline": team.discipline if team.discipline != "multi" else "hunt_seat"}
    form = SeasonClassForm(request.POST or None, initial=initial, season=season)
    if form.is_valid():
        obj = form.save(commit=False); obj.season = season; obj.save()
        messages.success(request, "Season class added."); return redirect("season_setup")
    return render(request, "portal/form.html", {"form": form, "title": "Add season class", "eyebrow": season.name})


@login_required
def season_class_edit(request, class_pk):
    _require_manage(request.user); team = _team(request.user)
    season_class = get_object_or_404(SeasonClass, pk=class_pk, season__team=team)
    form = SeasonClassForm(request.POST or None, instance=season_class, season=season_class.season)
    if form.is_valid():
        form.save(); messages.success(request, "Season class updated."); return redirect("season_setup")
    return render(request, "portal/form.html", {"form": form, "title": f"Edit {season_class.name}", "eyebrow": season_class.season.name})


@login_required
def calendar(request):
    team = _team(request.user)
    selected_kind = request.GET.get("kind", "all")
    valid_kinds = {value for value, _label in CalendarEvent.Kind.choices}
    events = team.events.select_related("show", "lesson").all()
    if not _can_manage(request.user):
        events = events.filter(visible_to_all=True)
    if selected_kind in valid_kinds:
        events = events.filter(kind=selected_kind)
    else:
        selected_kind = "all"
    return render(request, "portal/calendar.html", {
        "events": events[:100], "can_manage": _can_manage(request.user),
        "selected_kind": selected_kind, "event_kinds": CalendarEvent.Kind.choices,
    })


@login_required
def event_create(request):
    _require_manage(request.user); team = _team(request.user)
    form = CalendarEventForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.team = team; obj.season = _active_season(team); obj.save()
        messages.success(request, "Calendar event added."); return redirect("calendar")
    return render(request, "portal/form.html", {"form": form, "title": "Add calendar event", "eyebrow": "SCHEDULE"})


@login_required
def event_edit(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    event = get_object_or_404(CalendarEvent.objects.select_related("show", "lesson"), pk=pk, team=team)

    if event.show_id:
        messages.info(request, "This calendar entry is synced from a show. Edit the show to update the calendar.")
        return redirect("show_edit", pk=event.show_id)
    if event.lesson_id:
        messages.info(request, "This calendar entry is synced from a lesson. Edit the lesson to update the calendar.")
        return redirect("lesson_edit", pk=event.lesson_id)

    form = CalendarEventForm(request.POST or None, instance=event)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.save()
        messages.success(request, "Calendar event updated.")
        return redirect("calendar")
    return render(request, "portal/form.html", {
        "form": form,
        "title": f"Edit calendar event · {event.title}",
        "eyebrow": "SCHEDULE",
    })


@login_required
def event_delete(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    event = get_object_or_404(CalendarEvent.objects.select_related("show", "lesson"), pk=pk, team=team)

    if event.show_id:
        messages.info(request, "This calendar entry is synced from a show. Manage the show instead of deleting the calendar copy.")
        return redirect("show_edit", pk=event.show_id)
    if event.lesson_id:
        messages.info(request, "This calendar entry is synced from a lesson. Manage the lesson instead of deleting the calendar copy.")
        return redirect("lesson_edit", pk=event.lesson_id)

    if request.method == "POST":
        title = event.title
        event.delete()
        messages.success(request, f"Calendar event ‘{title}’ deleted.")
        return redirect("calendar")

    return render(request, "portal/confirm_delete.html", {
        "object": event,
        "title": f"Delete calendar event · {event.title}",
        "message": "This will permanently remove this manually-created calendar event. It will not delete any rider, show, lesson, or other team record.",
    })


@login_required
def announcement_create(request):
    _require_manage(request.user); team = _team(request.user)
    form = AnnouncementForm(request.POST or None, team=team)
    if form.is_valid():
        obj = form.save(commit=False); obj.team = team; obj.season = _active_season(team); obj.created_by = request.user; obj.save(); form.save_m2m()
        recipient_count = _deliver_announcement(obj) if obj.published else 0
        messages.success(request, f"Announcement posted to {recipient_count} portal user{'s' if recipient_count != 1 else ''}."); return redirect("dashboard")
    return render(request, "portal/form.html", {"form": form, "title": "Post announcement", "eyebrow": "TEAM NEWS"})


@login_required
def show_list(request):
    team = _team(request.user); today = timezone.localdate(); selected = _selected_team(request)
    qs = team.shows.select_related("season")
    if selected in TEAM_LEVELS:
        qs = qs.filter(classes__season_class__team_level__in=[selected, SeasonClass.TeamLevel.BOTH]).distinct()
    upcoming = qs.filter(show_date__gte=today).order_by("show_date")
    past = qs.filter(show_date__lt=today).order_by("-show_date")[:20]
    return render(request, "portal/show_list.html", {"upcoming": upcoming, "past": past, "can_manage": _can_manage(request.user), "selected_team": selected})


@login_required
def show_detail(request, pk):
    team = _team(request.user)
    can_manage = _can_manage(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    classes = show.classes.select_related("season_class").prefetch_related(
        "entries__rider", "entries__result", "entries__rider__memberships"
    )

    postseason_team_totals = []
    team_totals = {
        SeasonMembership.TeamLevel.FUTURES: 0,
        SeasonMembership.TeamLevel.UPPER: 0,
    }

    for show_class in classes:
        for entry in show_class.entries.all():
            membership = next(
                (m for m in entry.rider.memberships.all() if m.season_id == show.season_id),
                None,
            )
            if can_manage:
                entry.point_team_label = membership.get_team_level_display() if membership else "Team"

            entry.advances_to_zones = False
            if (
                show.competition_level == Show.CompetitionLevel.REGIONAL
                and entry.competition_track == ShowEntry.CompetitionTrack.INDIVIDUAL
            ):
                result = entry.result_or_none
                entry.advances_to_zones = bool(
                    result and result.place is not None and result.place <= 2
                )

            if (
                show.competition_level != Show.CompetitionLevel.REGULAR
                and entry.competition_track == ShowEntry.CompetitionTrack.TEAM
                and membership
                and membership.team_level in team_totals
                and not _is_non_team_scoring_class(show_class)
            ):
                result = entry.result_or_none
                if result and result.points is not None:
                    team_totals[membership.team_level] = (
                        team_totals.get(membership.team_level, 0) + result.points
                    )

    if show.competition_level != Show.CompetitionLevel.REGULAR:
        labels = dict(SeasonMembership.TeamLevel.choices)
        postseason_team_totals = [
            {
                "team_level": level,
                "team_label": labels[level],
                "points": points,
                "place": (
                    show.futures_team_place
                    if level == SeasonMembership.TeamLevel.FUTURES
                    else show.upper_team_place
                ),
                "advances_to_zones": (
                    show.competition_level == Show.CompetitionLevel.REGIONAL
                    and (
                        show.futures_team_place
                        if level == SeasonMembership.TeamLevel.FUTURES
                        else show.upper_team_place
                    ) == 1
                ),
            }
            for level, points in team_totals.items()
            if ShowEntry.objects.filter(
                show_class__show=show,
                competition_track=ShowEntry.CompetitionTrack.TEAM,
                rider__memberships__season=show.season,
                rider__memberships__team_level=level,
            ).exists()
        ]

    return render(request, "portal/show_detail.html", {
        "show": show,
        "classes": classes,
        "can_manage": can_manage,
        "can_finance_show": _can_finance(request.user, show.season),
        "postseason_team_totals": postseason_team_totals,
    })


@login_required
def show_day_dashboard(request, pk):
    team = _team(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    operational = _show_day_operational_user(request.user, show)

    participating = list(_show_day_participating_riders(show).prefetch_related("memberships"))
    status_map = {
        obj.rider_id: obj
        for obj in ShowDayRiderStatus.objects.filter(show=show).select_related("rider", "updated_by")
    }

    visible_rider_ids = set(_visible_riders(request.user, team).values_list("id", flat=True))
    rows = []
    counts = {
        ShowDayRiderStatus.Status.EXPECTED: 0,
        ShowDayRiderStatus.Status.ARRIVED: 0,
        ShowDayRiderStatus.Status.RUNNING_LATE: 0,
        ShowDayRiderStatus.Status.SCRATCHED: 0,
        ShowDayRiderStatus.Status.FINISHED: 0,
    }

    for rider in participating:
        membership = next((m for m in rider.memberships.all() if m.season_id == show.season_id), None)
        status_obj = status_map.get(rider.pk)
        status_value = status_obj.status if status_obj else ShowDayRiderStatus.Status.EXPECTED
        counts[status_value] = counts.get(status_value, 0) + 1

        can_edit = _can_update_show_day_rider_status(request.user, show, rider)
        if operational or rider.pk in visible_rider_ids:
            rows.append({
                "rider": rider,
                "membership": membership,
                "status_obj": status_obj,
                "status": status_value,
                "status_label": dict(ShowDayRiderStatus.Status.choices).get(status_value, status_value),
                "can_edit": can_edit,
            })

    schedule_classes = list(
        show.classes.select_related("season_class")
        .prefetch_related("entries__rider", "entries__result")
        .order_by("sort_order", "class_number", "name")
    )

    schedule_rows = []
    results_missing = 0
    points_missing = 0

    for show_class in schedule_classes:
        active_entries = [
            e for e in show_class.entries.all()
            if e.status != ShowEntry.Status.SCRATCHED
        ]
        if not active_entries:
            continue

        if operational:
            relevant_entries = active_entries
        else:
            relevant_entries = [e for e in active_entries if e.rider_id in visible_rider_ids]
            if not relevant_entries:
                continue

        result_count = sum(1 for e in active_entries if getattr(e, "result_or_none", None))
        missing_for_class = max(len(active_entries) - result_count, 0)
        results_missing += missing_for_class

        if show.competition_level == Show.CompetitionLevel.REGULAR:
            levels_present = set()
            for entry in active_entries:
                membership = SeasonMembership.objects.filter(
                    season=show.season, rider=entry.rider
                ).first()
                if membership:
                    levels_present.add(membership.team_level)
            for level in levels_present:
                has_points_rider = any(
                    e.is_point_rider
                    and SeasonMembership.objects.filter(
                        season=show.season, rider=e.rider, team_level=level
                    ).exists()
                    for e in active_entries
                )
                if not has_points_rider and not _is_non_team_scoring_class(show_class):
                    points_missing += 1

        schedule_rows.append({
            "class": show_class,
            "entries": relevant_entries,
            "missing_results": missing_for_class if operational else 0,
        })

    recent_updates = _visible_show_day_updates(request.user, show)[:4]

    planning_items_all = list(
        show.planning_items.select_related("assigned_to", "claimed_by").order_by("sort_order", "category", "title")
    )
    planning_items = [
        item for item in planning_items_all
        if _planning_item_visible_to_user(request.user, item)
    ]
    open_volunteers = [
        item for item in planning_items
        if item.item_type == ShowPlanningItem.ItemType.VOLUNTEER
        and not item.completed and not item.owner
    ]
    incomplete_checklist = [
        item for item in planning_items
        if item.item_type == ShowPlanningItem.ItemType.CHECKLIST and not item.completed
    ]
    my_assignments = [
        item for item in planning_items
        if item.owner_id == request.user.id and not item.completed
    ]

    needs_attention = []
    if operational:
        if counts[ShowDayRiderStatus.Status.RUNNING_LATE]:
            needs_attention.append(f"{counts[ShowDayRiderStatus.Status.RUNNING_LATE]} rider(s) marked running late")
        expected_count = counts[ShowDayRiderStatus.Status.EXPECTED]
        if expected_count:
            needs_attention.append(f"{expected_count} rider(s) still expected / not checked in")
        if results_missing:
            needs_attention.append(f"{results_missing} result(s) not yet entered")
        if points_missing and _can_manage_points(request.user, show.season):
            needs_attention.append(f"{points_missing} class/team points-rider selection(s) may need attention")
        if any(not row["class"].schedule_time for row in schedule_rows):
            needs_attention.append("One or more classes do not have an estimated time")
        if open_volunteers:
            needs_attention.append(f"{len(open_volunteers)} volunteer position(s) are still unfilled")
        if incomplete_checklist:
            needs_attention.append(f"{len(incomplete_checklist)} checklist item(s) remain incomplete")

    return render(request, "portal/show_day_dashboard.html", {
        "show": show,
        "operational": operational,
        "rider_rows": rows,
        "status_choices": ShowDayRiderStatus.Status.choices,
        "counts": counts,
        "schedule_rows": schedule_rows[:8],
        "needs_attention": needs_attention,
        "recent_updates": recent_updates,
        "can_manage_points": _can_manage_points(request.user, show.season),
        "can_publish_update": _can_publish_show_update(request.user, show),
        "can_edit_schedule": bool(_show_schedule_edit_levels(request.user, show)),
        "open_volunteer_count": len(open_volunteers),
        "incomplete_checklist_count": len(incomplete_checklist),
        "my_assignments": my_assignments[:6],
        "planning_preview": planning_items[:6],
        "can_plan_show": _can_plan_show(request.user, show),
    })


@login_required
@require_POST
def show_day_rider_status_update(request, pk, rider_pk):
    team = _team(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    rider = get_object_or_404(_show_day_participating_riders(show), pk=rider_pk)

    if not _can_update_show_day_rider_status(request.user, show, rider):
        raise PermissionDenied

    status = request.POST.get("status", ShowDayRiderStatus.Status.EXPECTED)
    valid_statuses = {value for value, _ in ShowDayRiderStatus.Status.choices}
    if status not in valid_statuses:
        messages.error(request, "Choose a valid rider status.")
        return redirect("show_day_dashboard", pk=show.pk)

    note = (request.POST.get("note") or "").strip()[:180]
    obj, created = ShowDayRiderStatus.objects.get_or_create(
        show=show,
        rider=rider,
        defaults={
            "status": status,
            "note": note,
            "updated_by": request.user,
        },
    )
    if not created:
        obj.status = status
        obj.note = note
        obj.updated_by = request.user
        obj.full_clean()
        obj.save(update_fields=["status", "note", "updated_by", "updated_at"])
    else:
        obj.full_clean()
        obj.save()

    _audit_event(
        team=team,
        actor=request.user,
        action=AuditEvent.Action.CREATED if created else AuditEvent.Action.UPDATED,
        obj=obj,
        season=show.season,
        summary=f"Show-day status: {rider.display_name} → {obj.get_status_display()}",
        details={"show": show, "rider": rider, "status": obj.status, "note": obj.note},
    )
    messages.success(request, f"{rider.display_name} marked {obj.get_status_display()}.")
    return redirect("show_day_dashboard", pk=show.pk)


@login_required
def show_schedule(request, pk):
    team = _team(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    classes = list(
        show.classes.select_related("season_class", "show")
        .prefetch_related("entries__rider", "entries__result")
        .order_by("sort_order", "class_number", "name")
    )
    editable_levels = _show_schedule_edit_levels(request.user, show)
    editable_ids = {c.pk for c in classes if c.team_level in editable_levels}

    if request.method == "POST":
        _ensure_season_open(show.season)
        action = request.POST.get("schedule_action", "save")

        if not editable_ids:
            raise PermissionDenied

        if action == "save":
            changed = 0
            errors = []
            for show_class in classes:
                if show_class.pk not in editable_ids:
                    continue
                try:
                    order_raw = (request.POST.get(f"order_{show_class.pk}") or "").strip()
                    if order_raw:
                        order = int(order_raw)
                        if order < 0:
                            raise ValueError
                    else:
                        order = show_class.sort_order

                    prize_time = _parse_schedule_time(request.POST.get(f"prize_{show_class.pk}"))
                    estimate_time = _parse_schedule_time(request.POST.get(f"estimate_{show_class.pk}"))
                    note = (request.POST.get(f"note_{show_class.pk}") or "").strip()[:180]
                except (ValueError, ValidationError) as exc:
                    errors.append(f"{show_class.display_name}: {exc}")
                    continue

                before = (
                    show_class.sort_order,
                    show_class.prize_list_time,
                    show_class.estimated_time,
                    show_class.schedule_note,
                )
                after = (order, prize_time, estimate_time, note)
                if before != after:
                    show_class.sort_order = order
                    show_class.prize_list_time = prize_time
                    show_class.estimated_time = estimate_time
                    show_class.schedule_note = note
                    show_class.save(update_fields=[
                        "sort_order", "prize_list_time", "estimated_time", "schedule_note",
                    ])
                    changed += 1

            if errors:
                for error in errors[:5]:
                    messages.error(request, error)
                if len(errors) > 5:
                    messages.error(request, f"{len(errors) - 5} additional schedule row(s) could not be saved.")
            if changed:
                _audit_event(
                    team=team, actor=request.user, action=AuditEvent.Action.UPDATED,
                    obj=show, season=show.season,
                    summary=f"Updated prize-list/show-day schedule for {show.name}",
                    details={"classes_changed": changed},
                )
                messages.success(request, f"Schedule updated for {changed} class{'es' if changed != 1 else ''}.")
            elif not errors:
                messages.info(request, "No schedule changes were detected.")

        elif action == "reset_estimates":
            changed = 0
            for show_class in classes:
                if show_class.pk not in editable_ids:
                    continue
                if show_class.estimated_time != show_class.prize_list_time:
                    show_class.estimated_time = show_class.prize_list_time
                    show_class.save(update_fields=["estimated_time"])
                    changed += 1
            _audit_event(
                team=team, actor=request.user, action=AuditEvent.Action.UPDATED,
                obj=show, season=show.season,
                summary=f"Reset show-day estimates to prize-list times for {show.name}",
                details={"classes_changed": changed},
            )
            messages.success(request, f"Reset {changed} class estimate{'s' if changed != 1 else ''} to prize-list times.")

        elif action == "shift":
            try:
                minutes = int(request.POST.get("shift_minutes", "0"))
            except ValueError:
                minutes = 0
            if minutes not in {-60, -30, -15, -10, 10, 15, 30, 60}:
                messages.error(request, "Choose one of the available schedule adjustments.")
                return redirect("show_schedule", pk=show.pk)

            start_id = request.POST.get("start_class")
            start_order = None
            if start_id and start_id.isdigit():
                start_class = next((c for c in classes if c.pk == int(start_id)), None)
                if start_class:
                    start_order = start_class.sort_order

            changed = 0
            for show_class in classes:
                if show_class.pk not in editable_ids:
                    continue
                if start_order is not None and show_class.sort_order < start_order:
                    continue
                current = show_class.schedule_time
                if current is None:
                    continue
                show_class.estimated_time = _shift_schedule_time(current, minutes)
                show_class.save(update_fields=["estimated_time"])
                changed += 1

            if changed:
                sign = "+" if minutes > 0 else ""
                _audit_event(
                    team=team, actor=request.user, action=AuditEvent.Action.UPDATED,
                    obj=show, season=show.season,
                    summary=f"Shifted show-day schedule {sign}{minutes} minutes for {show.name}",
                    details={
                        "minutes": minutes,
                        "classes_changed": changed,
                        "start_class_id": start_id or "",
                    },
                )
                messages.success(
                    request,
                    f"Shifted {changed} scheduled class{'es' if changed != 1 else ''} "
                    f"{abs(minutes)} minutes {'later' if minutes > 0 else 'earlier'}.",
                )
            else:
                messages.info(request, "No scheduled class times were available to shift.")
        else:
            messages.error(request, "Unknown schedule action.")

        return redirect("show_schedule", pk=show.pk)

    visible_rider_ids = set(_visible_riders(request.user, team).values_list("id", flat=True))
    my_class_ids = set(
        ShowEntry.objects.filter(
            show_class__show=show,
            rider_id__in=visible_rider_ids,
        )
        .exclude(status=ShowEntry.Status.SCRATCHED)
        .values_list("show_class_id", flat=True)
    )

    rows = []
    for show_class in classes:
        rows.append({
            "class": show_class,
            "editable": show_class.pk in editable_ids,
            "my_class": show_class.pk in my_class_ids,
            "entry_count": show_class.entries.exclude(status=ShowEntry.Status.SCRATCHED).count(),
        })

    return render(request, "portal/show_schedule.html", {
        "show": show,
        "rows": rows,
        "can_edit_any": bool(editable_ids),
        "editable_ids": editable_ids,
    })


@login_required
def show_day_updates(request, pk):
    team = _team(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    updates = show.day_updates.filter(published=True).select_related("created_by", "updated_by")

    if not (_can_manage(request.user) or _is_show_lead(request.user, show)):
        visible_ids = []
        for update in updates:
            if _show_update_recipients(update).filter(pk=request.user.pk).exists():
                visible_ids.append(update.pk)
        updates = updates.filter(pk__in=visible_ids)

    return render(request, "portal/show_day_updates.html", {
        "show": show,
        "updates": updates,
        "can_publish": _can_publish_show_update(request.user, show),
        "allowed_audiences": _show_update_allowed_audiences(request.user, show),
    })


@login_required
def show_day_update_add(request, pk):
    team = _team(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    allowed = _show_update_allowed_audiences(request.user, show)
    if not allowed:
        raise PermissionDenied
    _ensure_season_open(show.season)
    form = ShowDayUpdateForm(request.POST or None, allowed_audiences=allowed)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.show = show
        if obj.audience not in allowed:
            raise PermissionDenied
        obj.created_by = request.user
        obj.updated_by = request.user
        obj.full_clean()
        obj.save()
        delivered = 0
        if obj.published and form.cleaned_data.get("notify_now"):
            delivered = _deliver_show_update(obj)
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.CREATED,
            obj=obj, season=show.season,
            summary=f"Published show-day update: {obj.title}",
            details={"show": show.name, "audience": obj.audience, "notified": delivered},
        )
        messages.success(
            request,
            f"Show update saved" + (f" and sent to {delivered} portal user{'s' if delivered != 1 else ''}." if delivered else "."),
        )
        return redirect("show_day_updates", pk=show.pk)
    return render(request, "portal/form.html", {
        "form": form,
        "title": f"Post show update · {show.name}",
        "eyebrow": "SHOW DAY",
    })


@login_required
def show_day_update_edit(request, update_pk):
    team = _team(request.user)
    obj = get_object_or_404(
        ShowDayUpdate.objects.select_related("show__season"), pk=update_pk, show__team=team
    )
    show = obj.show
    allowed = _show_update_allowed_audiences(request.user, show)
    if obj.audience not in allowed:
        raise PermissionDenied
    _ensure_season_open(show.season)
    form = ShowDayUpdateForm(request.POST or None, instance=obj, allowed_audiences=allowed)
    if request.method != "POST":
        form.fields["notify_now"].initial = False
    if form.is_valid():
        obj = form.save(commit=False)
        if obj.audience not in allowed:
            raise PermissionDenied
        obj.updated_by = request.user
        obj.full_clean()
        obj.save()
        delivered = 0
        if obj.published and form.cleaned_data.get("notify_now"):
            delivered = _deliver_show_update(obj, revised=True)
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED,
            obj=obj, season=show.season,
            summary=f"Updated public show-day information: {obj.title}",
            details={"show": show.name, "audience": obj.audience, "renotified": delivered},
        )
        messages.success(
            request,
            f"Show update revised" + (f" and a new notification was sent to {delivered} portal user{'s' if delivered != 1 else ''}." if delivered else "."),
        )
        return redirect("show_day_updates", pk=show.pk)
    return render(request, "portal/form.html", {
        "form": form,
        "title": f"Update public show information · {show.name}",
        "eyebrow": "SHOW DAY",
    })


@login_required
@require_POST
def show_day_update_retract(request, update_pk):
    team = _team(request.user)
    obj = get_object_or_404(
        ShowDayUpdate.objects.select_related("show__season"), pk=update_pk, show__team=team
    )
    if not _can_publish_show_update(request.user, obj.show, obj.audience):
        raise PermissionDenied
    _ensure_season_open(obj.show.season)
    obj.published = False
    obj.updated_by = request.user
    obj.save(update_fields=["published", "updated_by", "updated_at"])
    _audit_event(
        team=team, actor=request.user, action=AuditEvent.Action.REMOVED,
        obj=obj, season=obj.show.season,
        summary=f"Retracted public show-day update: {obj.title}",
        details={"show": obj.show.name, "audience": obj.audience},
    )
    messages.success(request, "Show update retracted. Existing notification history is retained.")
    return redirect("show_day_updates", pk=obj.show_id)


@login_required
def show_week_summary(request, pk):
    team = _team(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    can_manage = _can_manage(request.user)
    classes = show.classes.select_related("season_class").prefetch_related("entries__rider", "entries__result")
    roster = Rider.objects.filter(show_entries__show_class__show=show).distinct().order_by("last_name", "first_name")
    availability = ShowAvailability.objects.filter(show=show, rider__in=roster).select_related("rider")
    if not can_manage:
        availability = availability.filter(rider__in=_visible_riders(request.user, team))
    return render(request, "portal/show_week_summary.html", {
        "show": show, "classes": classes, "roster": roster, "availability": availability, "can_manage": can_manage,
    })


@login_required
@require_POST
def show_week_summary_send(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    show = get_object_or_404(Show, pk=pk, team=team)
    riders = Rider.objects.filter(show_entries__show_class__show=show).distinct()
    recipient_ids = set(riders.exclude(user__isnull=True).values_list("user_id", flat=True))
    recipient_ids.update(GuardianContact.objects.filter(rider_links__rider__in=riders, user__isnull=False).values_list("user_id", flat=True))
    recipient_ids.update(User.objects.filter(profile__team=team, profile__role__in=[UserProfile.Role.ADMIN, UserProfile.Role.COACH]).values_list("id", flat=True))
    title = f"Show week: {show.name}"
    body = f"{show.name} is {show.show_date:%A, %B %d}. Check the portal for entries, schedule, venue, and your availability status."
    created = 0
    for user in User.objects.filter(id__in=recipient_ids, is_active=True).select_related("profile"):
        notification = Notification.objects.create(user=user, title=title, body=body, link=f"/shows/{show.pk}/week/")
        created += 1
        profile = getattr(user, "profile", None)
        if settings.EMAIL_HOST and user.email and (not profile or profile.email_reminders):
            send_mail(title, body, settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=True)
    messages.success(request, f"Show-week summary sent to {created} portal user{'s' if created != 1 else ''}.")
    return redirect("show_week_summary", pk=show.pk)


@login_required
def show_create(request):
    _require_manage(request.user); team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season before adding a show."); return redirect("show_list")
    form = ShowForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.team = team; obj.season = season; obj.save(); _sync_show_calendar(obj)
        messages.success(request, "Show added and synced to the calendar."); return redirect("show_detail", pk=obj.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add show", "eyebrow": "COMPETITION"})


@login_required
def show_edit(request, pk):
    _require_manage(request.user); team = _team(request.user)
    show = get_object_or_404(Show, pk=pk, team=team); form = ShowForm(request.POST or None, instance=show)
    if form.is_valid():
        form.save(); _sync_show_calendar(show); messages.success(request, "Show and calendar updated."); return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Edit show", "eyebrow": "COMPETITION"})


@login_required
def show_delete(request, pk):
    _require_manage(request.user); team = _team(request.user); show = get_object_or_404(Show, pk=pk, team=team)
    if request.method == "POST":
        show.delete(); messages.success(request, "Show deleted."); return redirect("show_list")
    return render(request, "portal/confirm_delete.html", {"object": show, "title": "Delete show", "message": "This also removes its show classes, entries, results, and linked calendar event."})


@login_required
@friendly_integrity_errors
def show_class_create(request, show_pk):
    _require_manage(request.user); team = _team(request.user); show = get_object_or_404(Show, pk=show_pk, team=team)
    if not show.season.season_classes.filter(active=True).exists():
        messages.error(request, "Set up season classes first, then add them to the show."); return redirect("season_setup")
    form = ShowClassForm(request.POST or None, show=show)
    if form.is_valid():
        obj = form.save(commit=False); obj.show = show; obj.save(); messages.success(request, "Season class added to this show."); return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add season class to show", "eyebrow": show.name})


@login_required
def show_class_edit(request, class_pk):
    _require_manage(request.user); team = _team(request.user)
    obj = get_object_or_404(ShowClass.objects.select_related("show"), pk=class_pk, show__team=team)
    form = ShowClassForm(request.POST or None, instance=obj, show=obj.show)
    if form.is_valid():
        form.save(); messages.success(request, "Show class updated."); return redirect("show_detail", pk=obj.show_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Edit {obj.display_name}", "eyebrow": obj.show.name})


@login_required
def show_class_delete(request, class_pk):
    _require_manage(request.user); team = _team(request.user)
    obj = get_object_or_404(ShowClass.objects.select_related("show"), pk=class_pk, show__team=team); show_id = obj.show_id
    if request.method == "POST":
        obj.delete(); messages.success(request, "Show class and its entries removed."); return redirect("show_detail", pk=show_id)
    return render(request, "portal/confirm_delete.html", {"object": obj, "title": "Remove class from show", "message": "Entries and results recorded under this show class will also be deleted."})


@login_required
@friendly_integrity_errors
def show_entry_create(request, show_pk):
    _require_manage(request.user); team = _team(request.user); show = get_object_or_404(Show, pk=show_pk, team=team)
    form = ShowEntryForm(request.POST or None, show=show, team=team)
    if form.is_valid():
        entry = form.save(commit=False)
        if entry.show_class.show_id != show.id or entry.rider.team_id != team.id: raise PermissionDenied
        entry.full_clean(); entry.save(); messages.success(request, "Rider entry added from season class assignment."); return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add rider entry", "eyebrow": show.name})


@login_required
def show_entry_edit(request, entry_pk):
    _require_manage(request.user); team = _team(request.user)
    entry = get_object_or_404(ShowEntry.objects.select_related("show_class__show", "rider"), pk=entry_pk, show_class__show__team=team); show = entry.show_class.show
    form = ShowEntryForm(request.POST or None, instance=entry, show=show, team=team)
    if form.is_valid():
        obj = form.save(commit=False); obj.full_clean(); obj.save(); messages.success(request, "Rider entry updated."); return redirect("show_detail", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Edit entry · {entry.rider}", "eyebrow": show.name})


@login_required
def show_entry_delete(request, entry_pk):
    _require_manage(request.user); team = _team(request.user)
    entry = get_object_or_404(ShowEntry.objects.select_related("show_class__show", "rider"), pk=entry_pk, show_class__show__team=team); show_id = entry.show_class.show_id
    if request.method == "POST":
        entry.delete(); messages.success(request, "Rider entry removed."); return redirect("show_detail", pk=show_id)
    return render(request, "portal/confirm_delete.html", {"object": entry, "title": "Remove rider entry", "message": "Any result attached to this entry will also be deleted."})


@login_required
def show_result_edit(request, entry_pk):
    team = _team(request.user)
    entry_probe = get_object_or_404(ShowEntry.objects.select_related("show_class__show__season"), pk=entry_pk, show_class__show__team=team)
    if not _can_manage_points(request.user, entry_probe.show_class.show.season):
        raise PermissionDenied
    _ensure_season_open(entry_probe.show_class.show.season)
    entry = get_object_or_404(ShowEntry.objects.select_related("show_class__show", "rider"), pk=entry_pk, show_class__show__team=team)
    result, created = ShowResult.objects.get_or_create(entry=entry); form = ShowResultForm(request.POST or None, instance=result)
    if form.is_valid():
        result = form.save()
        _audit_event(
            team=team, actor=request.user,
            action=AuditEvent.Action.CREATED if created else AuditEvent.Action.UPDATED,
            obj=result, season=entry.show_class.show.season,
            summary=f"Saved result for {entry.rider} · {entry.show_class.display_name}",
            details={"show": entry.show_class.show, "rider": entry.rider, "points": result.points},
        )
        messages.success(request, "Result saved.")
        return redirect("show_detail", pk=entry.show_class.show_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Result · {entry.rider}", "eyebrow": entry.show_class.display_name})



def _qualification_rows(season, team_level="all"):
    config, _ = SeasonScoringConfig.objects.get_or_create(season=season)
    memberships = season.memberships.select_related("rider").prefetch_related("classes", "qualification_overrides")
    if team_level in TEAM_LEVELS:
        memberships = memberships.filter(team_level=team_level)
    rows = []
    for membership in memberships:
        for season_class in membership.classes.filter(active=True).order_by("sort_order", "name"):
            total = ShowResult.objects.filter(
                entry__rider=membership.rider,
                entry__show_class__show__season=season,
                entry__show_class__show__competition_level=Show.CompetitionLevel.REGULAR,
                entry__competition_track=ShowEntry.CompetitionTrack.REGULAR,
                entry__show_class__season_class=season_class,
                entry__status__in=[ShowEntry.Status.PLANNED, ShowEntry.Status.ENTERED],
            ).aggregate(total=Sum("points"))["total"] or 0
            override = membership.qualification_overrides.filter(season_class=season_class).first()
            auto_qualified = total >= config.individual_qualification_points
            if override and override.status == QualificationOverride.Status.QUALIFIED:
                qualified = True
            elif override and override.status == QualificationOverride.Status.NOT_QUALIFIED:
                qualified = False
            else:
                qualified = auto_qualified
            rows.append({
                "membership": membership, "rider": membership.rider, "season_class": season_class,
                "points": total, "threshold": config.individual_qualification_points,
                "qualified": qualified, "override": override,
            })
    return rows


def _team_scoring_rows(season, team_level="all", include_riders=True):
    config, _ = SeasonScoringConfig.objects.get_or_create(season=season)
    levels = [SeasonMembership.TeamLevel.FUTURES, SeasonMembership.TeamLevel.UPPER]
    if team_level in TEAM_LEVELS:
        levels = [team_level]
    rows = []
    totals = {level: 0 for level in levels}
    shows = season.shows.filter(
        competition_level=Show.CompetitionLevel.REGULAR
    ).order_by("show_date", "name")
    for show in shows:
        for level in levels:
            entries = ShowEntry.objects.filter(
                show_class__show=show,
                competition_track=ShowEntry.CompetitionTrack.REGULAR,
                is_point_rider=True,
                status__in=[ShowEntry.Status.PLANNED, ShowEntry.Status.ENTERED],
                rider__memberships__season=season, rider__memberships__team_level=level,
            ).select_related("rider", "show_class__season_class", "result").distinct()
            class_rows = []
            show_total = 0
            for entry in entries:
                if _is_non_team_scoring_class(entry.show_class):
                    continue
                result = entry.result_or_none
                points = result.points if result and result.points is not None else 0
                show_total += points
                class_row = {
                    "class_name": entry.show_class.display_name,
                    "points": points,
                    "result": result,
                }
                if include_riders:
                    class_row["entry"] = entry
                    class_row["rider"] = entry.rider
                class_rows.append(class_row)
            totals[level] += show_total
            rows.append({"show": show, "team_level": level, "team_label": dict(SeasonMembership.TeamLevel.choices)[level], "points": show_total, "classes": class_rows})
    summary = [{
        "team_level": level, "team_label": dict(SeasonMembership.TeamLevel.choices)[level],
        "points": totals[level], "threshold": config.team_qualification_points,
        "qualified": totals[level] >= config.team_qualification_points,
    } for level in levels]
    return rows, summary


@login_required
def standings(request):
    team = _team(request.user)
    season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season before viewing standings.")
        return redirect("season_setup")
    selected = _selected_team(request)
    config, _ = SeasonScoringConfig.objects.get_or_create(season=season)
    individual = _qualification_rows(season, selected)
    can_manage = _can_manage(request.user)
    can_manage_points = _can_manage_points(request.user, season)
    team_rows, team_summary = _team_scoring_rows(season, selected, include_riders=can_manage_points)
    return render(request, "portal/standings.html", {
        "season": season, "config": config, "individual_rows": individual,
        "team_rows": team_rows, "team_summary": team_summary,
        "selected_team": selected, "can_manage": can_manage, "can_manage_points": can_manage_points,
    })


@login_required
def scoring_settings(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    config, _ = SeasonScoringConfig.objects.get_or_create(season=season)
    form = SeasonScoringConfigForm(request.POST or None, instance=config)
    if form.is_valid():
        form.save(); messages.success(request, "Season scoring and qualification rules updated."); return redirect("standings")
    return render(request, "portal/form.html", {"form": form, "title": "Scoring & qualification rules", "eyebrow": season.name})


@login_required
def qualification_override_edit(request, membership_pk, class_pk):
    team = _team(request.user)
    membership_probe = get_object_or_404(SeasonMembership.objects.select_related("season"), pk=membership_pk, season__team=team)
    if not _can_manage_points(request.user, membership_probe.season):
        raise PermissionDenied
    _ensure_season_open(membership_probe.season)
    membership = membership_probe
    membership = SeasonMembership.objects.select_related("rider", "season").get(pk=membership.pk)
    season_class = get_object_or_404(SeasonClass, pk=class_pk, season=membership.season)
    if not membership.classes.filter(pk=season_class.pk).exists():
        raise PermissionDenied("This rider is not assigned to that season class.")
    override, _ = QualificationOverride.objects.get_or_create(membership=membership, season_class=season_class)
    form = QualificationOverrideForm(request.POST or None, instance=override)
    if form.is_valid():
        obj = form.save()
        if obj.status == QualificationOverride.Status.AUTO and not obj.notes:
            obj.delete()
        messages.success(request, "Qualification status updated."); return redirect("standings")
    return render(request, "portal/form.html", {"form": form, "title": f"Qualification · {membership.rider}", "eyebrow": season_class.name})


@login_required
def standings_export(request):
    team = _team(request.user); season = _active_season(team)
    if season and not _can_manage_points(request.user, season):
        raise PermissionDenied
    if not season:
        return HttpResponse("No active season", status=400)
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="{season.name}-standings.csv"'
    writer = csv.writer(response)
    writer.writerow(["Individual qualification"])
    writer.writerow(["Team", "Rider", "Class", "Points", "Threshold", "Qualified"])
    for row in _qualification_rows(season):
        writer.writerow([row["membership"].get_team_level_display(), row["rider"], row["season_class"].name, row["points"], row["threshold"], "Yes" if row["qualified"] else "No"])
    writer.writerow([]); writer.writerow(["Team points"])
    writer.writerow(["Show", "Team", "Points rider", "Class", "Place", "Points"])
    team_rows, _ = _team_scoring_rows(season, include_riders=True)
    for row in team_rows:
        for cr in row["classes"]:
            result = cr["result"]
            writer.writerow([row["show"].name, row["team_label"], cr["entry"].rider, cr["entry"].show_class.display_name, result.place if result else "", cr["points"]])
    return response


@login_required
@require_POST
def point_rider_set(request, entry_pk):
    _require_manage(request.user); team = _team(request.user)
    entry = get_object_or_404(
        ShowEntry.objects.select_related("show_class__show", "rider"),
        pk=entry_pk, show_class__show__team=team,
    )
    show = entry.show_class.show
    if show.competition_level != Show.CompetitionLevel.REGULAR:
        messages.error(
            request,
            "Finals use separate Individual and Team entries instead of regular-season point-rider designations."
        )
        return redirect("show_detail", pk=show.pk)
    if _is_non_team_scoring_class(entry.show_class):
        entry.is_point_rider = False
        entry.save(update_fields=["is_point_rider"])
        messages.error(
            request,
            f"{entry.show_class.display_name} is an H8/H14 Walk/Trot class and does not count toward team points."
        )
        return redirect("show_detail", pk=show.pk)
    membership = SeasonMembership.objects.filter(rider=entry.rider, season=show.season).first()
    if not membership:
        messages.error(request, "This rider is not on the season roster.")
        return redirect("show_detail", pk=show.pk)
    clear = request.POST.get("clear") == "1"
    if clear:
        entry.is_point_rider = False
        entry.save(update_fields=["is_point_rider"])
        messages.success(request, f"Cleared {entry.rider} as the points rider for {entry.show_class.display_name}.")
        return redirect("show_detail", pk=show.pk)
    for other in entry.show_class.entries.filter(is_point_rider=True).exclude(pk=entry.pk).select_related("rider"):
        other_membership = SeasonMembership.objects.filter(rider=other.rider, season=show.season).first()
        if other_membership and other_membership.team_level == membership.team_level:
            other.is_point_rider = False
            other.save(update_fields=["is_point_rider"])
    entry.is_point_rider = True
    update_fields = ["is_point_rider"]
    if entry.entry_type == ShowEntry.EntryType.INDIVIDUAL:
        entry.entry_type = ShowEntry.EntryType.BOTH
        update_fields.append("entry_type")
    entry.full_clean()
    entry.save(update_fields=update_fields)
    messages.success(request, f"{entry.rider} is the {membership.get_team_level_display()} points rider for {entry.show_class.display_name}.")
    return redirect("show_detail", pk=show.pk)


def _sync_lesson_calendar(lesson):
    CalendarEvent.objects.update_or_create(
        lesson=lesson,
        defaults={
            "team": lesson.team,
            "season": lesson.season,
            "title": lesson.title,
            "kind": CalendarEvent.Kind.LESSON,
            "starts_at": lesson.starts_at,
            "ends_at": lesson.ends_at,
            "all_day": False,
            "location": lesson.location,
            "description": lesson.notes,
            "visible_to_all": True,
        },
    )


def _seed_lesson_attendance(lesson):
    if not lesson.group_id:
        return
    for rider in lesson.group.riders.filter(active=True):
        LessonAttendance.objects.get_or_create(lesson=lesson, rider=rider)


def _volunteer_requirement(membership):
    if membership.team_level == SeasonMembership.TeamLevel.FUTURES:
        return membership.season.futures_volunteer_hours_required
    if membership.team_level == SeasonMembership.TeamLevel.UPPER:
        return membership.season.upper_volunteer_hours_required
    return 0


def _volunteer_progress_rows(season, riders):
    memberships = SeasonMembership.objects.filter(season=season, rider__in=riders).select_related("rider", "season").order_by("rider__last_name", "rider__first_name")
    rows = []
    for membership in memberships:
        approved = VolunteerLog.objects.filter(season=season, rider=membership.rider, status=VolunteerLog.Status.APPROVED).aggregate(total=Sum("hours"))["total"] or 0
        pending = VolunteerLog.objects.filter(season=season, rider=membership.rider, status=VolunteerLog.Status.PENDING).aggregate(total=Sum("hours"))["total"] or 0
        required = _volunteer_requirement(membership)
        remaining = max(required - approved, 0)
        rows.append({
            "membership": membership,
            "rider": membership.rider,
            "required": required,
            "approved": approved,
            "pending": pending,
            "remaining": remaining,
            "complete": required <= 0 or approved >= required,
        })
    return rows


@login_required
def lesson_list(request):
    team = _team(request.user)
    season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season before scheduling lessons.")
        return redirect("season_setup")
    lessons = season.lessons.select_related("group", "coach").prefetch_related("attendance__rider")
    if not _can_manage(request.user):
        visible = _visible_riders(request.user, team)
        lessons = lessons.filter(attendance__rider__in=visible).distinct()
    upcoming = lessons.filter(starts_at__gte=timezone.now()).order_by("starts_at")
    recent = lessons.filter(starts_at__lt=timezone.now()).order_by("-starts_at")[:12]
    return render(request, "portal/lesson_list.html", {
        "season": season, "upcoming": upcoming, "recent": recent, "can_manage": _can_manage(request.user),
    })


@login_required
def lesson_group_list(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    groups = season.lesson_groups.prefetch_related("riders").select_related("coach")
    return render(request, "portal/lesson_groups.html", {"season": season, "groups": groups})


@login_required
@friendly_integrity_errors
def lesson_group_create(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    form = LessonGroupForm(request.POST or None, season=season, team=team)
    if form.is_valid():
        obj = form.save(commit=False); obj.season = season; obj.save(); form.save_m2m()
        messages.success(request, "Lesson group created."); return redirect("lesson_group_list")
    return render(request, "portal/form.html", {"form": form, "title": "Create lesson group", "eyebrow": season.name})


@login_required
def lesson_group_edit(request, pk):
    _require_manage(request.user)
    team = _team(request.user); group = get_object_or_404(LessonGroup, pk=pk, season__team=team)
    form = LessonGroupForm(request.POST or None, instance=group, season=group.season, team=team)
    if form.is_valid():
        form.save(); messages.success(request, "Lesson group updated."); return redirect("lesson_group_list")
    return render(request, "portal/form.html", {"form": form, "title": f"Edit {group.name}", "eyebrow": group.season.name})


@login_required
def lesson_create(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    form = LessonForm(request.POST or None, season=season, team=team)
    if form.is_valid():
        base = form.save(commit=False)
        weeks = form.cleaned_data.get("recurrence_weeks", 1)
        created = []
        for index in range(weeks):
            lesson = Lesson.objects.create(
                team=team, season=season, group=base.group, coach=base.coach,
                title=base.title,
                starts_at=base.starts_at + timedelta(weeks=index),
                ends_at=(base.ends_at + timedelta(weeks=index)) if base.ends_at else None,
                location=base.location or (base.group.default_location if base.group else ""),
                notes=base.notes, cancelled=base.cancelled,
            )
            _seed_lesson_attendance(lesson); _sync_lesson_calendar(lesson); created.append(lesson)
        messages.success(request, f"Created {len(created)} lesson{'s' if len(created) != 1 else ''}.")
        return redirect("lesson_list")
    return render(request, "portal/form.html", {"form": form, "title": "Schedule lesson", "eyebrow": season.name})


@login_required
def lesson_detail(request, pk):
    team = _team(request.user)
    lesson = get_object_or_404(Lesson.objects.select_related("season", "group", "coach"), pk=pk, team=team)
    visible = _visible_riders(request.user, team)
    attendance = lesson.attendance.select_related("rider")
    if not _can_manage(request.user):
        attendance = attendance.filter(rider__in=visible)
        if not attendance.exists():
            raise PermissionDenied
    return render(request, "portal/lesson_detail.html", {"lesson": lesson, "attendance": attendance, "can_manage": _can_manage(request.user)})


@login_required
def lesson_edit(request, pk):
    _require_manage(request.user)
    team = _team(request.user); lesson = get_object_or_404(Lesson, pk=pk, team=team)
    form = LessonForm(request.POST or None, instance=lesson, season=lesson.season, team=team)
    if form.is_valid():
        obj = form.save(); _seed_lesson_attendance(obj); _sync_lesson_calendar(obj)
        messages.success(request, "Lesson updated."); return redirect("lesson_detail", pk=obj.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Edit lesson", "eyebrow": lesson.season.name})


@login_required
def lesson_delete(request, pk):
    _require_manage(request.user)
    team = _team(request.user); lesson = get_object_or_404(Lesson, pk=pk, team=team)
    if request.method == "POST":
        lesson.delete(); messages.success(request, "Lesson deleted."); return redirect("lesson_list")
    return render(request, "portal/confirm_delete.html", {"object": lesson, "title": "Delete lesson", "message": "Attendance and the linked calendar event will also be deleted."})


@login_required
def lesson_attendance_edit(request, attendance_pk):
    _require_manage(request.user)
    team = _team(request.user)
    attendance = get_object_or_404(LessonAttendance.objects.select_related("lesson", "rider"), pk=attendance_pk, lesson__team=team)
    form = LessonAttendanceForm(request.POST or None, instance=attendance)
    if form.is_valid():
        form.save(); messages.success(request, f"Attendance updated for {attendance.rider}."); return redirect("lesson_detail", pk=attendance.lesson_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Attendance · {attendance.rider}", "eyebrow": attendance.lesson.title})


@login_required
def show_availability(request, show_pk):
    team = _team(request.user); show = get_object_or_404(Show, pk=show_pk, team=team)
    roster = Rider.objects.filter(team=team, active=True, memberships__season=show.season).distinct().order_by("last_name", "first_name")
    if not _can_manage(request.user):
        roster = roster.filter(pk__in=_visible_riders(request.user, team).values("pk"))
    rows = []
    for rider in roster:
        response, _ = ShowAvailability.objects.get_or_create(show=show, rider=rider)
        rows.append(response)
    return render(request, "portal/show_availability.html", {"show": show, "responses": rows, "can_manage": _can_manage(request.user)})


@login_required
def show_availability_edit(request, show_pk, rider_pk):
    team = _team(request.user); show = get_object_or_404(Show, pk=show_pk, team=team)
    rider = get_object_or_404(Rider, pk=rider_pk, team=team, memberships__season=show.season)
    if not _can_manage(request.user) and not _visible_riders(request.user, team).filter(pk=rider.pk).exists():
        raise PermissionDenied
    response, _ = ShowAvailability.objects.get_or_create(show=show, rider=rider)
    form = ShowAvailabilityForm(request.POST or None, instance=response)
    if form.is_valid():
        obj = form.save(commit=False); obj.responded_by = request.user
        obj.responded_at = timezone.now() if obj.status != ShowAvailability.Status.PENDING else None
        obj.save(); messages.success(request, f"Availability updated for {rider}."); return redirect("show_availability", show_pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Show availability · {rider}", "eyebrow": show.name})


@login_required
def volunteer_dashboard(request):
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season before tracking volunteer hours."); return redirect("season_setup")
    riders = team.riders.filter(active=True, memberships__season=season).distinct() if _can_manage(request.user) else _visible_riders(request.user, team).filter(active=True, memberships__season=season).distinct()
    rows = _volunteer_progress_rows(season, riders)
    logs = VolunteerLog.objects.filter(season=season, rider__in=riders).select_related("rider", "submitted_by", "approved_by")
    return render(request, "portal/volunteer_dashboard.html", {
        "season": season, "rows": rows, "logs": logs[:60], "can_manage": _can_manage(request.user),
        "pending_count": logs.filter(status=VolunteerLog.Status.PENDING).count(),
    })


@login_required
def volunteer_submit(request):
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    visible = team.riders.filter(active=True) if _can_manage(request.user) else _visible_riders(request.user, team).filter(active=True)
    form = VolunteerLogForm(request.POST or None, team=team, season=season, visible_riders=visible)
    if form.is_valid():
        log = form.save(commit=False); log.season = season; log.submitted_by = request.user
        if _can_manage(request.user):
            log.status = VolunteerLog.Status.APPROVED; log.approved_by = request.user; log.approved_at = timezone.now()
        log.full_clean(); log.save()
        messages.success(request, "Volunteer hours recorded." if _can_manage(request.user) else "Volunteer hours submitted for coach approval.")
        return redirect("volunteer_dashboard")
    return render(request, "portal/form.html", {"form": form, "title": "Record volunteer hours", "eyebrow": season.name})


@login_required
def volunteer_review(request, pk):
    _require_manage(request.user)
    team = _team(request.user); log = get_object_or_404(VolunteerLog.objects.select_related("rider", "season"), pk=pk, season__team=team)
    form = VolunteerReviewForm(request.POST or None, instance=log)
    if form.is_valid():
        obj = form.save(commit=False)
        if obj.status == VolunteerLog.Status.APPROVED:
            obj.approved_by = request.user; obj.approved_at = timezone.now()
        else:
            obj.approved_by = None; obj.approved_at = None
        obj.save(); messages.success(request, "Volunteer entry reviewed."); return redirect("volunteer_dashboard")
    return render(request, "portal/form.html", {"form": form, "title": f"Review volunteer hours · {log.rider}", "eyebrow": f"{log.hours} hours · {log.service_date:%b %d, %Y}"})


@login_required
def volunteer_requirements(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season first."); return redirect("season_setup")
    form = VolunteerRequirementForm(request.POST or None, instance=season)
    if form.is_valid():
        form.save(); messages.success(request, "Volunteer-hour requirements updated."); return redirect("volunteer_dashboard")
    return render(request, "portal/form.html", {"form": form, "title": "Volunteer-hour requirements", "eyebrow": season.name})


@login_required
def volunteer_export(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        return HttpResponse("No active season", status=400)
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="{season.name}-volunteer-hours.csv"'
    writer = csv.writer(response)
    writer.writerow(["Team", "Rider", "Required", "Approved", "Pending", "Remaining", "Complete"])
    riders = team.riders.filter(active=True, memberships__season=season).distinct()
    for row in _volunteer_progress_rows(season, riders):
        writer.writerow([row["membership"].get_team_level_display(), row["rider"], row["required"], row["approved"], row["pending"], row["remaining"], "Yes" if row["complete"] else "No"])
    writer.writerow([])
    writer.writerow(["Rider", "Date", "Hours", "Category", "Performed by", "Description", "Status", "Submitted by", "Approved by"])
    for log in season.volunteer_logs.select_related("rider", "submitted_by", "approved_by"):
        writer.writerow([log.rider, log.service_date, log.hours, log.get_category_display(), log.performed_by, log.description, log.get_status_display(), log.submitted_by or "", log.approved_by or ""])
    return response




def _rider_class_point_rows(season, rider):
    """Return season points per class; individual qualification is never combined across classes."""
    membership = SeasonMembership.objects.filter(
        season=season, rider=rider
    ).prefetch_related("classes").first()
    if not membership:
        return []

    rows = []
    for season_class in membership.classes.all().order_by("sort_order", "name"):
        result_qs = ShowResult.objects.filter(
            entry__rider=rider,
            entry__show_class__show__season=season,
            entry__show_class__show__competition_level=Show.CompetitionLevel.REGULAR,
            entry__competition_track=ShowEntry.CompetitionTrack.REGULAR,
            entry__show_class__season_class=season_class,
            entry__status__in=[ShowEntry.Status.PLANNED, ShowEntry.Status.ENTERED],
        )
        rows.append({
            "season_class": season_class,
            "points": result_qs.aggregate(total=Sum("points"))["total"] or 0,
            "wins": result_qs.filter(place=1).count(),
        })
    return rows


def _is_non_team_scoring_class(show_class):
    """IEA Hunt Seat H8/H14 Walk/Trot classes do not contribute team points."""
    candidates = [
        show_class.class_number or "",
        show_class.display_name or "",
        show_class.name or "",
    ]
    for value in candidates:
        normalized = re.sub(r"[^A-Z0-9]+", "", value.upper())
        if normalized in {"H8", "H14"}:
            return True
        # Handles labels such as "H8 Walk/Trot..." or "H14 - Walk Trot".
        if re.match(r"^\s*H(?:8|14)\b", value.upper()):
            return True
    return False


def _season_rider_summary(season, riders):
    rows = []
    for rider in riders:
        membership = SeasonMembership.objects.filter(season=season, rider=rider).prefetch_related("classes").first()
        results = ShowResult.objects.filter(
            entry__rider=rider, entry__show_class__show__season=season
        ).select_related("entry__show_class__show")
        class_points = _rider_class_point_rows(season, rider)
        shows = ShowEntry.objects.filter(rider=rider, show_class__show__season=season).values("show_class__show_id").distinct().count()
        wins = results.filter(place=1).count()
        attendance = LessonAttendance.objects.filter(
            rider=rider, lesson__season=season, status=LessonAttendance.Status.PRESENT
        ).count()
        approved_hours = VolunteerLog.objects.filter(
            rider=rider, season=season, status=VolunteerLog.Status.APPROVED
        ).aggregate(total=Sum("hours"))["total"] or 0
        rows.append({
            "rider": rider,
            "membership": membership,
            "class_points": class_points,
            "shows": shows,
            "wins": wins,
            "attendance": attendance,
            "volunteer_hours": approved_hours,
        })
    return rows


@login_required
def season_archive(request):
    team = _team(request.user)
    seasons = Season.objects.filter(team=team).order_by("-start_date")
    return render(request, "portal/season_archive.html", {
        "seasons": seasons, "can_manage": _can_manage(request.user)
    })


@login_required
def season_review(request, season_pk):
    team = _team(request.user)
    season = get_object_or_404(Season, pk=season_pk, team=team)
    points_access = _can_manage_points(request.user, season)
    if _can_manage(request.user) or points_access:
        riders = Rider.objects.filter(memberships__season=season).distinct().order_by("last_name", "first_name")
    else:
        riders = _visible_riders(request.user, team).filter(memberships__season=season).distinct()
    rider_rows = _season_rider_summary(season, riders)
    for row in rider_rows:
        row["can_history"] = _can_view_private_rider(request.user, row["rider"])
    qualification_rows = _qualification_rows(season) if points_access else [
        row for row in _qualification_rows(season) if row["rider"].pk in {r.pk for r in riders}
    ]
    awards = RiderAward.objects.filter(season=season, published=True).select_related("rider")
    if not (_can_manage(request.user) or points_access):
        awards = awards.filter(rider__in=riders)
    team_rows, team_summary = _team_scoring_rows(season, include_riders=points_access)
    postseason_results = ShowResult.objects.filter(
        entry__show_class__show__season=season,
        entry__show_class__show__competition_level__in=[
            Show.CompetitionLevel.REGIONAL,
            Show.CompetitionLevel.ZONE,
            Show.CompetitionLevel.NATIONAL,
        ],
    ).select_related(
        "entry__rider", "entry__show_class__show", "entry__show_class__season_class"
    ).order_by(
        "entry__show_class__show__show_date",
        "entry__show_class__sort_order",
        "entry__rider__last_name",
    )
    if not (_can_manage(request.user) or points_access):
        postseason_results = postseason_results.filter(entry__rider__in=riders)
    return render(request, "portal/season_review.html", {
        "season": season, "rider_rows": rider_rows, "qualification_rows": qualification_rows,
        "awards": awards, "team_summary": team_summary, "can_manage": _can_manage(request.user),
        "can_manage_points": points_access, "postseason_results": postseason_results,
    })


@login_required
@require_POST
def season_close(request, season_pk):
    if not _is_admin(request.user):
        raise PermissionDenied
    team = _team(request.user); season = get_object_or_404(Season, pk=season_pk, team=team)
    season.is_closed = True; season.is_active = False; season.closed_at = timezone.now()
    season.save(update_fields=["is_closed", "is_active", "closed_at"])
    messages.success(request, f"{season.name} is now archived.")
    return redirect("season_review", season_pk=season.pk)


@login_required
@require_POST
def season_reopen(request, season_pk):
    if not _is_admin(request.user):
        raise PermissionDenied
    team = _team(request.user); season = get_object_or_404(Season, pk=season_pk, team=team)
    season.is_closed = False; season.closed_at = None
    season.save(update_fields=["is_closed", "closed_at"])
    messages.success(request, f"{season.name} reopened for editing.")
    return redirect("season_review", season_pk=season.pk)


@login_required
def rider_history(request, pk):
    team = _team(request.user); rider = get_object_or_404(Rider, pk=pk, team=team)
    if not _can_view_private_rider(request.user, rider):
        raise PermissionDenied
    seasons = Season.objects.filter(memberships__rider=rider).distinct().order_by("-start_date")
    history = []
    for season in seasons:
        summary_rows = _season_rider_summary(season, [rider])
        if not summary_rows:
            continue
        row = summary_rows[0]
        row["awards"] = RiderAward.objects.filter(season=season, rider=rider)
        if not _can_manage(request.user):
            row["awards"] = row["awards"].filter(published=True)
        notes = RiderDevelopmentNote.objects.filter(season=season, rider=rider).select_related("author")
        if not _can_manage(request.user):
            notes = notes.filter(family_visible=True)
        row["notes"] = notes
        row["results"] = ShowResult.objects.filter(
            entry__rider=rider,
            entry__show_class__show__season=season,
        ).select_related(
            "entry__show_class__show", "entry__show_class__season_class"
        ).order_by("-entry__show_class__show__show_date", "entry__show_class__sort_order")
        history.append(row)
    return render(request, "portal/rider_history.html", {
        "rider": rider, "history": history, "can_manage": _can_manage(request.user)
    })


@login_required
def historical_results_add(request, pk, season_pk=None):
    """Enter prior-season individual results without rebuilding the normal show-entry workflow."""
    _require_manage(request.user)
    team = _team(request.user)
    rider = get_object_or_404(Rider, pk=pk, team=team)

    initial = {}
    if season_pk:
        season = get_object_or_404(
            Season.objects.filter(team=team, memberships__rider=rider).distinct(),
            pk=season_pk,
        )
        initial["season"] = season

    header = HistoricalResultHeaderForm(
        request.POST or None,
        team=team,
        rider=rider,
        initial=initial,
    )

    selected_season = None
    selected_competition_level = Show.CompetitionLevel.REGULAR
    header_valid = header.is_valid() if request.method == "POST" else False
    if request.method == "POST" and header_valid:
        selected_season = header.cleaned_data["season"]
        selected_competition_level = header.cleaned_data["competition_level"]
    elif season_pk:
        selected_season = initial["season"]

    lines = HistoricalResultFormSet(
        request.POST or None,
        prefix="results",
        form_kwargs={
            "season": selected_season,
            "rider": rider,
            "competition_level": selected_competition_level,
        },
    )

    if request.method == "POST" and header_valid and lines.is_valid():
        valid_rows = [
            form.cleaned_data for form in lines
            if form.cleaned_data and not form.cleaned_data.get("DELETE")
        ]
        if not valid_rows:
            lines.non_form_errors = lambda: ["Enter at least one historical result."]
        else:
            season = header.cleaned_data["season"]
            membership = get_object_or_404(SeasonMembership, season=season, rider=rider)

            # This workflow intentionally permits archived/closed seasons.
            # Regular-season imports use the regular track; finals imports use the
            # same separate Individual/Team tracks as live Region/Zone/National shows.
            competition_level = header.cleaned_data["competition_level"]
            with transaction.atomic():
                show, created = Show.objects.get_or_create(
                    team=team,
                    season=season,
                    name=header.cleaned_data["show_name"].strip(),
                    show_date=header.cleaned_data["show_date"],
                    competition_level=competition_level,
                    is_historical_import=True,
                    defaults={
                        "venue": header.cleaned_data.get("venue", ""),
                        "status": Show.Status.COMPLETE,
                        "futures_team_place": header.cleaned_data.get("futures_team_place"),
                        "upper_team_place": header.cleaned_data.get("upper_team_place"),
                        "notes": header.cleaned_data.get("notes", ""),
                    },
                )
                if not created:
                    changed = []
                    venue = header.cleaned_data.get("venue", "")
                    notes = header.cleaned_data.get("notes", "")
                    if venue and not show.venue:
                        show.venue = venue; changed.append("venue")
                    if notes and not show.notes:
                        show.notes = notes; changed.append("notes")
                    if show.status != Show.Status.COMPLETE:
                        show.status = Show.Status.COMPLETE; changed.append("status")
                    futures_place = header.cleaned_data.get("futures_team_place")
                    upper_place = header.cleaned_data.get("upper_team_place")
                    if futures_place is not None and show.futures_team_place != futures_place:
                        show.futures_team_place = futures_place; changed.append("futures_team_place")
                    if upper_place is not None and show.upper_team_place != upper_place:
                        show.upper_team_place = upper_place; changed.append("upper_team_place")
                    if changed:
                        show.save(update_fields=changed)

                saved = 0
                for row in valid_rows:
                    season_class = row["season_class"]
                    if not membership.classes.filter(pk=season_class.pk).exists():
                        raise PermissionDenied

                    show_class, _ = ShowClass.objects.get_or_create(
                        show=show,
                        season_class=season_class,
                        defaults={
                            "name": season_class.name,
                            "discipline": season_class.discipline,
                            "sort_order": season_class.sort_order,
                        },
                    )
                    competition_track = (
                        ShowEntry.CompetitionTrack.REGULAR
                        if competition_level == Show.CompetitionLevel.REGULAR
                        else row["competition_track"]
                    )
                    entry_type = (
                        ShowEntry.EntryType.INDIVIDUAL
                        if competition_track != ShowEntry.CompetitionTrack.TEAM
                        else ShowEntry.EntryType.TEAM
                    )
                    entry, _ = ShowEntry.objects.get_or_create(
                        show_class=show_class,
                        rider=rider,
                        competition_track=competition_track,
                        defaults={
                            "entry_type": entry_type,
                            "is_point_rider": False,
                            "status": ShowEntry.Status.ENTERED,
                            "notes": "Historical result",
                        },
                    )
                    entry.entry_type = entry_type
                    entry.is_point_rider = False
                    entry.status = ShowEntry.Status.ENTERED
                    entry.save(update_fields=["entry_type", "is_point_rider", "status"])

                    points = row.get("points")
                    place = row.get("place")
                    result, _ = ShowResult.objects.get_or_create(entry=entry)
                    result.place = place
                    result.horse_name = row.get("horse_name", "")
                    result.notes = row.get("notes", "")
                    if points is not None:
                        result.points = points
                        result.manual_points = True
                    else:
                        # Let the season scoring configuration calculate points
                        # from placing when explicit historical points were omitted.
                        result.manual_points = False
                    result.save()
                    saved += 1

            messages.success(
                request,
                f"{saved} historical result{'s' if saved != 1 else ''} saved for "
                f"{rider.display_name} · {season.name}."
            )
            return redirect("rider_history", pk=rider.pk)

    return render(request, "portal/historical_results_form.html", {
        "rider": rider,
        "header": header,
        "lines": lines,
        "selected_season": selected_season,
        "selected_competition_level": selected_competition_level,
    })


@login_required
def rider_summary_print(request, pk, season_pk):
    team = _team(request.user); rider = get_object_or_404(Rider, pk=pk, team=team)
    if not _can_view_private_rider(request.user, rider):
        raise PermissionDenied
    season = get_object_or_404(Season, pk=season_pk, team=team)
    summary = _season_rider_summary(season, [rider])[0]
    qualifications = [r for r in _qualification_rows(season) if r["rider"].pk == rider.pk]
    awards = RiderAward.objects.filter(season=season, rider=rider, published=True)
    notes = RiderDevelopmentNote.objects.filter(season=season, rider=rider, family_visible=True).select_related("author")
    postseason_results = ShowResult.objects.filter(
        entry__rider=rider,
        entry__show_class__show__season=season,
        entry__show_class__show__competition_level__in=[
            Show.CompetitionLevel.REGIONAL,
            Show.CompetitionLevel.ZONE,
            Show.CompetitionLevel.NATIONAL,
        ],
    ).select_related(
        "entry__show_class__show", "entry__show_class__season_class"
    ).order_by("entry__show_class__show__show_date", "entry__show_class__sort_order")
    return render(request, "portal/rider_summary_print.html", {
        "rider": rider, "season": season, "summary": summary,
        "qualifications": qualifications, "awards": awards, "notes": notes,
        "postseason_results": postseason_results,
    })


@login_required
def development_note_add(request, pk, season_pk):
    _require_manage(request.user); team = _team(request.user)
    rider = get_object_or_404(Rider, pk=pk, team=team); season = get_object_or_404(Season, pk=season_pk, team=team)
    form = RiderDevelopmentNoteForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.rider = rider; obj.season = season; obj.author = request.user; obj.save()
        messages.success(request, "Development note added."); return redirect("rider_history", pk=rider.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Development note · {rider.display_name}", "eyebrow": season.name})


@login_required
def award_list(request, season_pk):
    team = _team(request.user); season = get_object_or_404(Season, pk=season_pk, team=team)
    awards = RiderAward.objects.filter(season=season).select_related("rider")
    if not _can_manage(request.user):
        awards = awards.filter(published=True, rider__in=_visible_riders(request.user, team))
    return render(request, "portal/award_list.html", {"season": season, "awards": awards, "can_manage": _can_manage(request.user)})


@login_required
@friendly_integrity_errors
def award_add(request, season_pk):
    _require_manage(request.user); team = _team(request.user); season = get_object_or_404(Season, pk=season_pk, team=team)
    form = RiderAwardForm(request.POST or None, season=season)
    if form.is_valid():
        obj = form.save(commit=False); obj.season = season; obj.created_by = request.user; obj.save()
        messages.success(request, "Award added."); return redirect("award_list", season_pk=season.pk)
    return render(request, "portal/form.html", {"form": form, "title": "Add award or recognition", "eyebrow": season.name})


@login_required
def team_record_book(request):
    team = _team(request.user)
    records = []
    for season in Season.objects.filter(team=team).order_by("-start_date"):
        for rider in Rider.objects.filter(memberships__season=season).distinct():
            for class_row in _rider_class_point_rows(season, rider):
                if class_row["points"] or class_row["wins"]:
                    records.append({
                        "season": season,
                        "rider": rider,
                        "season_class": class_row["season_class"],
                        "points": class_row["points"],
                        "wins": class_row["wins"],
                    })
    records.sort(key=lambda x: (x["points"], x["wins"]), reverse=True)
    awards = RiderAward.objects.filter(season__team=team, published=True).select_related("season", "rider")[:50]
    postseason_entries = ShowEntry.objects.filter(
        show_class__show__team=team,
        competition_track=ShowEntry.CompetitionTrack.INDIVIDUAL,
        result__isnull=False,
    )
    finals_counts = {
        "regional": postseason_entries.filter(
            show_class__show__competition_level=Show.CompetitionLevel.REGIONAL
        ).values("rider_id").distinct().count(),
        "zone": postseason_entries.filter(
            show_class__show__competition_level=Show.CompetitionLevel.ZONE
        ).values("rider_id").distinct().count(),
        "national": postseason_entries.filter(
            show_class__show__competition_level=Show.CompetitionLevel.NATIONAL
        ).values("rider_id").distinct().count(),
    }
    return render(request, "portal/team_record_book.html", {
        "records": records[:25],
        "awards": awards,
        "finals_counts": finals_counts,
    })



@login_required
def rider_guardian_link(request, rider_pk):
    _require_manage(request.user)
    team = _team(request.user)
    rider = get_object_or_404(Rider, pk=rider_pk, team=team)

    existing_ids = RiderGuardian.objects.filter(rider=rider).values_list("guardian_id", flat=True)
    guardians = GuardianContact.objects.filter(team=team).exclude(pk__in=existing_ids).order_by("last_name", "first_name")

    if request.method == "POST":
        guardian_id = request.POST.get("guardian")
        relationship = (request.POST.get("relationship") or "Parent/Guardian").strip()
        primary_contact = request.POST.get("primary_contact") == "on"
        guardian = get_object_or_404(GuardianContact, pk=guardian_id, team=team)

        link, created = RiderGuardian.objects.get_or_create(
            rider=rider,
            guardian=guardian,
            defaults={
                "relationship": relationship,
                "primary_contact": primary_contact,
            },
        )
        if not created:
            messages.info(request, f"{guardian} is already linked to {rider}.")
        else:
            if guardian.user_id:
                rider.guardians.add(guardian.user)
            messages.success(request, f"{guardian} linked to {rider}.")
        return redirect("rider_detail", pk=rider.pk)

    return render(request, "portal/rider_guardian_link.html", {
        "rider": rider,
        "guardians": guardians,
    })


@login_required
@require_POST
def rider_guardian_unlink(request, rider_pk, link_pk):
    _require_manage(request.user)
    team = _team(request.user)
    rider = get_object_or_404(Rider, pk=rider_pk, team=team)
    link = get_object_or_404(RiderGuardian.objects.select_related("guardian"), pk=link_pk, rider=rider)

    guardian = link.guardian
    link.delete()

    if guardian.user_id:
        # Keep the legacy M2M only if this same user remains linked to the rider
        still_linked = RiderGuardian.objects.filter(rider=rider, guardian__user_id=guardian.user_id).exists()
        if not still_linked:
            rider.guardians.remove(guardian.user)

    messages.success(request, f"{guardian} unlinked from {rider}.")
    return redirect("rider_detail", pk=rider.pk)


@login_required
def committee_list(request):
    team = _team(request.user)
    season = _active_season(team)
    assignments = CommitteeAssignment.objects.filter(team=team, season=season).select_related("user") if season else []
    return render(request, "portal/committee_list.html", {
        "season": season, "assignments": assignments, "can_manage": _can_manage(request.user)
    })


@login_required
@friendly_integrity_errors
def committee_assignment_create(request):
    _require_manage(request.user)
    team = _team(request.user); season = _active_season(team)
    if not season:
        messages.error(request, "Create or activate a season before assigning committee chairs.")
        return redirect("committee_list")
    form = CommitteeAssignmentForm(request.POST or None, team=team, season=season)
    if form.is_valid():
        obj = form.save(commit=False); obj.team = team; obj.season = season; obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj, season=season,
            summary=f"Created committee assignment: {obj}",
            details={"role": obj.role, "user": obj.user, "active": obj.active},
        )
        messages.success(request, "Committee assignment saved.")
        return redirect("committee_list")
    return render(request, "portal/form.html", {"form": form, "title": "Assign committee chair", "eyebrow": "COMMITTEES"})


@login_required
def committee_assignment_edit(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    obj = get_object_or_404(CommitteeAssignment, pk=pk, team=team)
    form = CommitteeAssignmentForm(request.POST or None, instance=obj, team=team)
    if form.is_valid():
        obj = form.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj, season=obj.season,
            summary=f"Updated committee assignment: {obj}",
            details={"role": obj.role, "user": obj.user, "active": obj.active},
        )
        messages.success(request, "Committee assignment updated.")
        return redirect("committee_list")
    return render(request, "portal/form.html", {"form": form, "title": "Edit committee assignment", "eyebrow": "COMMITTEES"})


@login_required
def show_planning(request, pk):
    team = _team(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    can_plan = _can_plan_show(request.user, show)
    allowed_levels = _show_planning_allowed_levels(request.user, show)
    leads = show.lead_assignments.filter(active=True).select_related("user")
    all_items = list(show.planning_items.select_related("assigned_to", "claimed_by"))
    items = [item for item in all_items if _planning_item_visible_to_user(request.user, item)]
    for item in items:
        item.can_manage_item = _can_manage_planning_item(request.user, item)
        item.is_my_item = item.claimed_by_id == request.user.id or item.assigned_to_id == request.user.id
    return render(request, "portal/show_planning.html", {
        "show": show,
        "leads": leads,
        "items": items,
        "can_plan": can_plan,
        "allowed_levels": allowed_levels,
        "can_manage": _can_manage(request.user),
        "open_volunteer_count": sum(
            1 for item in items
            if item.item_type == ShowPlanningItem.ItemType.VOLUNTEER and not item.owner and not item.completed
        ),
        "incomplete_checklist_count": sum(
            1 for item in items
            if item.item_type == ShowPlanningItem.ItemType.CHECKLIST and not item.completed
        ),
    })


@login_required
@require_POST
def show_planning_seed_defaults(request, pk):
    team = _team(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    if not (_can_manage(request.user) or _is_show_lead(request.user, show)):
        raise PermissionDenied
    _ensure_season_open(show.season)

    attending_defaults = [
        (ShowPlanningItem.ItemType.CHECKLIST, ShowPlanningItem.Category.TASK, "Confirm coach packet / paperwork", False),
        (ShowPlanningItem.ItemType.CHECKLIST, ShowPlanningItem.Category.TASK, "Confirm rider arrival plan", False),
        (ShowPlanningItem.ItemType.SUPPLY, ShowPlanningItem.Category.SUPPLY, "Team banner / signage", True),
        (ShowPlanningItem.ItemType.SUPPLY, ShowPlanningItem.Category.DRINK, "Team water / drinks", True),
        (ShowPlanningItem.ItemType.SUPPLY, ShowPlanningItem.Category.LUNCH, "Team lunch / food plan", True),
    ]
    hosting_defaults = attending_defaults + [
        (ShowPlanningItem.ItemType.CHECKLIST, ShowPlanningItem.Category.TASK, "Facility / ring setup complete", False),
        (ShowPlanningItem.ItemType.CHECKLIST, ShowPlanningItem.Category.TASK, "Officials / steward arrival confirmed", False),
        (ShowPlanningItem.ItemType.VOLUNTEER, ShowPlanningItem.Category.TASK, "Parking support", True),
        (ShowPlanningItem.ItemType.VOLUNTEER, ShowPlanningItem.Category.TASK, "Ring crew", True),
        (ShowPlanningItem.ItemType.VOLUNTEER, ShowPlanningItem.Category.TASK, "Hospitality support", True),
        (ShowPlanningItem.ItemType.VOLUNTEER, ShowPlanningItem.Category.TASK, "Awards support", True),
        (ShowPlanningItem.ItemType.VOLUNTEER, ShowPlanningItem.Category.TASK, "Cleanup crew", True),
        (ShowPlanningItem.ItemType.SUPPLY, ShowPlanningItem.Category.SUPPLY, "Awards / ribbons staged", False),
    ]

    defaults = (
        hosting_defaults
        if show.financial_role == Show.FinancialRole.HOSTING_ATTENDING
        else attending_defaults
    )
    existing_titles = set(show.planning_items.values_list("title", flat=True))
    created = 0
    for order, (item_type, category, title, family_visible) in enumerate(defaults, start=10):
        if title in existing_titles:
            continue
        ShowPlanningItem.objects.create(
            show=show,
            item_type=item_type,
            team_level=ShowPlanningItem.TeamLevel.ALL,
            category=category,
            title=title,
            family_visible=family_visible,
            sort_order=order * 10,
        )
        created += 1

    _audit_event(
        team=team, actor=request.user, action=AuditEvent.Action.GENERATED,
        obj=show, season=show.season,
        summary=f"Generated starter show-day plan for {show.name}",
        details={"items_created": created, "mode": show.financial_role},
    )
    if created:
        messages.success(request, f"Added {created} starter show-day item{'s' if created != 1 else ''}.")
    else:
        messages.info(request, "The starter show-day items are already present.")
    return redirect("show_planning", pk=show.pk)


@login_required
@friendly_integrity_errors
def show_lead_add(request, pk):
    _require_manage(request.user)
    team = _team(request.user); show = get_object_or_404(Show, pk=pk, team=team)
    form = ShowLeadAssignmentForm(request.POST or None, team=team, show=show)
    if form.is_valid():
        obj = form.save(commit=False); obj.show = show; obj.save()
        messages.success(request, "Show lead assigned."); return redirect("show_planning", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Assign show lead · {show.name}", "eyebrow": "SHOW PLANNING"})


@login_required
def show_planning_item_add(request, pk):
    team = _team(request.user); show = get_object_or_404(Show, pk=pk, team=team)
    allowed_levels = _show_planning_allowed_levels(request.user, show)
    if not allowed_levels:
        raise PermissionDenied
    form = ShowPlanningItemForm(request.POST or None, team=team, allowed_team_levels=allowed_levels)
    if form.is_valid():
        obj = form.save(commit=False); obj.show = show
        if obj.team_level not in allowed_levels:
            raise PermissionDenied
        obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.CREATED,
            obj=obj, season=show.season,
            summary=f"Added show-day {obj.get_item_type_display().lower()}: {obj.title}",
            details={"show": show, "team_level": obj.team_level},
        )
        messages.success(request, "Show planning item added."); return redirect("show_planning", pk=show.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Add show planning item · {show.name}", "eyebrow": "SHOW PLANNING"})


@login_required
def show_planning_item_edit(request, item_pk):
    team = _team(request.user); item = get_object_or_404(ShowPlanningItem.objects.select_related("show__season"), pk=item_pk, show__team=team)
    allowed_levels = _show_planning_allowed_levels(request.user, item.show)
    if not _can_manage_planning_item(request.user, item):
        raise PermissionDenied
    form = ShowPlanningItemForm(
        request.POST or None, instance=item, team=team, allowed_team_levels=allowed_levels
    )
    if form.is_valid():
        obj = form.save(commit=False)
        if obj.team_level not in allowed_levels:
            raise PermissionDenied
        obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED,
            obj=obj, season=item.show.season,
            summary=f"Updated show-day {obj.get_item_type_display().lower()}: {obj.title}",
            details={"show": item.show, "team_level": obj.team_level},
        )
        messages.success(request, "Show planning item updated."); return redirect("show_planning", pk=item.show_id)
    return render(request, "portal/form.html", {"form": form, "title": "Edit show planning item", "eyebrow": "SHOW PLANNING"})


@login_required
@require_POST
def show_planning_item_claim(request, item_pk):
    team = _team(request.user)
    item = get_object_or_404(
        ShowPlanningItem.objects.select_related("show__season"),
        pk=item_pk, show__team=team, family_visible=True
    )
    if not _planning_item_visible_to_user(request.user, item):
        raise PermissionDenied
    can_manage_item = _can_manage_planning_item(request.user, item)
    if item.claimed_by_id and item.claimed_by_id != request.user.id and not can_manage_item:
        raise PermissionDenied
    if request.POST.get("clear") and (item.claimed_by_id == request.user.id or can_manage_item):
        item.claimed_by = None
    elif not item.claimed_by_id:
        item.claimed_by = request.user
    item.save(update_fields=["claimed_by"])
    return redirect("show_planning", pk=item.show_id)


@login_required
@require_POST
def show_planning_item_complete(request, item_pk):
    team = _team(request.user)
    item = get_object_or_404(
        ShowPlanningItem.objects.select_related("show__season"),
        pk=item_pk, show__team=team
    )
    can_manage_item = _can_manage_planning_item(request.user, item)
    is_owner = item.claimed_by_id == request.user.id or item.assigned_to_id == request.user.id
    if not can_manage_item and not is_owner:
        raise PermissionDenied
    item.completed = not item.completed
    item.save(update_fields=["completed"])
    _audit_event(
        team=team, actor=request.user, action=AuditEvent.Action.UPDATED,
        obj=item, season=item.show.season,
        summary=f"{'Completed' if item.completed else 'Reopened'} show-day item: {item.title}",
        details={"show": item.show, "completed": item.completed},
    )
    return redirect("show_planning", pk=item.show_id)


@login_required
def notification_list(request):
    notifications = request.user.portal_notifications.select_related("announcement", "show_day_update").all()[:100]
    return render(request, "portal/notifications.html", {"notifications": notifications})


@login_required
@require_POST
def notification_read(request, pk):
    notification = get_object_or_404(Notification, pk=pk, user=request.user)
    if not notification.read_at:
        notification.read_at = timezone.now(); notification.save(update_fields=["read_at"])
    return redirect(notification.link or "notification_list")


@login_required
@require_POST
def notification_read_all(request):
    request.user.portal_notifications.filter(read_at__isnull=True).update(read_at=timezone.now())
    return redirect("notification_list")


@login_required
def notification_preferences(request):
    if not hasattr(request.user, "profile"):
        raise PermissionDenied
    form = NotificationPreferenceForm(request.POST or None, instance=request.user.profile)
    if form.is_valid():
        form.save(); messages.success(request, "Notification preferences updated."); return redirect("notification_list")
    return render(request, "portal/form.html", {"form": form, "title": "Notification preferences", "eyebrow": "COMMUNICATIONS"})


@login_required
def user_list(request):
    _require_manage(request.user)
    team = _team(request.user)
    users = User.objects.filter(profile__team=team).select_related("profile", "rider_record", "guardian_contact").order_by("last_name", "first_name", "username")
    if not _is_admin(request.user):
        users = users.filter(profile__role__in=[UserProfile.Role.PARENT, UserProfile.Role.RIDER])
    return render(request, "portal/user_list.html", {"users": users, "is_admin_actor": _is_admin(request.user)})


@login_required
def user_create(request, rider_pk=None, guardian_pk=None):
    _require_manage(request.user)
    team = _team(request.user)
    rider = get_object_or_404(Rider, pk=rider_pk, team=team, user__isnull=True) if rider_pk else None
    guardian = get_object_or_404(GuardianContact, pk=guardian_pk, team=team, user__isnull=True) if guardian_pk else None
    form = UserOnboardingForm(request.POST or None, team=team, actor=request.user, initial_rider=rider, initial_guardian=guardian)
    if form.is_valid():
        try:
            user = form.save()
        except ValidationError as exc:
            form.add_error(None, exc)
        except IntegrityError as exc:
            # A double-click or browser retry can submit onboarding twice before
            # the first transaction becomes visible to the second request.
            # After the failed transaction rolls back, reconcile against the
            # account that may just have been created by the first request.
            username = form.cleaned_data.get("username", "").strip()
            existing = User.objects.filter(username__iexact=username).first()
            selected_rider = form.cleaned_data.get("rider")
            selected_guardian = form.cleaned_data.get("guardian")
            completed_by_first_request = False

            if existing:
                rider_ok = True
                guardian_ok = True
                if selected_rider:
                    selected_rider.refresh_from_db(fields=["user"])
                    rider_ok = selected_rider.user_id == existing.id
                if selected_guardian:
                    selected_guardian.refresh_from_db(fields=["user"])
                    guardian_ok = selected_guardian.user_id == existing.id
                completed_by_first_request = rider_ok and guardian_ok

            if completed_by_first_request:
                messages.success(
                    request,
                    f"Login created for {existing.get_full_name() or existing.username}. "
                    "They must change the temporary password at first login."
                )
                return redirect("user_list")

            cause = getattr(exc, "__cause__", None)
            diag = getattr(cause, "diag", None)
            constraint = getattr(diag, "constraint_name", None)
            friendly = {
                "auth_user_username_key": "That username is already in use. Choose a different username.",
                "auth_user_pkey": "The database user ID sequence is out of sync. Upgrade to the latest portal release to repair the sequence, then try again.",
                "portal_userprofile_pkey": "The user-profile ID sequence is out of sync. Upgrade to the latest portal release to repair the sequence, then try again.",
                "portal_userprofile_user_id_key": "A profile already exists for this login.",
                "portal_rider_user_id_key": "That login is already attached to another rider.",
                "portal_guardiancontact_user_id_key": "That login is already attached to another parent/guardian.",
            }
            message = friendly.get(
                constraint,
                "That login could not be created because of a database constraint conflict."
            )
            if constraint and constraint not in friendly:
                message += f" Constraint: {constraint}."
            form.add_error(None, message)
        else:
            messages.success(request, f"Login created for {user.get_full_name() or user.username}. They must change the temporary password at first login.")
            return redirect("user_list")
    return render(request, "portal/user_form.html", {"form": form, "title": "Add user", "eyebrow": "USER ONBOARDING", "default_password_configured": bool(settings.DEFAULT_TEMP_PASSWORD)})


@login_required
def user_edit(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    target = get_object_or_404(User.objects.select_related("profile"), pk=pk, profile__team=team)
    if not _can_manage_user(request.user, target):
        raise PermissionDenied
    form = UserAccountEditForm(request.POST or None, team=team, actor=request.user, user_obj=target)
    if form.is_valid():
        form.save()
        target.refresh_from_db()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED,
            season=_active_season(team), entity_type="User", entity_id=target.pk,
            entity_label=target.get_full_name() or target.username,
            summary=f"Updated user account: {target.get_full_name() or target.username}",
            details={"role": getattr(target.profile, "role", ""), "active": target.is_active},
        )
        messages.success(request, "User account and links updated.")
        return redirect("user_list")
    return render(request, "portal/user_form.html", {"form": form, "title": f"Manage {target.get_full_name() or target.username}", "eyebrow": "USERS", "target_user": target})


@login_required
def user_reset_password(request, pk):
    _require_manage(request.user)
    team = _team(request.user)
    target = get_object_or_404(User.objects.select_related("profile"), pk=pk, profile__team=team)
    if not _can_manage_user(request.user, target):
        raise PermissionDenied
    if target == request.user:
        messages.error(request, "Use Change password for your own account."); return redirect("user_list")
    form = TemporaryPasswordResetForm(request.POST or None, user_obj=target)
    if request.method == "POST" and form.is_valid():
        target.set_password(form.cleaned_data["resolved_password"]); target.save(update_fields=["password"])
        target.profile.must_change_password = True; target.profile.save(update_fields=["must_change_password"])
        messages.success(request, f"Temporary password reset for {target.get_full_name() or target.username}. A password change will be required at next login.")
        return redirect("user_list")
    return render(request, "portal/user_form.html", {"form": form, "title": "Reset temporary password", "eyebrow": target.username, "default_password_configured": bool(settings.DEFAULT_TEMP_PASSWORD)})


@login_required
def password_change_required(request):
    form = PasswordChangeForm(request.user, request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save(); update_session_auth_hash(request, user)
        if hasattr(user, "profile"):
            user.profile.must_change_password = False; user.profile.save(update_fields=["must_change_password"])
        messages.success(request, "Password changed. Your account is ready to use.")
        return redirect("dashboard")
    return render(request, "registration/password_change_required.html", {"form": form})

# --- Finance ---------------------------------------------------------------

def _finance_account_rows(team):
    rows = []
    for account in FinancialAccount.objects.filter(team=team):
        posted = account.transactions.filter(status=FinancialTransaction.Status.POSTED)
        totals = posted.aggregate(
            income=Sum("amount", filter=Q(kind=FinancialTransaction.Kind.INCOME)),
            expense=Sum("amount", filter=Q(kind=FinancialTransaction.Kind.EXPENSE)),
        )
        income = totals["income"] or Decimal("0")
        expense = totals["expense"] or Decimal("0")
        rows.append({
            "account": account,
            "income": income,
            "expense": expense,
            "balance": account.opening_balance + income - expense,
        })
    return rows




FINANCE_AUDIT_ENTITY_TYPES = {
    "FinancialTransaction", "ShowTransactionAllocation", "ReimbursementRequest",
    "FamilyPayment", "FamilyCharge", "FamilyCredit", "ShowBudgetLine",
    "SeasonBudget", "FinancialAccount", "FinancialCategory",
    "FinancialAssistanceAward", "AssistanceClaim", "ServiceAgreementCredit",
    "FundraisingCampaign", "FundraisingContribution", "FundraisingPolicy",
}


@login_required
def audit_log(request):
    _require_manage(request.user)
    team = _team(request.user)
    qs = AuditEvent.objects.filter(team=team).select_related("actor", "season")
    if not _is_admin(request.user):
        qs = qs.exclude(entity_type__in=FINANCE_AUDIT_ENTITY_TYPES)

    selected_action = request.GET.get("action", "")
    selected_season = request.GET.get("season", "")
    selected_entity = request.GET.get("entity_type", "")
    entity_id = request.GET.get("entity_id", "")
    q = request.GET.get("q", "").strip()

    valid_actions = {x[0] for x in AuditEvent.Action.choices}
    if selected_action in valid_actions:
        qs = qs.filter(action=selected_action)
    else:
        selected_action = ""
    if selected_season.isdigit():
        qs = qs.filter(season_id=int(selected_season))
    else:
        selected_season = ""
    if selected_entity:
        qs = qs.filter(entity_type=selected_entity)
    if entity_id.isdigit():
        qs = qs.filter(entity_id=int(entity_id))
    else:
        entity_id = ""
    if q:
        qs = qs.filter(
            Q(entity_label__icontains=q)
            | Q(summary__icontains=q)
            | Q(actor__first_name__icontains=q)
            | Q(actor__last_name__icontains=q)
            | Q(actor__username__icontains=q)
        )

    paginator = Paginator(qs, 75)
    page = paginator.get_page(request.GET.get("page"))
    params = {
        "action": selected_action, "season": selected_season,
        "entity_type": selected_entity, "entity_id": entity_id, "q": q,
    }
    entity_type_qs = AuditEvent.objects.filter(team=team).exclude(entity_type="")
    if not _is_admin(request.user):
        entity_type_qs = entity_type_qs.exclude(entity_type__in=FINANCE_AUDIT_ENTITY_TYPES)
    entity_types = entity_type_qs.values_list("entity_type", flat=True).distinct().order_by("entity_type")
    return render(request, "portal/finance_audit_log.html", {
        "events": page.object_list,
        "page_obj": page,
        "actions": AuditEvent.Action.choices,
        "seasons": Season.objects.filter(team=team).order_by("-start_date"),
        "entity_types": entity_types,
        "selected_action": selected_action,
        "selected_season": selected_season,
        "selected_entity": selected_entity,
        "entity_id": entity_id,
        "q": q,
        "filter_query": urlencode({k: v for k, v in params.items() if v}),
        "audit_title": "Team audit log",
        "audit_eyebrow": "OPERATIONS & CONTROLS",
        "audit_intro": "Immutable activity history for important team, competition, user, and finance changes.",
        "audit_back_url": "dashboard",
    })

@login_required
def finance_audit_log(request):
    team = _team(request.user)
    season_ids = _finance_season_ids(request.user, team)
    if not season_ids:
        raise PermissionDenied

    finance_entity_types = FINANCE_AUDIT_ENTITY_TYPES
    qs = AuditEvent.objects.filter(team=team, season_id__in=season_ids).select_related("actor", "season")
    is_admin = request.user.is_superuser or (
        hasattr(request.user, "profile") and request.user.profile.role == UserProfile.Role.ADMIN
    )
    if not is_admin:
        qs = qs.filter(entity_type__in=finance_entity_types)

    selected_action = request.GET.get("action", "")
    selected_season = request.GET.get("season", "")
    selected_entity = request.GET.get("entity_type", "")
    entity_id = request.GET.get("entity_id", "")
    q = request.GET.get("q", "").strip()

    valid_actions = {x[0] for x in AuditEvent.Action.choices}
    if selected_action in valid_actions:
        qs = qs.filter(action=selected_action)
    else:
        selected_action = ""
    if selected_season.isdigit() and int(selected_season) in season_ids:
        qs = qs.filter(season_id=int(selected_season))
    else:
        selected_season = ""
    if selected_entity:
        qs = qs.filter(entity_type=selected_entity)
    if entity_id.isdigit():
        qs = qs.filter(entity_id=int(entity_id))
    else:
        entity_id = ""
    if q:
        qs = qs.filter(
            Q(entity_label__icontains=q)
            | Q(summary__icontains=q)
            | Q(actor__first_name__icontains=q)
            | Q(actor__last_name__icontains=q)
            | Q(actor__username__icontains=q)
        )

    paginator = Paginator(qs, 75)
    page = paginator.get_page(request.GET.get("page"))
    params = {
        "action": selected_action, "season": selected_season,
        "entity_type": selected_entity, "entity_id": entity_id, "q": q,
    }
    entity_type_qs = AuditEvent.objects.filter(team=team, season_id__in=season_ids).exclude(entity_type="")
    if not is_admin:
        entity_type_qs = entity_type_qs.filter(entity_type__in=finance_entity_types)
    entity_types = entity_type_qs.values_list("entity_type", flat=True).distinct().order_by("entity_type")
    return render(request, "portal/finance_audit_log.html", {
        "events": page.object_list,
        "page_obj": page,
        "actions": AuditEvent.Action.choices,
        "seasons": Season.objects.filter(team=team, pk__in=season_ids).order_by("-start_date"),
        "entity_types": entity_types,
        "selected_action": selected_action,
        "selected_season": selected_season,
        "selected_entity": selected_entity,
        "entity_id": entity_id,
        "q": q,
        "filter_query": urlencode({k: v for k, v in params.items() if v}),
        "audit_title": "Finance audit log",
        "audit_eyebrow": "AUDIT & CONTROLS",
        "audit_intro": "Immutable activity history for financial and reimbursement workflows.",
        "audit_back_url": "finance_dashboard",
    })

@login_required
def finance_dashboard(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)

    tx = FinancialTransaction.objects.filter(team=team, status=FinancialTransaction.Status.POSTED).select_related(
        "season", "account", "category", "show", "rider", "created_by", "updated_by"
    )
    season_tx = tx.filter(season=season) if season else tx.none()
    totals = season_tx.aggregate(
        income=Sum("amount", filter=Q(kind=FinancialTransaction.Kind.INCOME)),
        expense=Sum("amount", filter=Q(kind=FinancialTransaction.Kind.EXPENSE)),
    )
    income = totals["income"] or Decimal("0")
    expense = totals["expense"] or Decimal("0")
    budget_total = (
        SeasonBudget.objects.filter(season=season).aggregate(total=Sum("amount"))["total"] or Decimal("0")
        if season else Decimal("0")
    )
    receivable_balance = Decimal("0")
    active_award_remaining = Decimal("0")
    if season:
        for membership in SeasonMembership.objects.filter(season=season):
            receivable_balance += _family_account_totals(membership)["balance"]
        for award in FinancialAssistanceAward.objects.filter(membership__season=season, status=FinancialAssistanceAward.Status.ACTIVE):
            active_award_remaining += award.remaining_eligibility

    budget_rows = []
    if season:
        for budget in SeasonBudget.objects.filter(season=season).select_related("category"):
            actual = season_tx.filter(
                category=budget.category, kind=budget.kind
            ).aggregate(total=Sum("amount"))["total"] or Decimal("0")
            if budget.kind == FinancialTransaction.Kind.INCOME:
                variance = actual - budget.amount
            else:
                variance = budget.amount - actual
            budget_rows.append({"budget": budget, "actual": actual, "variance": variance})

    attention = {
        "overdue_families": 0,
        "overdue_balance": Decimal("0"),
        "draft_claims": 0,
        "outstanding_claims": 0,
        "missing_home_barn": 0,
        "missing_dues_rate": 0,
        "dues_not_generated": 0,
    }
    if season:
        report_rows, report_totals = _receivable_report_rows(season)
        attention["overdue_families"] = sum(1 for r in report_rows if r["overdue"] > 0)
        attention["overdue_balance"] = report_totals.get("overdue", Decimal("0"))
        _, assistance_totals = _assistance_report_rows(season)
        attention["draft_claims"] = assistance_totals.get("draft_claims", 0)
        attention["outstanding_claims"] = assistance_totals.get("outstanding_claims", 0)

        memberships = SeasonMembership.objects.filter(season=season).select_related("home_barn")
        attention["missing_home_barn"] = memberships.filter(home_barn__isnull=True).count()
        rate_barn_ids = set(MembershipDuesRate.objects.filter(season=season).values_list("home_barn_id", flat=True))
        attention["missing_dues_rate"] = sum(
            1 for m in memberships if m.home_barn_id and m.home_barn_id not in rate_barn_ids
        )
        attention["dues_not_generated"] = sum(
            1 for m in memberships
            if not m.family_charges.filter(charge_type=FamilyCharge.ChargeType.MEMBERSHIP_DUES).exists()
        )

    return render(request, "portal/finance_dashboard.html", {
        "season": season,
        "income": income,
        "expense": expense,
        "net": income - expense,
        "budget_total": budget_total,
        "receivable_balance": receivable_balance,
        "active_award_remaining": active_award_remaining,
        "budget_rows": budget_rows,
        "account_rows": _finance_account_rows(team),
        "recent_transactions": tx[:12],
        "attention": attention,
        "can_finance": True,
    })


@login_required
def finance_transaction_list(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)

    tx = FinancialTransaction.objects.filter(team=team).select_related(
        "season", "account", "category", "show", "rider",
        "created_by", "updated_by", "voided_by"
    )

    selected_status = request.GET.get("status", "posted")
    if selected_status == "void":
        tx = tx.filter(status=FinancialTransaction.Status.VOID)
    elif selected_status != "all":
        selected_status = "posted"
        tx = tx.filter(status=FinancialTransaction.Status.POSTED)

    selected_kind = request.GET.get("kind", "")
    if selected_kind in {FinancialTransaction.Kind.INCOME, FinancialTransaction.Kind.EXPENSE}:
        tx = tx.filter(kind=selected_kind)
    else:
        selected_kind = ""

    selected_season = request.GET.get("season", "")
    selected_account = request.GET.get("account", "")
    selected_category = request.GET.get("category", "")
    selected_show = request.GET.get("show", "")
    date_from = request.GET.get("date_from", "").strip()
    date_to = request.GET.get("date_to", "").strip()
    q = request.GET.get("q", "").strip()

    if selected_season.isdigit():
        tx = tx.filter(season_id=int(selected_season))
    else:
        selected_season = ""
    if selected_account.isdigit():
        tx = tx.filter(account_id=int(selected_account))
    else:
        selected_account = ""
    if selected_category.isdigit():
        tx = tx.filter(category_id=int(selected_category))
    else:
        selected_category = ""
    if selected_show.isdigit():
        tx = tx.filter(show_allocations__show_id=int(selected_show)).distinct()
    else:
        selected_show = ""
    if date_from:
        tx = tx.filter(transaction_date__gte=date_from)
    if date_to:
        tx = tx.filter(transaction_date__lte=date_to)
    if q:
        tx = tx.filter(
            Q(description__icontains=q)
            | Q(payee__icontains=q)
            | Q(reference__icontains=q)
            | Q(category__name__icontains=q)
            | Q(account__name__icontains=q)
            | Q(rider__first_name__icontains=q)
            | Q(rider__last_name__icontains=q)
            | Q(show_allocations__show__name__icontains=q)
        ).distinct()

    paginator = Paginator(tx, 50)
    page = paginator.get_page(request.GET.get("page"))
    filter_params = {
        "status": selected_status,
        "kind": selected_kind,
        "season": selected_season,
        "account": selected_account,
        "category": selected_category,
        "show": selected_show,
        "date_from": date_from,
        "date_to": date_to,
        "q": q,
    }
    filter_query = urlencode({k: v for k, v in filter_params.items() if v})

    return render(request, "portal/finance_transaction_list.html", {
        "transactions": page.object_list,
        "page_obj": page,
        "selected_kind": selected_kind,
        "selected_status": selected_status,
        "selected_season": selected_season,
        "selected_account": selected_account,
        "selected_category": selected_category,
        "selected_show": selected_show,
        "date_from": date_from,
        "date_to": date_to,
        "q": q,
        "filter_query": filter_query,
        "seasons": Season.objects.filter(team=team).order_by("-start_date"),
        "accounts": FinancialAccount.objects.filter(team=team).order_by("name"),
        "categories": FinancialCategory.objects.filter(team=team).order_by("sort_order", "name"),
        "shows": Show.objects.filter(team=team).order_by("-show_date", "name"),
    })


@login_required
@friendly_integrity_errors
def finance_transaction_create(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    form = FinancialTransactionForm(request.POST or None, request.FILES or None, team=team)
    if not request.method == "POST" and season:
        form.fields["season"].initial = season
        form.fields["transaction_date"].initial = timezone.localdate()
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.created_by = request.user
        obj.updated_by = request.user
        obj.full_clean()
        obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj,
            summary=f"Created financial transaction: {obj.description}",
            details={"amount": obj.amount, "kind": obj.kind, "account": obj.account, "category": obj.category},
        )
        messages.success(request, "Financial transaction saved.")
        return redirect("finance_transaction_list")
    return render(request, "portal/form.html", {
        "form": form, "title": "Add transaction", "eyebrow": "TEAM FINANCE"
    })


@login_required
@friendly_integrity_errors
def finance_transaction_edit(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(FinancialTransaction, pk=pk, team=team)
    _require_finance(request.user, obj.season)
    if obj.status == FinancialTransaction.Status.VOID:
        messages.info(request, "Voided transactions are retained for audit history and cannot be edited.")
        return redirect("finance_transaction_list")
    if hasattr(obj, "fundraising_contribution"):
        contribution = obj.fundraising_contribution
        messages.info(
            request,
            "This ledger transaction is controlled by a fundraising contribution. Edit the contribution instead so the ledger and family credit remain synchronized.",
        )
        return redirect("fundraising_contribution_edit", pk=contribution.pk)
    before = {
        "amount": obj.amount, "description": obj.description, "payee": obj.payee,
        "account": obj.account, "category": obj.category, "transaction_date": obj.transaction_date,
    }
    form = FinancialTransactionForm(
        request.POST or None, request.FILES or None, instance=obj, team=team
    )
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.updated_by = request.user
        obj.full_clean()
        obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj,
            summary=f"Updated financial transaction: {obj.description}",
            details={
                "before_amount": before["amount"], "after_amount": obj.amount,
                "before_description": before["description"], "after_description": obj.description,
                "before_payee": before["payee"], "after_payee": obj.payee,
                "before_account": before["account"], "after_account": obj.account,
                "before_category": before["category"], "after_category": obj.category,
                "before_date": before["transaction_date"], "after_date": obj.transaction_date,
            },
        )
        messages.success(request, "Financial transaction updated.")
        return redirect("finance_transaction_list")
    return render(request, "portal/form.html", {
        "form": form, "title": "Edit transaction", "eyebrow": "TEAM FINANCE"
    })


@login_required
def finance_transaction_delete(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(FinancialTransaction, pk=pk, team=team)
    _require_finance(request.user, obj.season)
    if obj.status == FinancialTransaction.Status.VOID:
        messages.info(request, "This transaction is already void.")
        return redirect("finance_transaction_list")
    if hasattr(obj, "fundraising_contribution"):
        contribution = obj.fundraising_contribution
        messages.info(
            request,
            "This ledger transaction is controlled by a fundraising contribution. Void the contribution instead so its ledger income and any family credit are corrected together.",
        )
        return redirect("fundraising_contribution_void", pk=contribution.pk)
    if request.method == "POST":
        reason = (request.POST.get("reason") or "Voided by Treasurer").strip()
        create_reversal = request.POST.get("create_reversal") == "1"
        obj.status = FinancialTransaction.Status.VOID
        obj.voided_at = timezone.now()
        obj.voided_by = request.user
        obj.void_reason = reason
        obj.updated_by = request.user
        obj.save(update_fields=["status","voided_at","voided_by","void_reason","updated_by","updated_at"])
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.VOIDED, obj=obj,
            summary=f"Voided financial transaction: {obj.description}",
            details={"amount": obj.amount, "reason": reason, "create_reversal": create_reversal},
        )
        if create_reversal:
            reversal_kind = (
                FinancialTransaction.Kind.EXPENSE
                if obj.kind == FinancialTransaction.Kind.INCOME
                else FinancialTransaction.Kind.INCOME
            )
            reversal = FinancialTransaction(
                team=obj.team, season=obj.season, transaction_date=timezone.localdate(),
                kind=reversal_kind, account=obj.account, category=obj.category, amount=obj.amount,
                payee=obj.payee, description=f"Reversal of: {obj.description}", show=obj.show,
                show_finance_scope=obj.show_finance_scope, rider=obj.rider, reference=obj.reference,
                notes=f"Reversal of transaction #{obj.pk}. {reason}", created_by=request.user,
                updated_by=request.user, reversal_of=obj,
            )
            # A reversal may use the original category even if its directional category normally
            # disallows the opposite kind; preserve audit value without bypassing unrelated validation.
            reversal.save()
            _audit_event(
                team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=reversal,
                summary=f"Created reversal transaction for #{obj.pk}",
                details={"reversal_of": obj.pk, "amount": reversal.amount, "kind": reversal.kind},
            )
        messages.success(request, "Financial transaction voided; its history has been retained.")
        return redirect("finance_transaction_list")
    return render(request, "portal/finance_transaction_void.html", {
        "object": obj,
        "title": "Void transaction",
    })


@login_required
def finance_transaction_export(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)

    rows = FinancialTransaction.objects.filter(team=team).select_related(
        "season", "account", "category", "show", "rider", "created_by", "updated_by", "voided_by"
    ).order_by("transaction_date", "id")

    selected_status = request.GET.get("status", "posted")
    if selected_status == "void":
        rows = rows.filter(status=FinancialTransaction.Status.VOID)
    elif selected_status != "all":
        rows = rows.filter(status=FinancialTransaction.Status.POSTED)

    selected_kind = request.GET.get("kind", "")
    if selected_kind in {FinancialTransaction.Kind.INCOME, FinancialTransaction.Kind.EXPENSE}:
        rows = rows.filter(kind=selected_kind)

    selected_season = request.GET.get("season", "")
    selected_account = request.GET.get("account", "")
    selected_category = request.GET.get("category", "")
    selected_show = request.GET.get("show", "")
    date_from = request.GET.get("date_from", "").strip()
    date_to = request.GET.get("date_to", "").strip()
    q = request.GET.get("q", "").strip()

    if selected_season.isdigit():
        rows = rows.filter(season_id=int(selected_season))
    if selected_account.isdigit():
        rows = rows.filter(account_id=int(selected_account))
    if selected_category.isdigit():
        rows = rows.filter(category_id=int(selected_category))
    if selected_show.isdigit():
        rows = rows.filter(show_allocations__show_id=int(selected_show)).distinct()
    if date_from:
        rows = rows.filter(transaction_date__gte=date_from)
    if date_to:
        rows = rows.filter(transaction_date__lte=date_to)
    if q:
        rows = rows.filter(
            Q(description__icontains=q)
            | Q(payee__icontains=q)
            | Q(reference__icontains=q)
            | Q(category__name__icontains=q)
            | Q(account__name__icontains=q)
            | Q(rider__first_name__icontains=q)
            | Q(rider__last_name__icontains=q)
            | Q(show_allocations__show__name__icontains=q)
        ).distinct()

    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="team-finance-transactions.csv"'
    writer = csv.writer(response)
    writer.writerow([
        "Date", "Season", "Status", "Type", "Account", "Category", "Amount", "Payee",
        "Description", "Rider", "Reference", "Created by", "Updated by", "Updated at",
        "Voided at", "Voided by", "Void reason",
    ])
    for row in rows:
        writer.writerow([
            row.transaction_date,
            row.season.name,
            row.get_status_display(),
            row.get_kind_display(),
            row.account.name,
            row.category.name,
            row.amount,
            row.payee,
            row.description,
            row.rider or "",
            row.reference,
            row.created_by.get_full_name() or row.created_by.username if row.created_by else "",
            row.updated_by.get_full_name() or row.updated_by.username if row.updated_by else "",
            row.updated_at,
            row.voided_at or "",
            row.voided_by.get_full_name() or row.voided_by.username if row.voided_by else "",
            row.void_reason,
        ])
    return response


@login_required
def finance_accounts(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    return render(request, "portal/finance_accounts.html", {
        "account_rows": _finance_account_rows(team),
        "categories": FinancialCategory.objects.filter(team=team),
    })


@login_required
@friendly_integrity_errors
def finance_account_create(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    form = FinancialAccountForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj,
            season=season, summary=f"Created financial account: {obj.name}",
            details={"active": obj.active},
        )
        messages.success(request, "Financial account added.")
        return redirect("finance_accounts")
    return render(request, "portal/form.html", {
        "form": form, "title": "Add financial account", "eyebrow": "TEAM FINANCE"
    })


@login_required
@friendly_integrity_errors
def finance_account_edit(request, pk):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    obj = get_object_or_404(FinancialAccount, pk=pk, team=team)
    form = FinancialAccountForm(request.POST or None, instance=obj)
    if form.is_valid():
        obj = form.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj,
            season=season, summary=f"Updated financial account: {obj.name}",
            details={"active": obj.active},
        )
        messages.success(request, "Financial account updated.")
        return redirect("finance_accounts")
    return render(request, "portal/form.html", {
        "form": form, "title": f"Edit account · {obj.name}", "eyebrow": "TEAM FINANCE"
    })


@login_required
@friendly_integrity_errors
def finance_category_create(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    form = FinancialCategoryForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj,
            season=season, summary=f"Created financial category: {obj.name}",
            details={"kind": obj.kind, "active": obj.active},
        )
        messages.success(request, "Financial category added.")
        return redirect("finance_accounts")
    return render(request, "portal/form.html", {
        "form": form, "title": "Add financial category", "eyebrow": "TEAM FINANCE"
    })


@login_required
@friendly_integrity_errors
def finance_category_edit(request, pk):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    obj = get_object_or_404(FinancialCategory, pk=pk, team=team)
    form = FinancialCategoryForm(request.POST or None, instance=obj)
    if form.is_valid():
        obj = form.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj,
            season=season, summary=f"Updated financial category: {obj.name}",
            details={"kind": obj.kind, "active": obj.active},
        )
        messages.success(request, "Financial category updated.")
        return redirect("finance_accounts")
    return render(request, "portal/form.html", {
        "form": form, "title": f"Edit category · {obj.name}", "eyebrow": "TEAM FINANCE"
    })


@login_required
def finance_budget(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    if not season:
        messages.error(request, "Create or activate a season before setting a budget.")
        return redirect("finance_dashboard")
    rows = SeasonBudget.objects.filter(season=season).select_related("category")
    return render(request, "portal/finance_budget.html", {"season": season, "budgets": rows})


@login_required
@friendly_integrity_errors
def finance_budget_create(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    if not season:
        messages.error(request, "Create or activate a season before setting a budget.")
        return redirect("finance_dashboard")
    form = SeasonBudgetForm(request.POST or None, season=season, team=team)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.season = season
        obj.updated_by = request.user
        obj.full_clean()
        obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj,
            season=season, summary=f"Created season budget line: {obj.category.name}",
            details={"kind": obj.kind, "amount": obj.amount},
        )
        messages.success(request, "Budget line added.")
        return redirect("finance_budget")
    return render(request, "portal/form.html", {
        "form": form, "title": "Add budget line", "eyebrow": season.name
    })


@login_required
@friendly_integrity_errors
def finance_budget_edit(request, pk):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    obj = get_object_or_404(SeasonBudget.objects.select_related("season", "category"), pk=pk, season__team=team)
    form = SeasonBudgetForm(request.POST or None, instance=obj, season=obj.season, team=team)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.updated_by = request.user
        obj.full_clean()
        obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj,
            season=obj.season, summary=f"Updated season budget line: {obj.category.name}",
            details={"kind": obj.kind, "amount": obj.amount},
        )
        messages.success(request, "Budget line updated.")
        return redirect("finance_budget")
    return render(request, "portal/form.html", {
        "form": form, "title": f"Edit budget · {obj.category.name}", "eyebrow": obj.season.name
    })


@login_required
def finance_receipt_download(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(FinancialTransaction, pk=pk, team=team)
    _require_finance(request.user, obj.season)
    if not obj.receipt:
        raise Http404("No receipt is attached to this transaction.")
    try:
        handle = obj.receipt.open("rb")
    except FileNotFoundError:
        raise Http404("The receipt file could not be found.")
    filename = obj.receipt.name.rsplit("/", 1)[-1]
    return FileResponse(handle, as_attachment=False, filename=filename)

# --- v1.9.1 Membership dues / family receivables --------------------------

def _can_view_family_account(user, membership):
    if _is_rider_account(user):
        return False
    if _can_finance(user, membership.season):
        return True
    rider = membership.rider
    return (
        rider.guardians.filter(pk=user.pk).exists()
        or rider.guardian_links.filter(guardian__user=user).exists()
    )


def _require_adult_finance_participant(user):
    """Family-facing finance workflows are intentionally unavailable to Rider logins."""
    if _is_rider_account(user):
        raise PermissionDenied


def _family_account_totals(membership):
    charges = list(
        membership.family_charges.select_related("show", "source_dues_rate").prefetch_related(
            "credits", "service_credits", "assistance_claims", "payments"
        )
    )
    billed = sum((c.amount for c in charges if c.status != FamilyCharge.Status.WAIVED), Decimal("0"))
    generic_credits = sum((c.applied_credit_total for c in charges), Decimal("0"))
    service_credits = sum((c.service_credit_total for c in charges), Decimal("0"))
    assistance = sum((c.assistance_total for c in charges), Decimal("0"))
    payments = sum((c.payment_total for c in charges), Decimal("0"))
    balance = sum((c.balance for c in charges), Decimal("0"))
    return {
        "charges": charges,
        "billed": billed,
        "generic_credits": generic_credits,
        "service_credits": service_credits,
        "assistance": assistance,
        "payments": payments,
        "balance": balance,
    }


@login_required
def finance_receivables(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    rows = []
    total_billed = total_relief = total_paid = total_balance = Decimal("0")
    if season:
        memberships = SeasonMembership.objects.filter(season=season).select_related(
            "rider", "home_barn"
        ).order_by("rider__last_name", "rider__first_name")
        for membership in memberships:
            totals = _family_account_totals(membership)
            rows.append({"membership": membership, **totals})
            total_billed += totals["billed"]
            total_relief += totals["generic_credits"] + totals["service_credits"] + totals["assistance"]
            total_paid += totals["payments"]
            total_balance += totals["balance"]
    return render(request, "portal/finance_receivables.html", {
        "season": season,
        "rows": rows,
        "total_billed": total_billed,
        "total_relief": total_relief,
        "total_paid": total_paid,
        "total_balance": total_balance,
    })


@login_required
def finance_dues_setup(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    barns = HomeBarn.objects.filter(team=team).order_by("name")
    rates = MembershipDuesRate.objects.filter(season=season).select_related("home_barn") if season else MembershipDuesRate.objects.none()
    return render(request, "portal/finance_dues_setup.html", {
        "season": season, "barns": barns, "rates": rates,
    })


@login_required
@friendly_integrity_errors
def home_barn_create(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    form = HomeBarnForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.team = team; obj.save()
        messages.success(request, "Home barn added.")
        return redirect("finance_dues_setup")
    return render(request, "portal/form.html", {"form": form, "title": "Add home barn", "eyebrow": "MEMBERSHIP DUES"})


@login_required
@friendly_integrity_errors
def home_barn_edit(request, pk):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    obj = get_object_or_404(HomeBarn, pk=pk, team=team)
    form = HomeBarnForm(request.POST or None, instance=obj)
    if form.is_valid():
        form.save(); messages.success(request, "Home barn updated."); return redirect("finance_dues_setup")
    return render(request, "portal/form.html", {"form": form, "title": f"Edit barn · {obj.name}", "eyebrow": "MEMBERSHIP DUES"})


@login_required
@friendly_integrity_errors
def dues_rate_create(request):
    team = _team(request.user); season = _active_season(team)
    _require_finance(request.user, season)
    if not season:
        messages.error(request, "Create or activate a season before setting dues.")
        return redirect("finance_dues_setup")
    form = MembershipDuesRateForm(request.POST or None, team=team, season=season)
    if form.is_valid():
        obj = form.save(commit=False); obj.season = season; obj.full_clean(); obj.save()
        messages.success(request, "Membership dues rate added.")
        return redirect("finance_dues_setup")
    return render(request, "portal/form.html", {"form": form, "title": "Add membership dues rate", "eyebrow": season.name})


@login_required
@friendly_integrity_errors
def dues_rate_edit(request, pk):
    team = _team(request.user); season = _active_season(team)
    _require_finance(request.user, season)
    obj = get_object_or_404(MembershipDuesRate.objects.select_related("season", "home_barn"), pk=pk, season__team=team)
    form = MembershipDuesRateForm(request.POST or None, instance=obj, team=team, season=obj.season)
    if form.is_valid():
        obj = form.save(commit=False); obj.full_clean(); obj.save()
        messages.success(request, "Membership dues rate updated.")
        return redirect("finance_dues_setup")
    return render(request, "portal/form.html", {"form": form, "title": f"Edit dues · {obj.home_barn.name}", "eyebrow": obj.season.name})


@login_required
@require_POST
def membership_dues_generate(request, membership_pk):
    team = _team(request.user)
    membership = get_object_or_404(
        SeasonMembership.objects.select_related("season", "rider", "home_barn"),
        pk=membership_pk, season__team=team
    )
    _require_finance(request.user, membership.season)
    if not membership.home_barn:
        messages.error(request, f"Set {membership.rider.display_name}'s home barn before generating membership dues.")
        return redirect("family_account", membership_pk=membership.pk)
    rate = MembershipDuesRate.objects.filter(season=membership.season, home_barn=membership.home_barn).first()
    if not rate:
        messages.error(request, f"No dues rate is configured for {membership.home_barn.name}.")
        return redirect("family_account", membership_pk=membership.pk)
    existing = membership.family_charges.filter(charge_type=FamilyCharge.ChargeType.MEMBERSHIP_DUES).first()
    if existing:
        messages.info(request, "This rider already has a membership-dues charge. Edit the existing charge rather than creating a duplicate.")
    else:
        FamilyCharge.objects.create(
            membership=membership,
            charge_type=FamilyCharge.ChargeType.MEMBERSHIP_DUES,
            description=f"{membership.season.name} membership dues — {membership.home_barn.name}",
            amount=rate.amount,
            charge_date=membership.season.start_date,
            due_date=rate.due_date,
            source_dues_rate=rate,
            created_by=request.user,
        )
        messages.success(request, f"Membership dues charge created from the {membership.home_barn.name} season rate.")
    return redirect("family_account", membership_pk=membership.pk)


@login_required
def family_account(request, membership_pk):
    team = _team(request.user)
    membership = get_object_or_404(
        SeasonMembership.objects.select_related("rider", "season", "home_barn"),
        pk=membership_pk, season__team=team,
    )
    if not _can_view_family_account(request.user, membership):
        raise PermissionDenied
    totals = _family_account_totals(membership)
    awards = membership.assistance_awards.prefetch_related("claims").all()
    service_agreements = membership.service_agreements.prefetch_related("required_shows").select_related("charge")
    fundraising_qs = FundraisingContribution.objects.filter(
        campaign__season=membership.season,
        beneficiary_membership=membership,
        status=FundraisingContribution.Status.POSTED,
    )
    fundraising_totals = fundraising_qs.aggregate(
        raised=Sum("amount"), family_credit=Sum("family_credit_amount")
    )
    return render(request, "portal/family_account.html", {
        "membership": membership,
        "can_finance": _can_finance(request.user, membership.season),
        "awards": awards,
        "service_agreements": service_agreements,
        "fundraising_raised": fundraising_totals["raised"] or Decimal("0"),
        "fundraising_credit": fundraising_totals["family_credit"] or Decimal("0"),
        "fundraising_team": (
            (fundraising_totals["raised"] or Decimal("0"))
            - (fundraising_totals["family_credit"] or Decimal("0"))
        ),
        **totals,
    })


@login_required
def family_charge_create(request, membership_pk):
    team = _team(request.user)
    membership = get_object_or_404(SeasonMembership.objects.select_related("season", "rider"), pk=membership_pk, season__team=team)
    _require_finance(request.user, membership.season)
    form = FamilyChargeForm(request.POST or None, membership=membership)
    if form.is_valid():
        obj = form.save(commit=False); obj.membership = membership; obj.created_by = request.user; obj.full_clean(); obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj,
            season=membership.season,
            summary=f"Added family charge for {membership.rider.display_name}",
            details={"description": obj.description, "amount": obj.amount, "status": obj.status},
        )
        messages.success(request, "Family charge added.")
        return redirect("family_account", membership_pk=membership.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Add charge · {membership.rider.display_name}", "eyebrow": "FAMILY ACCOUNT"})


@login_required
def family_charge_edit(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(FamilyCharge.objects.select_related("membership__season", "membership__rider"), pk=pk, membership__season__team=team)
    _require_finance(request.user, obj.membership.season)
    form = FamilyChargeForm(request.POST or None, instance=obj, membership=obj.membership)
    if form.is_valid():
        obj = form.save(commit=False); obj.full_clean(); obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj,
            season=obj.membership.season,
            summary=f"Updated family charge: {obj.description}",
            details={"amount": obj.amount, "status": obj.status},
        )
        messages.success(request, "Charge updated.")
        return redirect("family_account", membership_pk=obj.membership_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Edit charge · {obj.description}", "eyebrow": "FAMILY ACCOUNT"})


@login_required
def family_credit_add(request, charge_pk):
    team = _team(request.user)
    charge = get_object_or_404(FamilyCharge.objects.select_related("membership__season", "membership__rider"), pk=charge_pk, membership__season__team=team)
    _require_finance(request.user, charge.membership.season)
    form = FamilyCreditForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.charge = charge; obj.created_by = request.user; obj.full_clean(); obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj,
            season=charge.membership.season,
            summary=f"Added family credit/adjustment to {charge.description}",
            details={"amount": obj.amount, "status": obj.status, "type": obj.credit_type},
        )
        messages.success(request, "Credit/adjustment added.")
        return redirect("family_account", membership_pk=charge.membership_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Add credit · {charge.description}", "eyebrow": charge.membership.rider.display_name})



@login_required
def family_credit_edit(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(
        FamilyCredit.objects.select_related("charge__membership__season", "charge__membership__rider"),
        pk=pk, charge__membership__season__team=team
    )
    _require_finance(request.user, obj.charge.membership.season)
    form = FamilyCreditForm(request.POST or None, instance=obj)
    if form.is_valid():
        obj = form.save(commit=False); obj.full_clean(); obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj,
            season=obj.charge.membership.season,
            summary=f"Updated family credit/adjustment for {obj.charge.description}",
            details={"amount": obj.amount, "status": obj.status, "type": obj.credit_type},
        )
        messages.success(request, "Credit/adjustment updated.")
        return redirect("family_account", membership_pk=obj.charge.membership_id)
    return render(request, "portal/form.html", {
        "form": form, "title": f"Edit credit · {obj.charge.description}", "eyebrow": obj.charge.membership.rider.display_name
    })


@login_required
def service_agreement_add(request, membership_pk):
    team = _team(request.user)
    membership = get_object_or_404(SeasonMembership.objects.select_related("season", "rider"), pk=membership_pk, season__team=team)
    _require_finance(request.user, membership.season)
    form = ServiceAgreementCreditForm(request.POST or None, membership=membership)
    if form.is_valid():
        obj = form.save(commit=False); obj.membership = membership; obj.created_by = request.user; obj.full_clean(); obj.save(); form.save_m2m()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj,
            season=membership.season, summary=f"Added service agreement for {membership.rider.display_name}",
            details={"amount": obj.amount, "status": obj.status},
        )
        messages.success(request, "Service agreement saved.")
        return redirect("family_account", membership_pk=membership.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Add service agreement · {membership.rider.display_name}", "eyebrow": "CONDITIONAL CREDIT"})


@login_required
def service_agreement_edit(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(ServiceAgreementCredit.objects.select_related("membership__season", "membership__rider"), pk=pk, membership__season__team=team)
    _require_finance(request.user, obj.membership.season)
    form = ServiceAgreementCreditForm(request.POST or None, instance=obj, membership=obj.membership)
    if form.is_valid():
        obj = form.save(commit=False); obj.full_clean(); obj.save(); form.save_m2m()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj,
            season=obj.membership.season, summary=f"Updated service agreement for {obj.membership.rider.display_name}",
            details={"amount": obj.amount, "status": obj.status},
        )
        messages.success(request, "Service agreement updated.")
        return redirect("family_account", membership_pk=obj.membership_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Edit service agreement · {obj.membership.rider.display_name}", "eyebrow": "CONDITIONAL CREDIT"})


@login_required
def assistance_award_add(request, membership_pk):
    team = _team(request.user)
    membership = get_object_or_404(SeasonMembership.objects.select_related("season", "rider"), pk=membership_pk, season__team=team)
    _require_finance(request.user, membership.season)
    form = FinancialAssistanceAwardForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.membership = membership; obj.created_by = request.user; obj.full_clean(); obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj,
            season=membership.season, summary=f"Added financial assistance award for {membership.rider.display_name}",
            details={"provider": obj.provider, "approved_maximum": obj.approved_maximum, "status": obj.status},
        )
        messages.success(request, "Financial assistance award added.")
        return redirect("family_account", membership_pk=membership.pk)
    return render(request, "portal/form.html", {"form": form, "title": f"Add assistance award · {membership.rider.display_name}", "eyebrow": "EXTERNAL ASSISTANCE"})


@login_required
def assistance_award_edit(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(FinancialAssistanceAward.objects.select_related("membership__season", "membership__rider"), pk=pk, membership__season__team=team)
    _require_finance(request.user, obj.membership.season)
    form = FinancialAssistanceAwardForm(request.POST or None, instance=obj)
    if form.is_valid():
        obj = form.save(commit=False); obj.full_clean(); obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj,
            season=obj.membership.season, summary=f"Updated financial assistance award for {obj.membership.rider.display_name}",
            details={"provider": obj.provider, "approved_maximum": obj.approved_maximum, "status": obj.status},
        )
        messages.success(request, "Financial assistance award updated.")
        return redirect("family_account", membership_pk=obj.membership_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Edit assistance award · {obj.provider}", "eyebrow": obj.membership.rider.display_name})


def _sync_assistance_transaction(claim, user):
    """Create/update real team income only after an outside award reimbursement is received."""
    if claim.status != AssistanceClaim.Status.REIMBURSED:
        if claim.financial_transaction_id:
            old_tx = claim.financial_transaction
            if old_tx.status != FinancialTransaction.Status.VOID:
                old_tx.status = FinancialTransaction.Status.VOID
                old_tx.voided_at = timezone.now()
                old_tx.voided_by = user
                old_tx.void_reason = f"Assistance claim #{claim.pk} is no longer reimbursed."
                old_tx.updated_by = user
                old_tx.save(update_fields=[
                    "status", "voided_at", "voided_by", "void_reason", "updated_by", "updated_at"
                ])
            claim.financial_transaction = None
            claim.save(update_fields=["financial_transaction"])
        return
    award = claim.award
    membership = award.membership
    tx = claim.financial_transaction or FinancialTransaction(
        team=membership.season.team,
        season=membership.season,
        created_by=user,
    )
    tx.transaction_date = claim.received_date
    tx.kind = FinancialTransaction.Kind.INCOME
    tx.account = claim.reimbursement_account
    tx.category = claim.reimbursement_category
    tx.amount = claim.reimbursed_amount
    tx.payee = award.provider
    tx.description = f"{award.program_name or award.provider} reimbursement — {membership.rider}"
    tx.rider = membership.rider
    tx.reference = claim.reference
    tx.notes = f"External assistance reimbursement linked to claim #{claim.pk}."
    tx.updated_by = user
    tx.full_clean()
    tx.save()
    if claim.financial_transaction_id != tx.pk:
        claim.financial_transaction = tx
        claim.save(update_fields=["financial_transaction"])


@login_required
def assistance_claim_add(request, award_pk):
    team = _team(request.user)
    award = get_object_or_404(FinancialAssistanceAward.objects.select_related("membership__season", "membership__rider"), pk=award_pk, membership__season__team=team)
    _require_finance(request.user, award.membership.season)
    form = AssistanceClaimForm(request.POST or None, award=award, team=team)
    if form.is_valid():
        with transaction.atomic():
            obj = form.save(commit=False); obj.award = award; obj.updated_by = request.user; obj.full_clean(); obj.save()
            _sync_assistance_transaction(obj, request.user)
            _audit_event(
                team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj,
                season=award.membership.season,
                summary=f"Added assistance claim for {award.membership.rider.display_name}",
                details={"status": obj.status, "requested": obj.amount_requested, "reimbursed": obj.reimbursed_amount},
            )
        messages.success(request, "Assistance claim saved.")
        return redirect("family_account", membership_pk=award.membership_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Add reimbursement claim · {award.provider}", "eyebrow": award.membership.rider.display_name})


@login_required
def assistance_claim_edit(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(AssistanceClaim.objects.select_related("award__membership__season", "award__membership__rider"), pk=pk, award__membership__season__team=team)
    _require_finance(request.user, obj.award.membership.season)
    form = AssistanceClaimForm(request.POST or None, instance=obj, award=obj.award, team=team)
    if form.is_valid():
        with transaction.atomic():
            obj = form.save(commit=False); obj.updated_by = request.user; obj.full_clean(); obj.save()
            _sync_assistance_transaction(obj, request.user)
            _audit_event(
                team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj,
                season=obj.award.membership.season,
                summary=f"Updated assistance claim for {obj.award.membership.rider.display_name}",
                details={"status": obj.status, "requested": obj.amount_requested, "reimbursed": obj.reimbursed_amount},
            )
        messages.success(request, "Assistance claim updated.")
        return redirect("family_account", membership_pk=obj.award.membership_id)
    return render(request, "portal/form.html", {"form": form, "title": f"Edit reimbursement claim · {obj.award.provider}", "eyebrow": obj.award.membership.rider.display_name})


def _sync_family_payment_transaction(payment, user):
    membership = payment.membership
    tx = payment.financial_transaction or FinancialTransaction(
        team=membership.season.team,
        season=membership.season,
        created_by=user,
    )
    tx.transaction_date = payment.received_date
    tx.kind = FinancialTransaction.Kind.INCOME
    tx.account = payment.account
    tx.category = payment.category
    tx.amount = payment.amount
    tx.payee = str(membership.rider)
    tx.description = f"Family payment — {payment.charge.description}"
    tx.rider = membership.rider
    tx.reference = payment.reference
    tx.notes = payment.notes
    tx.updated_by = user
    tx.full_clean()
    tx.save()
    if payment.financial_transaction_id != tx.pk:
        payment.financial_transaction = tx
        payment.save(update_fields=["financial_transaction"])


@login_required
def family_payment_add(request, membership_pk):
    team = _team(request.user)
    membership = get_object_or_404(
        SeasonMembership.objects.select_related("season", "rider"),
        pk=membership_pk, season__team=team
    )
    _require_finance(request.user, membership.season)
    form = FamilyPaymentForm(request.POST or None, membership=membership, team=team)
    if form.is_valid():
        with transaction.atomic():
            obj = form.save(commit=False)
            obj.membership = membership
            obj.created_by = request.user
            obj.full_clean()
            obj.save()
            _sync_family_payment_transaction(obj, request.user)
            _audit_event(
                team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj,
                season=membership.season,
                summary=f"Recorded family payment for {membership.rider.display_name}",
                details={"amount": obj.amount, "charge": obj.charge, "account": obj.account},
            )
        messages.success(request, "Payment recorded and posted to the team ledger.")
        return redirect("family_account", membership_pk=membership.pk)
    return render(request, "portal/form.html", {
        "form": form, "title": f"Record payment · {membership.rider.display_name}", "eyebrow": "FAMILY ACCOUNT"
    })


@login_required
def family_payment_edit(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(
        FamilyPayment.objects.select_related(
            "membership__season", "membership__rider", "charge", "financial_transaction"
        ),
        pk=pk, membership__season__team=team
    )
    _require_finance(request.user, obj.membership.season)
    if obj.status == FamilyPayment.Status.VOID:
        messages.info(request, "Voided family payments are retained for audit history and cannot be edited.")
        return redirect("family_account", membership_pk=obj.membership_id)
    form = FamilyPaymentForm(request.POST or None, instance=obj, membership=obj.membership, team=team)
    if form.is_valid():
        with transaction.atomic():
            obj = form.save(commit=False)
            obj.full_clean()
            obj.save()
            _sync_family_payment_transaction(obj, request.user)
            _audit_event(
                team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj,
                season=obj.membership.season,
                summary=f"Updated family payment for {obj.membership.rider.display_name}",
                details={"amount": obj.amount, "charge": obj.charge, "account": obj.account},
            )
        messages.success(request, "Payment and linked team-ledger transaction updated.")
        return redirect("family_account", membership_pk=obj.membership_id)
    return render(request, "portal/form.html", {
        "form": form, "title": f"Edit payment · {obj.membership.rider.display_name}", "eyebrow": "FAMILY ACCOUNT"
    })


@login_required
def family_payment_delete(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(
        FamilyPayment.objects.select_related(
            "membership__season", "membership__rider", "financial_transaction"
        ),
        pk=pk, membership__season__team=team
    )
    _require_finance(request.user, obj.membership.season)
    membership_id = obj.membership_id

    if obj.status == FamilyPayment.Status.VOID:
        messages.info(request, "This family payment is already void.")
        return redirect("family_account", membership_pk=membership_id)

    if request.method == "POST":
        reason = (request.POST.get("reason") or "Voided by Treasurer").strip()
        with transaction.atomic():
            obj.status = FamilyPayment.Status.VOID
            obj.voided_at = timezone.now()
            obj.voided_by = request.user
            obj.void_reason = reason
            obj.save(update_fields=["status", "voided_at", "voided_by", "void_reason"])

            tx = obj.financial_transaction
            if tx and tx.status != FinancialTransaction.Status.VOID:
                tx.status = FinancialTransaction.Status.VOID
                tx.voided_at = timezone.now()
                tx.voided_by = request.user
                tx.void_reason = f"Family payment void: {reason}"
                tx.updated_by = request.user
                tx.save(update_fields=[
                    "status", "voided_at", "voided_by", "void_reason", "updated_by", "updated_at"
                ])

            _audit_event(
                team=team, actor=request.user, action=AuditEvent.Action.VOIDED, obj=obj,
                season=obj.membership.season,
                summary=f"Voided family payment for {obj.membership.rider.display_name}",
                details={"amount": obj.amount, "reason": reason, "transaction": tx.pk if tx else ""},
            )

        messages.success(request, "Family payment voided; the payment and ledger history were retained.")
        return redirect("family_account", membership_pk=membership_id)

    return render(request, "portal/finance_family_payment_void.html", {
        "object": obj,
        "title": "Void family payment",
    })


@login_required
@require_POST
def membership_dues_generate_all(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    if not season:
        messages.error(request, "Create or activate a season before generating membership dues.")
        return redirect("finance_dues_setup")

    created = skipped_existing = missing_barn = missing_rate = 0
    rates = {
        r.home_barn_id: r
        for r in MembershipDuesRate.objects.filter(season=season).select_related("home_barn")
    }
    memberships = SeasonMembership.objects.filter(season=season).select_related("rider", "home_barn")
    with transaction.atomic():
        for membership in memberships:
            if membership.family_charges.filter(charge_type=FamilyCharge.ChargeType.MEMBERSHIP_DUES).exists():
                skipped_existing += 1
                continue
            if not membership.home_barn_id:
                missing_barn += 1
                continue
            rate = rates.get(membership.home_barn_id)
            if not rate:
                missing_rate += 1
                continue
            FamilyCharge.objects.create(
                membership=membership,
                charge_type=FamilyCharge.ChargeType.MEMBERSHIP_DUES,
                description=f"{season.name} membership dues — {membership.home_barn.name}",
                amount=rate.amount,
                charge_date=season.start_date,
                due_date=rate.due_date,
                source_dues_rate=rate,
                created_by=request.user,
            )
            created += 1

    messages.success(
        request,
        f"Membership dues generation complete: {created} created, {skipped_existing} existing skipped, "
        f"{missing_barn} missing home barn, {missing_rate} missing dues rate."
    )
    return redirect("finance_receivables")

# --- v1.9.6 Fundraising -----------------------------------------------------

def _sync_fundraising_contribution(contribution, user):
    """Post fundraiser cash once to the ledger and optionally credit a family receivable."""
    campaign = contribution.campaign

    tx = contribution.financial_transaction or FinancialTransaction(
        team=campaign.team,
        season=campaign.season,
        created_by=user,
    )
    tx.transaction_date = contribution.received_date
    tx.kind = FinancialTransaction.Kind.INCOME
    tx.account = contribution.account
    tx.category = contribution.category
    tx.amount = contribution.amount
    tx.payee = contribution.donor_name
    tx.description = f"Fundraiser · {campaign.name}"
    tx.rider = (
        contribution.beneficiary_membership.rider
        if contribution.beneficiary_membership_id else None
    )
    tx.reference = contribution.reference
    tx.notes = contribution.notes
    tx.updated_by = user
    tx.full_clean()
    tx.save()

    if contribution.financial_transaction_id != tx.pk:
        contribution.financial_transaction = tx
        contribution.save(update_fields=["financial_transaction"])

    credit_amount = contribution.family_credit_amount or Decimal("0")
    if credit_amount > 0 and contribution.family_charge_id:
        credit = contribution.family_credit or FamilyCredit(
            created_by=user,
            credit_type=FamilyCredit.CreditType.FUNDRAISING,
        )
        credit.charge = contribution.family_charge
        credit.credit_type = FamilyCredit.CreditType.FUNDRAISING
        credit.amount = credit_amount
        credit.source = campaign.name
        credit.status = FamilyCredit.Status.APPLIED
        detail = f"Fundraising contribution #{contribution.pk}"
        credit.notes = f"{detail}. {contribution.notes}".strip()
        credit.full_clean()
        credit.save()
        if contribution.family_credit_id != credit.pk:
            contribution.family_credit = credit
            contribution.save(update_fields=["family_credit"])
    elif contribution.family_credit_id:
        credit = contribution.family_credit
        credit.status = FamilyCredit.Status.CANCELLED
        credit.notes = (
            f"{credit.notes}\nFamily fundraising credit removed from contribution #{contribution.pk}."
        ).strip()
        credit.save(update_fields=["status", "notes"])


def _fundraising_policy(season):
    if not season:
        return None
    policy, _ = FundraisingPolicy.objects.get_or_create(
        season=season,
        defaults={
            "model": FundraisingPolicy.Model.TEAM_WIDE,
            "default_family_credit_percent": Decimal("0"),
            "participation_optional": True,
        },
    )
    return policy


@login_required
def fundraising_policy_edit(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    if not season:
        messages.error(request, "Create or activate a season before setting a fundraising policy.")
        return redirect("fundraising_dashboard")
    policy = _fundraising_policy(season)
    form = FundraisingPolicyForm(request.POST or None, instance=policy, season=season)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.season = season
        obj.updated_by = request.user
        obj.full_clean()
        obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED,
            obj=obj, season=season,
            summary=f"Updated fundraising policy for {season.name}",
            details={
                "model": obj.model,
                "default_family_credit_percent": obj.default_family_credit_percent,
                "participation_optional": obj.participation_optional,
                "allowed_charge_types": ", ".join(obj.allowed_charge_types or []),
            },
        )
        messages.success(request, "Fundraising policy updated.")
        return redirect("fundraising_dashboard")
    return render(request, "portal/form.html", {
        "form": form,
        "title": f"Fundraising policy · {season.name}",
        "eyebrow": "FUNDRAISING POLICY",
    })


@login_required
def family_fundraising(request, membership_pk):
    team = _team(request.user)
    membership = get_object_or_404(
        SeasonMembership.objects.select_related("rider", "season"),
        pk=membership_pk, season__team=team,
    )
    if not _can_view_family_account(request.user, membership):
        raise PermissionDenied

    policy = _fundraising_policy(membership.season)
    contributions = (
        FundraisingContribution.objects.filter(
            campaign__team=team,
            campaign__season=membership.season,
            beneficiary_membership=membership,
            status=FundraisingContribution.Status.POSTED,
        )
        .select_related("campaign", "family_charge")
        .order_by("-received_date", "-created_at")
    )

    rows = []
    total_raised = total_credit = Decimal("0")
    for contribution in contributions:
        rows.append({
            "campaign": contribution.campaign,
            "date": contribution.received_date,
            "amount": contribution.amount,
            "family_credit": contribution.family_credit_amount,
            "team_retained": contribution.team_retained_amount,
            "family_charge": contribution.family_charge,
        })
        total_raised += contribution.amount
        total_credit += contribution.family_credit_amount or Decimal("0")

    return render(request, "portal/family_fundraising.html", {
        "membership": membership,
        "policy": policy,
        "rows": rows,
        "total_raised": total_raised,
        "total_credit": total_credit,
        "total_team": total_raised - total_credit,
    })


@login_required
def fundraising_dashboard(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)

    campaigns = FundraisingCampaign.objects.filter(team=team).select_related("season")
    selected_season = request.GET.get("season", "")
    if selected_season == "all":
        pass
    elif selected_season.isdigit():
        campaigns = campaigns.filter(season_id=int(selected_season))
    else:
        selected_season = str(season.pk) if season else "all"
        if season:
            campaigns = campaigns.filter(season=season)

    campaign_rows = []
    total_raised = total_family_credit = total_retained = Decimal("0")
    for campaign in campaigns:
        raised = campaign.posted_total
        family_credit = campaign.family_credit_total
        retained = raised - family_credit
        campaign_rows.append({
            "campaign": campaign,
            "raised": raised,
            "family_credit": family_credit,
            "retained": retained,
        })
        total_raised += raised
        total_family_credit += family_credit
        total_retained += retained

    return render(request, "portal/fundraising_dashboard.html", {
        "policy": _fundraising_policy(season),
        "campaign_rows": campaign_rows,
        "seasons": Season.objects.filter(team=team).order_by("-start_date"),
        "selected_season": selected_season,
        "total_raised": total_raised,
        "total_family_credit": total_family_credit,
        "total_retained": total_retained,
    })


@login_required
def fundraising_campaign_create(request):
    team = _team(request.user)
    season = _active_season(team)
    _require_finance(request.user, season)
    if not season:
        messages.error(request, "Create or activate a season before creating a fundraising campaign.")
        return redirect("fundraising_dashboard")
    form = FundraisingCampaignForm(request.POST or None)
    if not request.method == "POST" and season:
        form.fields["start_date"].initial = timezone.localdate()
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.season = season
        obj.created_by = request.user
        obj.full_clean()
        obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj,
            season=season, summary=f"Created fundraising campaign: {obj.name}",
            details={"goal": obj.goal_amount, "status": obj.status},
        )
        messages.success(request, "Fundraising campaign created.")
        return redirect("fundraising_campaign_detail", pk=obj.pk)
    return render(request, "portal/form.html", {
        "form": form, "title": "New fundraising campaign", "eyebrow": "FUNDRAISING"
    })


@login_required
def fundraising_campaign_edit(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(FundraisingCampaign, pk=pk, team=team)
    _require_finance(request.user, obj.season)
    form = FundraisingCampaignForm(request.POST or None, instance=obj)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.full_clean()
        obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj,
            season=obj.season, summary=f"Updated fundraising campaign: {obj.name}",
            details={"goal": obj.goal_amount, "status": obj.status},
        )
        messages.success(request, "Fundraising campaign updated.")
        return redirect("fundraising_campaign_detail", pk=obj.pk)
    return render(request, "portal/form.html", {
        "form": form, "title": f"Edit fundraiser · {obj.name}", "eyebrow": "FUNDRAISING"
    })


@login_required
def fundraising_campaign_detail(request, pk):
    team = _team(request.user)
    campaign = get_object_or_404(FundraisingCampaign.objects.select_related("season"), pk=pk, team=team)
    _require_finance(request.user, campaign.season)
    contributions = campaign.contributions.select_related(
        "beneficiary_membership__rider", "family_charge", "account", "category",
        "financial_transaction", "family_credit"
    )
    posted = contributions.filter(status=FundraisingContribution.Status.POSTED)
    totals = posted.aggregate(
        raised=Sum("amount"),
        family_credit=Sum("family_credit_amount"),
    )
    raised = totals["raised"] or Decimal("0")
    family_credit = totals["family_credit"] or Decimal("0")
    return render(request, "portal/fundraising_campaign_detail.html", {
        "campaign": campaign,
        "contributions": contributions,
        "raised": raised,
        "family_credit": family_credit,
        "retained": raised - family_credit,
    })


@login_required
def fundraising_contribution_add(request, campaign_pk):
    team = _team(request.user)
    campaign = get_object_or_404(FundraisingCampaign, pk=campaign_pk, team=team)
    _require_finance(request.user, campaign.season)
    if campaign.status == FundraisingCampaign.Status.CLOSED:
        messages.error(request, "Closed fundraising campaigns cannot receive new contributions.")
        return redirect("fundraising_campaign_detail", pk=campaign.pk)

    policy = _fundraising_policy(campaign.season)
    form = FundraisingContributionForm(request.POST or None, campaign=campaign, policy=policy)
    if not request.method == "POST":
        form.fields["received_date"].initial = timezone.localdate()
    if form.is_valid():
        with transaction.atomic():
            obj = form.save(commit=False)
            obj.campaign = campaign
            obj.created_by = request.user
            obj.status = FundraisingContribution.Status.POSTED
            obj.full_clean()
            obj.save()
            _sync_fundraising_contribution(obj, request.user)
            _audit_event(
                team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj,
                season=campaign.season,
                summary=f"Recorded fundraising contribution to {campaign.name}",
                details={
                    "donor": obj.donor_name or "Anonymous", "amount": obj.amount,
                    "family_credit": obj.family_credit_amount,
                    "beneficiary": obj.beneficiary_membership or "",
                },
            )
        messages.success(request, "Fundraising contribution recorded and posted to the team ledger.")
        return redirect("fundraising_campaign_detail", pk=campaign.pk)
    return render(request, "portal/form.html", {
        "form": form, "title": f"Add contribution · {campaign.name}", "eyebrow": "FUNDRAISING"
    })


@login_required
def fundraising_contribution_edit(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(
        FundraisingContribution.objects.select_related(
            "campaign__season", "family_credit", "family_charge", "beneficiary_membership__rider"
        ),
        pk=pk, campaign__team=team,
    )
    _require_finance(request.user, obj.campaign.season)
    if obj.status == FundraisingContribution.Status.VOID:
        messages.info(request, "Voided fundraising contributions are retained for audit history and cannot be edited.")
        return redirect("fundraising_campaign_detail", pk=obj.campaign_id)

    policy = _fundraising_policy(obj.campaign.season)
    form = FundraisingContributionForm(
        request.POST or None, instance=obj, campaign=obj.campaign, policy=policy
    )
    if form.is_valid():
        with transaction.atomic():
            obj = form.save(commit=False)
            obj.campaign = obj.campaign
            obj.full_clean()
            obj.save()
            _sync_fundraising_contribution(obj, request.user)
            _audit_event(
                team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj,
                season=obj.campaign.season,
                summary=f"Updated fundraising contribution to {obj.campaign.name}",
                details={
                    "donor": obj.donor_name or "Anonymous", "amount": obj.amount,
                    "family_credit": obj.family_credit_amount,
                    "beneficiary": obj.beneficiary_membership or "",
                },
            )
        messages.success(request, "Fundraising contribution and linked finance records updated.")
        return redirect("fundraising_campaign_detail", pk=obj.campaign_id)
    return render(request, "portal/form.html", {
        "form": form, "title": f"Edit contribution · {obj.campaign.name}", "eyebrow": "FUNDRAISING"
    })


@login_required
def fundraising_contribution_void(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(
        FundraisingContribution.objects.select_related(
            "campaign__season", "financial_transaction", "family_credit"
        ),
        pk=pk, campaign__team=team,
    )
    _require_finance(request.user, obj.campaign.season)
    if obj.status == FundraisingContribution.Status.VOID:
        messages.info(request, "This fundraising contribution is already void.")
        return redirect("fundraising_campaign_detail", pk=obj.campaign_id)

    if request.method == "POST":
        reason = (request.POST.get("reason") or "Voided by Treasurer").strip()
        with transaction.atomic():
            obj.status = FundraisingContribution.Status.VOID
            obj.voided_at = timezone.now()
            obj.voided_by = request.user
            obj.void_reason = reason
            obj.save(update_fields=["status", "voided_at", "voided_by", "void_reason", "updated_at"])

            if obj.financial_transaction_id:
                tx = obj.financial_transaction
                if tx.status != FinancialTransaction.Status.VOID:
                    tx.status = FinancialTransaction.Status.VOID
                    tx.voided_at = timezone.now()
                    tx.voided_by = request.user
                    tx.void_reason = f"Fundraising contribution void: {reason}"
                    tx.updated_by = request.user
                    tx.save(update_fields=[
                        "status", "voided_at", "voided_by", "void_reason", "updated_by", "updated_at"
                    ])

            if obj.family_credit_id:
                credit = obj.family_credit
                credit.status = FamilyCredit.Status.CANCELLED
                credit.notes = f"{credit.notes}\nFundraising contribution #{obj.pk} voided: {reason}".strip()
                credit.save(update_fields=["status", "notes"])

            _audit_event(
                team=team, actor=request.user, action=AuditEvent.Action.VOIDED, obj=obj,
                season=obj.campaign.season,
                summary=f"Voided fundraising contribution to {obj.campaign.name}",
                details={"amount": obj.amount, "reason": reason},
            )
        messages.success(request, "Fundraising contribution voided; ledger and family-credit history were retained.")
        return redirect("fundraising_campaign_detail", pk=obj.campaign_id)

    return render(request, "portal/fundraising_contribution_void.html", {
        "object": obj, "title": "Void fundraising contribution"
    })


@login_required
def fundraising_campaign_export(request, pk):
    team = _team(request.user)
    campaign = get_object_or_404(FundraisingCampaign, pk=pk, team=team)
    _require_finance(request.user, campaign.season)
    response = HttpResponse(content_type="text/csv")
    safe_name = re.sub(r"[^A-Za-z0-9_-]+", "-", campaign.name).strip("-").lower() or "fundraiser"
    response["Content-Disposition"] = f'attachment; filename="{safe_name}-contributions.csv"'
    writer = csv.writer(response)
    writer.writerow([
        "Date", "Status", "Donor", "Amount", "Rider / Family", "Family credit",
        "Team retained", "Account", "Category", "Method", "Reference", "Notes",
    ])
    for row in campaign.contributions.select_related(
        "beneficiary_membership__rider", "account", "category"
    ):
        writer.writerow([
            row.received_date, row.get_status_display(), row.donor_name or "Anonymous", row.amount,
            row.beneficiary_membership.rider if row.beneficiary_membership_id else "",
            row.family_credit_amount, row.team_retained_amount,
            row.account.name, row.category.name, row.method, row.reference, row.notes,
        ])
    return response


# --- v1.9.3 Financial reporting -------------------------------------------

def _finance_report_season(request, team):
    season_id = request.GET.get("season")
    if season_id:
        return Season.objects.filter(team=team, pk=season_id).first()
    return _active_season(team)


def _budget_report_rows(season):
    if not season:
        return [], {}
    tx = FinancialTransaction.objects.filter(team=season.team, season=season, status=FinancialTransaction.Status.POSTED)
    budgets = SeasonBudget.objects.filter(season=season).select_related("category")
    rows = []
    totals = {
        "income_budget": Decimal("0"), "income_actual": Decimal("0"),
        "expense_budget": Decimal("0"), "expense_actual": Decimal("0"),
    }
    for budget in budgets:
        actual = tx.filter(
            category=budget.category, kind=budget.kind
        ).aggregate(total=Sum("amount"))["total"] or Decimal("0")
        if budget.kind == FinancialTransaction.Kind.INCOME:
            variance = actual - budget.amount
            totals["income_budget"] += budget.amount
            totals["income_actual"] += actual
        else:
            variance = budget.amount - actual
            totals["expense_budget"] += budget.amount
            totals["expense_actual"] += actual
        pct = (actual / budget.amount * Decimal("100")) if budget.amount else None
        rows.append({
            "budget": budget, "actual": actual, "variance": variance,
            "percent": pct, "favorable": variance >= 0,
        })
    totals["budget_net"] = totals["income_budget"] - totals["expense_budget"]
    totals["actual_net"] = totals["income_actual"] - totals["expense_actual"]
    totals["net_variance"] = totals["actual_net"] - totals["budget_net"]
    return rows, totals


def _receivable_report_rows(season):
    if not season:
        return [], {}
    today = timezone.localdate()
    rows = []
    totals = {
        "billed": Decimal("0"), "credits": Decimal("0"), "assistance": Decimal("0"),
        "payments": Decimal("0"), "balance": Decimal("0"), "overdue": Decimal("0"),
        "due_soon": Decimal("0"),
    }
    memberships = SeasonMembership.objects.filter(season=season).select_related(
        "rider", "home_barn"
    ).order_by("rider__last_name", "rider__first_name")
    for membership in memberships:
        info = _family_account_totals(membership)
        overdue = due_soon = Decimal("0")
        next_due = None
        for charge in info["charges"]:
            charge_balance = charge.balance
            if charge_balance <= 0 or not charge.due_date:
                continue
            if next_due is None or charge.due_date < next_due:
                next_due = charge.due_date
            if charge.due_date < today:
                overdue += charge_balance
            elif charge.due_date <= today + timedelta(days=14):
                due_soon += charge_balance
        status = "current"
        if overdue > 0:
            status = "overdue"
        elif due_soon > 0:
            status = "due_soon"
        elif info["balance"] <= 0 and info["billed"] > 0:
            status = "paid"
        credits = info["generic_credits"] + info["service_credits"]
        row = {
            "membership": membership, **info, "credits": credits,
            "overdue": overdue, "due_soon": due_soon, "next_due": next_due, "status": status,
        }
        rows.append(row)
        totals["billed"] += info["billed"]
        totals["credits"] += credits
        totals["assistance"] += info["assistance"]
        totals["payments"] += info["payments"]
        totals["balance"] += info["balance"]
        totals["overdue"] += overdue
        totals["due_soon"] += due_soon
    return rows, totals


def _assistance_report_rows(season):
    if not season:
        return [], {}
    rows = []
    totals = {
        "approved_maximum": Decimal("0"), "allocated": Decimal("0"),
        "submitted": Decimal("0"), "approved": Decimal("0"),
        "reimbursed": Decimal("0"), "remaining": Decimal("0"),
        "draft_claims": 0, "outstanding_claims": 0,
    }
    awards = FinancialAssistanceAward.objects.filter(
        membership__season=season
    ).select_related("membership__rider").prefetch_related("claims__charge")
    for award in awards:
        claims = list(award.claims.all())
        submitted = sum(
            (c.amount_requested for c in claims if c.status in {
                AssistanceClaim.Status.SUBMITTED, AssistanceClaim.Status.APPROVED, AssistanceClaim.Status.REIMBURSED
            }), Decimal("0")
        )
        approved = sum(
            (c.amount_approved for c in claims if c.status in {
                AssistanceClaim.Status.APPROVED, AssistanceClaim.Status.REIMBURSED
            }), Decimal("0")
        )
        reimbursed = sum((c.reimbursed_amount for c in claims), Decimal("0"))
        draft_count = sum(1 for c in claims if c.status == AssistanceClaim.Status.DRAFT)
        outstanding_count = sum(1 for c in claims if c.status in {
            AssistanceClaim.Status.SUBMITTED, AssistanceClaim.Status.APPROVED
        })
        allocated = award.allocated_total
        remaining = award.remaining_eligibility
        rows.append({
            "award": award, "claims": claims, "allocated": allocated,
            "submitted": submitted, "approved": approved, "reimbursed": reimbursed,
            "remaining": remaining, "draft_count": draft_count,
            "outstanding_count": outstanding_count,
        })
        totals["approved_maximum"] += award.approved_maximum
        totals["allocated"] += allocated
        totals["submitted"] += submitted
        totals["approved"] += approved
        totals["reimbursed"] += reimbursed
        totals["remaining"] += remaining
        totals["draft_claims"] += draft_count
        totals["outstanding_claims"] += outstanding_count
    return rows, totals


@login_required
def finance_reports(request):
    team = _team(request.user)
    season = _finance_report_season(request, team)
    _require_finance(request.user, season)
    seasons = Season.objects.filter(team=team).order_by("-start_date")
    budget_rows, budget_totals = _budget_report_rows(season)
    receivable_rows, receivable_totals = _receivable_report_rows(season)
    assistance_rows, assistance_totals = _assistance_report_rows(season)
    return render(request, "portal/finance_reports.html", {
        "season": season, "seasons": seasons,
        "budget_line_count": len(budget_rows),
        "budget_totals": budget_totals,
        "receivable_totals": receivable_totals,
        "assistance_totals": assistance_totals,
        "assistance_count": len(assistance_rows),
    })


@login_required
def finance_report_budget(request):
    team = _team(request.user)
    season = _finance_report_season(request, team)
    _require_finance(request.user, season)
    rows, totals = _budget_report_rows(season)
    return render(request, "portal/finance_report_budget.html", {
        "season": season, "seasons": Season.objects.filter(team=team).order_by("-start_date"),
        "rows": rows, "totals": totals,
    })


@login_required
def finance_report_receivables(request):
    team = _team(request.user)
    season = _finance_report_season(request, team)
    _require_finance(request.user, season)
    rows, totals = _receivable_report_rows(season)
    status = request.GET.get("status", "")
    if status in {"overdue", "due_soon", "current", "paid"}:
        rows = [row for row in rows if row["status"] == status]
    return render(request, "portal/finance_report_receivables.html", {
        "season": season, "seasons": Season.objects.filter(team=team).order_by("-start_date"),
        "rows": rows, "totals": totals, "selected_status": status,
    })


@login_required
def finance_report_assistance(request):
    team = _team(request.user)
    season = _finance_report_season(request, team)
    _require_finance(request.user, season)
    rows, totals = _assistance_report_rows(season)
    return render(request, "portal/finance_report_assistance.html", {
        "season": season, "seasons": Season.objects.filter(team=team).order_by("-start_date"),
        "rows": rows, "totals": totals,
    })


@login_required
def finance_report_category(request):
    team = _team(request.user)
    season = _finance_report_season(request, team)
    _require_finance(request.user, season)
    categories = FinancialCategory.objects.filter(team=team).order_by("sort_order", "name")
    category_id = request.GET.get("category")
    kind = request.GET.get("kind", "")
    category = categories.filter(pk=category_id).first() if category_id else None
    tx = FinancialTransaction.objects.filter(team=team, season=season, status=FinancialTransaction.Status.POSTED).select_related("category", "account", "rider", "show")
    if category:
        tx = tx.filter(category=category)
    if kind in {FinancialTransaction.Kind.INCOME, FinancialTransaction.Kind.EXPENSE}:
        tx = tx.filter(kind=kind)
    totals = tx.aggregate(
        income=Sum("amount", filter=Q(kind=FinancialTransaction.Kind.INCOME)),
        expense=Sum("amount", filter=Q(kind=FinancialTransaction.Kind.EXPENSE)),
    )
    income = totals["income"] or Decimal("0")
    expense = totals["expense"] or Decimal("0")
    return render(request, "portal/finance_report_category.html", {
        "season": season, "seasons": Season.objects.filter(team=team).order_by("-start_date"),
        "categories": categories, "selected_category": category, "selected_kind": kind,
        "transactions": tx[:500], "income": income, "expense": expense, "net": income-expense,
    })


def _csv_response(filename, headers, rows):
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    writer = csv.writer(response)
    writer.writerow(headers)
    for row in rows:
        writer.writerow(row)
    return response


@login_required
def finance_report_budget_export(request):
    team = _team(request.user); season = _finance_report_season(request, team)
    _require_finance(request.user, season)
    rows, _ = _budget_report_rows(season)
    return _csv_response(
        f"budget-vs-actual-{season.name if season else 'none'}.csv",
        ["Season","Type","Category","Budget","Actual","Variance","Percent"],
        [[season.name, r["budget"].get_kind_display(), r["budget"].category.name,
          r["budget"].amount, r["actual"], r["variance"],
          f'{r["percent"]:.1f}' if r["percent"] is not None else ""] for r in rows],
    )


@login_required
def finance_report_receivables_export(request):
    team = _team(request.user); season = _finance_report_season(request, team)
    _require_finance(request.user, season)
    rows, _ = _receivable_report_rows(season)
    return _csv_response(
        f"family-receivables-{season.name if season else 'none'}.csv",
        ["Season","Rider","Home Barn","Billed","Credits","Assistance","Payments","Balance","Overdue","Due Soon","Status"],
        [[season.name, r["membership"].rider, r["membership"].home_barn or "", r["billed"], r["credits"],
          r["assistance"], r["payments"], r["balance"], r["overdue"], r["due_soon"], r["status"]] for r in rows],
    )


@login_required
def finance_report_assistance_export(request):
    team = _team(request.user); season = _finance_report_season(request, team)
    _require_finance(request.user, season)
    rows, _ = _assistance_report_rows(season)
    return _csv_response(
        f"financial-assistance-{season.name if season else 'none'}.csv",
        ["Season","Rider","Provider","Program","Award Maximum","Allocated","Submitted","Approved","Reimbursed","Remaining","Status"],
        [[season.name, r["award"].membership.rider, r["award"].provider, r["award"].program_name,
          r["award"].approved_maximum, r["allocated"], r["submitted"], r["approved"],
          r["reimbursed"], r["remaining"], r["award"].get_status_display()] for r in rows],
    )


@login_required
def finance_report_category_export(request):
    team = _team(request.user); season = _finance_report_season(request, team)
    _require_finance(request.user, season)
    category_id = request.GET.get("category")
    kind = request.GET.get("kind", "")
    tx = FinancialTransaction.objects.filter(team=team, season=season, status=FinancialTransaction.Status.POSTED).select_related("category", "account", "rider", "show")
    if category_id:
        tx = tx.filter(category_id=category_id)
    if kind in {FinancialTransaction.Kind.INCOME, FinancialTransaction.Kind.EXPENSE}:
        tx = tx.filter(kind=kind)
    return _csv_response(
        f"category-activity-{season.name if season else 'none'}.csv",
        ["Date","Season","Type","Category","Account","Description","Payee","Rider","Show","Amount","Reference"],
        [[t.transaction_date, t.season.name, t.get_kind_display(), t.category.name, t.account.name,
          t.description, t.payee, t.rider or "", t.show or "", t.amount, t.reference] for t in tx],
    )



# --- v1.9.4 Show finance & funding policies -------------------------------

def _show_finance_totals(show):
    allocations = ShowTransactionAllocation.objects.filter(
        show=show,
        transaction__status=FinancialTransaction.Status.POSTED,
    ).select_related("transaction", "transaction__category", "transaction__account", "budget_line")

    income = allocations.filter(
        transaction__kind=FinancialTransaction.Kind.INCOME
    ).aggregate(total=Sum("amount"))["total"] or Decimal("0")
    expense = allocations.filter(
        transaction__kind=FinancialTransaction.Kind.EXPENSE
    ).aggregate(total=Sum("amount"))["total"] or Decimal("0")

    hosting_income = allocations.filter(
        scope=FinancialTransaction.ShowFinanceScope.HOSTING,
        transaction__kind=FinancialTransaction.Kind.INCOME,
    ).aggregate(total=Sum("amount"))["total"] or Decimal("0")
    hosting_expense = allocations.filter(
        scope=FinancialTransaction.ShowFinanceScope.HOSTING,
        transaction__kind=FinancialTransaction.Kind.EXPENSE,
    ).aggregate(total=Sum("amount"))["total"] or Decimal("0")
    participation_income = allocations.filter(
        scope=FinancialTransaction.ShowFinanceScope.PARTICIPATION,
        transaction__kind=FinancialTransaction.Kind.INCOME,
    ).aggregate(total=Sum("amount"))["total"] or Decimal("0")
    participation_expense = allocations.filter(
        scope=FinancialTransaction.ShowFinanceScope.PARTICIPATION,
        transaction__kind=FinancialTransaction.Kind.EXPENSE,
    ).aggregate(total=Sum("amount"))["total"] or Decimal("0")

    legacy_unallocated = FinancialTransaction.objects.filter(
        team=show.team,
        season=show.season,
        show=show,
        status=FinancialTransaction.Status.POSTED,
        show_allocations__isnull=True,
    ).select_related("category", "account")
    legacy_unallocated_amount = legacy_unallocated.aggregate(total=Sum("amount"))["total"] or Decimal("0")

    unassigned_budget_allocations = allocations.filter(budget_line__isnull=True)
    unassigned_budget_amount = unassigned_budget_allocations.aggregate(total=Sum("amount"))["total"] or Decimal("0")

    family_charges = list(show.family_charges.select_related("membership__rider").all())
    billed = sum((c.amount for c in family_charges), Decimal("0"))
    outstanding = sum((c.balance for c in family_charges), Decimal("0"))

    budget_rows = []
    budget_scope_totals = {
        ShowBudgetLine.Scope.HOSTING: {
            "income_planned": Decimal("0"), "income_actual": Decimal("0"),
            "expense_planned": Decimal("0"), "expense_actual": Decimal("0"),
        },
        ShowBudgetLine.Scope.PARTICIPATION: {
            "income_planned": Decimal("0"), "income_actual": Decimal("0"),
            "expense_planned": Decimal("0"), "expense_actual": Decimal("0"),
        },
    }
    for line in show.show_budget_lines.select_related("category"):
        actual = allocations.filter(
            budget_line=line
        ).aggregate(total=Sum("amount"))["total"] or Decimal("0")
        variance = (
            actual - line.amount
            if line.kind == FinancialTransaction.Kind.INCOME
            else line.amount - actual
        )
        budget_rows.append({"line": line, "actual": actual, "variance": variance})
        bucket = budget_scope_totals[line.scope]
        if line.kind == FinancialTransaction.Kind.INCOME:
            bucket["income_planned"] += line.amount
            bucket["income_actual"] += actual
        else:
            bucket["expense_planned"] += line.amount
            bucket["expense_actual"] += actual

    return {
        "income": income,
        "expense": expense,
        "net": income - expense,
        "hosting_income": hosting_income,
        "hosting_expense": hosting_expense,
        "hosting_net": hosting_income - hosting_expense,
        "participation_income": participation_income,
        "participation_expense": participation_expense,
        "participation_net": participation_income - participation_expense,
        "family_billed": billed,
        "family_outstanding": outstanding,
        "family_charges": family_charges,
        "budget_rows": budget_rows,
        "budget_scope_totals": budget_scope_totals,
        "show_allocations": allocations,
        "unassigned_budget_allocations": unassigned_budget_allocations,
        "unassigned_budget_amount": unassigned_budget_amount,
        "legacy_unallocated_transactions": legacy_unallocated,
        "legacy_unallocated_amount": legacy_unallocated_amount,
    }


@login_required
def show_finance(request, pk):
    team = _team(request.user)
    show = get_object_or_404(Show.objects.select_related("season"), pk=pk, team=team)
    _require_finance(request.user, show.season)
    totals = _show_finance_totals(show)
    reimbursements = show.reimbursement_requests.select_related("requested_by","category","payment_account")
    return render(request, "portal/show_finance.html", {
        "show": show, **totals, "reimbursements": reimbursements,
        "funding_policy": show.season.show_fee_policy_for(show.competition_level),
        "funding_policy_label": dict(Season.ShowFeePolicy.choices).get(show.season.show_fee_policy_for(show.competition_level)),
    })


@login_required
def show_budget_add(request, show_pk):
    team = _team(request.user); show = get_object_or_404(Show, pk=show_pk, team=team)
    _require_finance(request.user, show.season)
    form = ShowBudgetLineForm(request.POST or None, show=show)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.show = show
        obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.CREATED, obj=obj,
            season=show.season,
            summary=f"Added show budget item: {obj.description}",
            details={"show": show, "scope": obj.scope, "category": obj.category, "amount": obj.amount},
        )
        messages.success(request, "Show budget line added.")
        return redirect("show_finance", pk=show.pk)
    return render(request,"portal/form.html",{"form":form,"title":"Add show budget line","eyebrow":show.name})


@login_required
def show_budget_edit(request, pk):
    team=_team(request.user); line=get_object_or_404(ShowBudgetLine.objects.select_related("show"),pk=pk,show__team=team)
    _require_finance(request.user,line.show.season)
    form=ShowBudgetLineForm(request.POST or None,instance=line,show=line.show)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.show = line.show
        obj.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=obj,
            season=line.show.season,
            summary=f"Updated show budget item: {obj.description}",
            details={"show": line.show, "scope": obj.scope, "category": obj.category, "amount": obj.amount},
        )
        messages.success(request, "Show budget line updated.")
        return redirect("show_finance", pk=line.show_id)
    return render(request,"portal/form.html",{"form":form,"title":"Edit show budget line","eyebrow":line.show.name})


@login_required
def show_family_charges_generate(request, pk):
    team=_team(request.user); show=get_object_or_404(Show.objects.select_related("season"),pk=pk,team=team)
    _require_finance(request.user,show.season)
    policy=show.season.show_fee_policy_for(show.competition_level)
    riders=Rider.objects.filter(show_entries__show_class__show=show).distinct().order_by("last_name","first_name")
    memberships=SeasonMembership.objects.filter(season=show.season,rider__in=riders).select_related("rider")
    if request.method=="POST":
        if policy in {Season.ShowFeePolicy.INCLUDED, Season.ShowFeePolicy.PACKAGE}:
            messages.error(request,"This season marks these show fees as covered by dues or a season package. Change the funding policy or use Manual / mixed before creating family charges.")
            return redirect("show_finance",pk=show.pk)
        amount_raw=request.POST.get("amount","0")
        description=(request.POST.get("description") or f"{show.name} show fee").strip()
        due_date=request.POST.get("due_date") or None
        try: amount=Decimal(amount_raw)
        except Exception: amount=Decimal("0")
        selected=set(request.POST.getlist("membership"))
        if amount <= 0:
            messages.error(request,"Enter a show fee greater than zero.")
        else:
            created=skipped=0
            for membership in memberships:
                if str(membership.pk) not in selected: continue
                exists=FamilyCharge.objects.filter(membership=membership,show=show,charge_type=FamilyCharge.ChargeType.SHOW_FEE).exists()
                if exists: skipped+=1; continue
                FamilyCharge.objects.create(membership=membership,show=show,charge_type=FamilyCharge.ChargeType.SHOW_FEE,
                    description=description,amount=amount,due_date=due_date,created_by=request.user)
                created+=1
            messages.success(request,f"Created {created} family show charge{'s' if created != 1 else ''}; skipped {skipped} existing charge{'s' if skipped != 1 else ''}.")
            return redirect("show_finance",pk=show.pk)
    return render(request,"portal/show_family_charges.html",{
        "show":show,"memberships":memberships,"policy":policy,
        "policy_label":dict(Season.ShowFeePolicy.choices).get(policy),
        "default_amount":show.season.default_rider_show_fee,
    })


@login_required
def show_funding_policy(request):
    _require_manage(request.user); team=_team(request.user); season=_active_season(team)
    if not season:
        messages.error(request,"Create or activate a season first."); return redirect("season_setup")
    form=ShowFundingPolicyForm(request.POST or None,instance=season)
    if form.is_valid():
        form.save(); messages.success(request,"Show funding policy updated."); return redirect("season_setup")
    return render(request,"portal/form.html",{"form":form,"title":"Show funding policy","eyebrow":season.name})



@login_required
def finance_transaction_allocations(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(
        FinancialTransaction.objects.select_related("season", "account", "category"),
        pk=pk, team=team,
    )
    _require_finance(request.user, obj.season)
    allocations = obj.show_allocations.select_related("show", "budget_line").all()
    allocated = allocations.aggregate(total=Sum("amount"))["total"] or Decimal("0")
    remaining = obj.amount - allocated
    return render(request, "portal/finance_transaction_allocations.html", {
        "transaction": obj,
        "allocations": allocations,
        "allocated": allocated,
        "remaining": remaining,
    })


@login_required
@friendly_integrity_errors
def finance_transaction_allocation_add(request, pk):
    team = _team(request.user)
    obj = get_object_or_404(FinancialTransaction, pk=pk, team=team)
    _require_finance(request.user, obj.season)
    if obj.status != FinancialTransaction.Status.POSTED:
        messages.error(request, "Voided transactions cannot receive show allocations.")
        return redirect("finance_transaction_allocations", pk=obj.pk)
    allocated = obj.show_allocations.aggregate(total=Sum("amount"))["total"] or Decimal("0")
    remaining = obj.amount - allocated
    form = ShowTransactionAllocationForm(
        request.POST or None, transaction=obj,
        initial={"amount": remaining if remaining > 0 else None},
    )
    if form.is_valid():
        allocation = form.save(commit=False)
        allocation.transaction = obj
        allocation.full_clean()
        allocation.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.ALLOCATED, obj=allocation,
            summary=f"Allocated {allocation.amount} to {allocation.show.name}",
            details={
                "transaction": obj.pk, "scope": allocation.scope,
                "budget_item": allocation.budget_line or "", "amount": allocation.amount,
            },
        )
        messages.success(request, "Show allocation added.")
        return redirect("finance_transaction_allocations", pk=obj.pk)
    return render(request, "portal/form.html", {
        "form": form,
        "title": "Allocate transaction to show",
        "eyebrow": obj.description,
    })


@login_required
@friendly_integrity_errors
def finance_transaction_allocation_edit(request, allocation_pk):
    team = _team(request.user)
    allocation = get_object_or_404(
        ShowTransactionAllocation.objects.select_related("transaction", "show"),
        pk=allocation_pk, transaction__team=team,
    )
    obj = allocation.transaction
    _require_finance(request.user, obj.season)
    if obj.status != FinancialTransaction.Status.POSTED:
        messages.error(request, "Allocations on voided transactions cannot be edited.")
        return redirect("finance_transaction_allocations", pk=obj.pk)
    form = ShowTransactionAllocationForm(
        request.POST or None, instance=allocation, transaction=obj
    )
    if form.is_valid():
        item = form.save(commit=False)
        item.transaction = obj
        item.full_clean()
        item.save()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.UPDATED, obj=item,
            summary=f"Updated show allocation for {item.show.name}",
            details={
                "transaction": obj.pk, "scope": item.scope,
                "budget_item": item.budget_line or "", "amount": item.amount,
            },
        )
        messages.success(request, "Show allocation updated.")
        return redirect("finance_transaction_allocations", pk=obj.pk)
    return render(request, "portal/form.html", {
        "form": form,
        "title": "Edit show allocation",
        "eyebrow": obj.description,
    })


@login_required
def finance_transaction_allocation_delete(request, allocation_pk):
    team = _team(request.user)
    allocation = get_object_or_404(
        ShowTransactionAllocation.objects.select_related("transaction", "show"),
        pk=allocation_pk, transaction__team=team,
    )
    obj = allocation.transaction
    _require_finance(request.user, obj.season)
    if request.method == "POST":
        allocation_label = str(allocation)
        allocation_id = allocation.pk
        allocation_amount = allocation.amount
        allocation_show = allocation.show
        allocation.delete()
        _audit_event(
            team=team, actor=request.user, action=AuditEvent.Action.REMOVED,
            season=obj.season, entity_type="ShowTransactionAllocation",
            entity_id=allocation_id, entity_label=allocation_label,
            summary=f"Removed show allocation from {allocation_show.name}",
            details={"transaction": obj.pk, "amount": allocation_amount, "show": allocation_show},
        )
        messages.success(request, "Show allocation removed. The ledger transaction itself was not changed.")
        return redirect("finance_transaction_allocations", pk=obj.pk)
    return render(request, "portal/confirm_delete.html", {
        "object": allocation,
        "title": "Remove show allocation",
        "message": "This removes only the reporting allocation. It does not delete or void the underlying payment.",
    })

@login_required
def reimbursement_list(request):
    _require_adult_finance_participant(request.user)
    team = _team(request.user)
    base = ReimbursementRequest.objects.filter(team=team).select_related(
        "season", "show", "requested_by", "category"
    )

    is_admin = request.user.is_superuser or (
        hasattr(request.user, "profile") and request.user.profile.role == UserProfile.Role.ADMIN
    )
    finance_season_ids = _finance_season_ids(request.user, team)
    can_review_any = is_admin or bool(finance_season_ids)

    if is_admin:
        qs = base.filter(Q(status__gt="") & (Q(status__in=[
            ReimbursementRequest.Status.SUBMITTED,
            ReimbursementRequest.Status.APPROVED,
            ReimbursementRequest.Status.REJECTED,
            ReimbursementRequest.Status.PAID,
        ]) | Q(requested_by=request.user)))
    elif finance_season_ids:
        qs = base.filter(
            Q(requested_by=request.user)
            | (
                Q(season_id__in=finance_season_ids)
                & ~Q(status=ReimbursementRequest.Status.DRAFT)
            )
        ).distinct()
    else:
        qs = base.filter(requested_by=request.user)

    selected_status = request.GET.get("status", "")
    selected_season = request.GET.get("season", "")
    selected_show = request.GET.get("show", "")
    q = request.GET.get("q", "").strip()

    valid_statuses = {x[0] for x in ReimbursementRequest.Status.choices}
    if selected_status in valid_statuses:
        qs = qs.filter(status=selected_status)
    else:
        selected_status = ""
    if selected_season.isdigit():
        qs = qs.filter(season_id=int(selected_season))
    else:
        selected_season = ""
    if selected_show.isdigit():
        qs = qs.filter(show_id=int(selected_show))
    else:
        selected_show = ""
    if q:
        qs = qs.filter(
            Q(description__icontains=q)
            | Q(payee_name__icontains=q)
            | Q(category__name__icontains=q)
            | Q(show__name__icontains=q)
            | Q(requested_by__first_name__icontains=q)
            | Q(requested_by__last_name__icontains=q)
        )

    paginator = Paginator(qs, 50)
    page = paginator.get_page(request.GET.get("page"))
    params = {
        "status": selected_status, "season": selected_season,
        "show": selected_show, "q": q,
    }
    return render(request, "portal/reimbursement_list.html", {
        "requests": page.object_list, "page_obj": page, "can_finance": can_review_any,
        "selected_status": selected_status, "selected_season": selected_season,
        "selected_show": selected_show, "q": q,
        "filter_query": urlencode({k: v for k, v in params.items() if v}),
        "statuses": ReimbursementRequest.Status.choices,
        "seasons": Season.objects.filter(team=team).order_by("-start_date"),
        "shows": Show.objects.filter(team=team).order_by("-show_date", "name"),
    })


@login_required
def reimbursement_create(request):
    _require_adult_finance_participant(request.user)
    team = _team(request.user)
    form = ReimbursementRequestForm(
        request.POST or None, request.FILES or None, team=team, user=request.user
    )
    if form.is_valid():
        obj = form.save(commit=False)
        obj.team = team
        obj.requested_by = request.user
        action = request.POST.get("action", "submit")
        if action == "draft":
            obj.status = ReimbursementRequest.Status.DRAFT
            obj.submitted_at = None
        else:
            obj.status = ReimbursementRequest.Status.SUBMITTED
            obj.submitted_at = timezone.now()
        obj.full_clean()
        obj.save()
        _audit_event(
            team=team, actor=request.user,
            action=AuditEvent.Action.CREATED if obj.status == ReimbursementRequest.Status.DRAFT else AuditEvent.Action.SUBMITTED,
            obj=obj, season=obj.season,
            summary=(
                f"Saved reimbursement draft: {obj.description}"
                if obj.status == ReimbursementRequest.Status.DRAFT
                else f"Submitted reimbursement: {obj.description}"
            ),
            details={"amount": obj.amount, "show": obj.show or "", "category": obj.category},
        )
        messages.success(
            request,
            "Reimbursement saved as a draft." if obj.status == ReimbursementRequest.Status.DRAFT
            else "Reimbursement request submitted for Treasurer review."
        )
        return redirect("reimbursement_list")
    return render(request, "portal/reimbursement_form.html", {
        "form": form, "title": "New reimbursement", "eyebrow": "TEAM EXPENSE"
    })


@login_required
def reimbursement_edit(request, pk):
    _require_adult_finance_participant(request.user)
    team = _team(request.user)
    obj = get_object_or_404(ReimbursementRequest, pk=pk, team=team, requested_by=request.user)
    if obj.status != ReimbursementRequest.Status.DRAFT:
        messages.error(request, "Only draft reimbursements can be edited by the submitter.")
        return redirect("reimbursement_list")

    form = ReimbursementRequestForm(
        request.POST or None, request.FILES or None, instance=obj, team=team, user=request.user
    )
    if form.is_valid():
        item = form.save(commit=False)
        action = request.POST.get("action", "draft")
        if action == "submit":
            item.status = ReimbursementRequest.Status.SUBMITTED
            item.submitted_at = timezone.now()
        else:
            item.status = ReimbursementRequest.Status.DRAFT
            item.submitted_at = None
        item.full_clean()
        item.save()
        _audit_event(
            team=team, actor=request.user,
            action=AuditEvent.Action.SUBMITTED if item.status == ReimbursementRequest.Status.SUBMITTED else AuditEvent.Action.UPDATED,
            obj=item, season=item.season,
            summary=(
                f"Submitted reimbursement: {item.description}"
                if item.status == ReimbursementRequest.Status.SUBMITTED
                else f"Updated reimbursement draft: {item.description}"
            ),
            details={"amount": item.amount, "show": item.show or "", "category": item.category},
        )
        messages.success(
            request,
            "Reimbursement submitted for Treasurer review."
            if item.status == ReimbursementRequest.Status.SUBMITTED
            else "Reimbursement draft updated."
        )
        return redirect("reimbursement_list")
    return render(request, "portal/reimbursement_form.html", {
        "form": form, "title": "Edit reimbursement draft", "eyebrow": "TEAM EXPENSE"
    })


@login_required
@require_POST
def reimbursement_submit(request, pk):
    _require_adult_finance_participant(request.user)
    team = _team(request.user)
    obj = get_object_or_404(ReimbursementRequest, pk=pk, team=team, requested_by=request.user)
    if obj.status != ReimbursementRequest.Status.DRAFT:
        messages.error(request, "Only draft reimbursements can be submitted.")
        return redirect("reimbursement_list")
    obj.status = ReimbursementRequest.Status.SUBMITTED
    obj.submitted_at = timezone.now()
    obj.full_clean()
    obj.save(update_fields=["status", "submitted_at"])
    _audit_event(
        team=team, actor=request.user, action=AuditEvent.Action.SUBMITTED, obj=obj,
        season=obj.season, summary=f"Submitted reimbursement: {obj.description}",
        details={"amount": obj.amount},
    )
    messages.success(request, "Reimbursement submitted for Treasurer review.")
    return redirect("reimbursement_list")


@login_required
def reimbursement_review(request, pk):
    _require_adult_finance_participant(request.user)
    team = _team(request.user)
    obj = get_object_or_404(ReimbursementRequest, pk=pk, team=team)
    _require_finance(request.user, obj.season)
    if obj.status == ReimbursementRequest.Status.DRAFT:
        raise PermissionDenied("Draft reimbursements are private to the submitter.")

    previous_status = obj.status
    form = ReimbursementReviewForm(request.POST or None, instance=obj, team=team)
    if form.is_valid():
        item = form.save(commit=False)
        allowed = {
            ReimbursementRequest.Status.SUBMITTED: {
                ReimbursementRequest.Status.SUBMITTED,
                ReimbursementRequest.Status.APPROVED,
                ReimbursementRequest.Status.REJECTED,
            },
            ReimbursementRequest.Status.APPROVED: {
                ReimbursementRequest.Status.APPROVED,
                ReimbursementRequest.Status.REJECTED,
                ReimbursementRequest.Status.PAID,
            },
            ReimbursementRequest.Status.REJECTED: {
                ReimbursementRequest.Status.REJECTED,
                ReimbursementRequest.Status.SUBMITTED,
            },
            ReimbursementRequest.Status.PAID: {ReimbursementRequest.Status.PAID},
        }
        if item.status not in allowed.get(previous_status, {item.status}):
            form.add_error(
                "status",
                f"Cannot change reimbursement from {obj.get_status_display()} to {item.get_status_display()}.",
            )
        if form.errors:
            return render(request, "portal/form.html", {
                "form": form, "title": f"Review reimbursement · {obj.payee_name}", "eyebrow": "TREASURER"
            })

        item.reviewed_by = request.user
        item.reviewed_at = timezone.now()
        item.full_clean()

        if item.status == ReimbursementRequest.Status.PAID:
            if item.financial_transaction_id:
                tx = item.financial_transaction
                tx.transaction_date = item.paid_date
                tx.account = item.payment_account
                tx.category = item.category
                tx.amount = item.amount
                tx.payee = item.payee_name
                tx.description = item.description
                tx.show = item.show
                tx.show_finance_scope = item.show_finance_scope
                tx.updated_by = request.user
                tx.full_clean()
                tx.save()
            else:
                tx = FinancialTransaction(
                    team=item.team, season=item.season, transaction_date=item.paid_date,
                    kind=FinancialTransaction.Kind.EXPENSE, account=item.payment_account,
                    category=item.category, amount=item.amount, payee=item.payee_name,
                    description=item.description, show=item.show,
                    show_finance_scope=item.show_finance_scope,
                    notes=f"Reimbursement request #{item.pk}",
                    created_by=request.user, updated_by=request.user,
                )
                tx.full_clean()
                tx.save()
                item.financial_transaction = tx

        item.save()

        if item.status == ReimbursementRequest.Status.PAID and item.financial_transaction_id:
            if item.show_id and item.show_finance_scope:
                allocation_note = f"From reimbursement request #{item.pk}"
                reimbursement_allocation = ShowTransactionAllocation.objects.filter(
                    transaction=item.financial_transaction,
                    notes=allocation_note,
                ).first()
                if reimbursement_allocation:
                    reimbursement_allocation.show = item.show
                    reimbursement_allocation.scope = item.show_finance_scope
                    reimbursement_allocation.amount = item.amount
                    reimbursement_allocation.full_clean()
                    reimbursement_allocation.save()
                else:
                    reimbursement_allocation = ShowTransactionAllocation(
                        transaction=item.financial_transaction,
                        show=item.show,
                        scope=item.show_finance_scope,
                        amount=item.amount,
                        notes=allocation_note,
                    )
                    reimbursement_allocation.full_clean()
                    reimbursement_allocation.save()

        action_map = {
            ReimbursementRequest.Status.SUBMITTED: AuditEvent.Action.SUBMITTED,
            ReimbursementRequest.Status.APPROVED: AuditEvent.Action.APPROVED,
            ReimbursementRequest.Status.REJECTED: AuditEvent.Action.REJECTED,
            ReimbursementRequest.Status.PAID: AuditEvent.Action.PAID,
        }
        _audit_event(
            team=team, actor=request.user, action=action_map[item.status], obj=item,
            season=item.season,
            summary=f"Reimbursement {item.get_status_display().lower()}: {item.description}",
            details={
                "from_status": previous_status, "to_status": item.status,
                "amount": item.amount, "reviewer": request.user,
                "ledger_transaction": item.financial_transaction_id or "",
            },
        )
        messages.success(request, "Reimbursement request updated.")
        return redirect("reimbursement_list")
    return render(request, "portal/form.html", {
        "form": form, "title": f"Review reimbursement · {obj.payee_name}", "eyebrow": "TREASURER"
    })


@login_required
def reimbursement_receipt(request, pk):
    _require_adult_finance_participant(request.user)
    team=_team(request.user); obj=get_object_or_404(ReimbursementRequest,pk=pk,team=team)
    season=obj.season
    if obj.requested_by_id != request.user.id and not _can_finance(request.user,season):
        raise PermissionDenied
    if not obj.receipt: raise Http404("No receipt attached.")
    return FileResponse(obj.receipt.open("rb"),as_attachment=True,filename=Path(obj.receipt.name).name)
