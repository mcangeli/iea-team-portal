# IEA Team Portal v1.4.0

## Points, Qualification & Standings

### Show-level points riders
- Coaches can designate a **points rider for each show class** directly from the show page.
- The points-rider designation is show-specific and class-specific.
- Futures and Upper School designations are tracked independently, so one points rider per team can be used where a class supports both teams.
- Selecting a new points rider automatically clears the previous points rider for that class/team.
- A points rider must be a Team or Individual + Team entry. Designating an Individual-only entry automatically changes it to Individual + Team.
- Non-points riders continue earning individual points normally; only the designated points rider contributes that class result to the team total.

### Automatic result scoring
- New results calculate points automatically from placing using the season scoring configuration.
- Default regular-season scale: 1st 7, 2nd 5, 3rd 4, 4th 3, 5th 2, 6th 1.
- Coaches can mark a result as a manual points override for corrections or unusual situations.
- Existing pre-v1.4 result point values are preserved as manual historical values during migration.

### Qualification configuration
- Each season has editable scoring and qualification settings.
- Individual qualification threshold defaults to 18 points.
- Team qualification threshold defaults to 20 points.
- Thresholds and placing values can be changed by coaches/admins without code changes.
- Coaches can override an individual rider/class qualification status and attach a note.

### Standings dashboard
- New **Standings** navigation section.
- Individual rider/class points are totaled for the active season.
- Qualification status is calculated against the season threshold, with coach overrides respected.
- Team points are calculated separately for Futures and Upper School from designated points riders.
- Per-show team scoring lists the class, designated rider, placing, and points used in the team total.
- Futures / Upper School filters are available.
- Full individual and team standings can be exported to CSV.

## Migration
- Adds `portal.0005_v140_points_qualification`.
- Adds `ShowResult.manual_points`.
- Adds `SeasonScoringConfig`.
- Adds `QualificationOverride`.
- Seeds a scoring configuration for existing seasons.
- Marks all existing non-null result point values as manual so historical scoring is not recalculated on upgrade.

## Deployment
The persistent `.env`, PostgreSQL volume, media volume, loopback gateway, preflight checks, and automatic backup upgrade workflow introduced in v1.3 remain unchanged.
