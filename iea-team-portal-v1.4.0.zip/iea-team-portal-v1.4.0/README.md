# IEA Team Portal v1.4.0

A self-hosted Django portal for an interscholastic equestrian team with separate Futures and Upper School season rosters, season class assignments, shows, results, points-rider designation, qualification tracking, standings, calendar, rider profiles, parent/guardian contacts, announcements, and role-based access.

The application uses an IEA-inspired palette but does not bundle official IEA logo artwork. Upload only branding your team is authorized to use. This private team portal complements rather than replaces AccessIEA.

## v1.4.0 highlights

- Show-level, class-level points-rider designation.
- One points rider per class/team with automatic replacement of the previous designation.
- Team points derived from the designated rider's actual class result.
- Individual points continue to count for every rider regardless of points-rider status.
- Automatic points calculation from placing with configurable season scoring values.
- Manual result-point overrides for corrections and exceptions.
- Individual qualification progress by rider and season class.
- Separate Futures and Upper School team qualification totals.
- Coach qualification overrides and notes.
- New standings dashboard and CSV export.
- Existing historical result points are preserved on upgrade.

## Persistent deployment layout

```text
/opt/iea-team-portal/
├── .env
├── backups/
├── iea-team-portal-v1.3.0/
└── iea-team-portal-v1.4.0/
```

The Compose project and persistent volumes remain:

```text
iea-team-portal_postgres_data
iea-team-portal_media_data
```

The existing host reverse proxy can continue forwarding HTTPS traffic to:

```text
http://127.0.0.1:8088
```

## Upgrade to v1.4.0

Extract the release under `/opt/iea-team-portal/`, then run:

```bash
cd /opt/iea-team-portal/iea-team-portal-v1.4.0
chmod +x portalctl
./portalctl upgrade
```

`upgrade` creates a timestamped PostgreSQL backup, builds the release, runs schema preflight, starts the application, and Django applies migrations automatically using `migrate --fake-initial --noinput` before Gunicorn starts.

Verify after startup:

```bash
./portalctl ps
./portalctl logs --tail=150 web
./portalctl exec web python manage.py showmigrations portal
./portalctl exec web python manage.py check
```

Expected portal migration history:

```text
[X] 0001_initial
[X] 0002_competition_management
[X] 0003_team_levels_season_classes_guardians
[X] 0004_v130_workflow
[X] 0005_v140_points_qualification
```

## v1.4 scoring workflow

### Configure the season
1. Open **Standings**.
2. Coaches/admins can choose **Scoring rules**.
3. Review/edit first-through-sixth point values.
4. Set the individual qualification threshold appropriate for the season/zone.
5. Set the team qualification threshold.

### Enter a show
1. Create the show and add its season classes.
2. Add riders to each class from their season assignments.
3. On the show page, click **Make point rider** beside the rider selected by the coach for that class.
4. Enter each rider's placing/result.
5. Points calculate automatically unless **manual points** is selected on the result.

### Team points
For each show class, only the designated points rider's result contributes to that team's total. Other riders' results still contribute to their individual qualification totals.

### Qualification overrides
From **Standings**, a coach/admin can override a rider/class qualification status and add a note. Leaving the status on Automatic makes the portal use the configured threshold.

## Roles
- Administrator
- Coach
- Parent/Guardian
- Rider

Parents and riders remain restricted to linked rider information. Coaches/admins can manage team-wide competition and scoring data.
